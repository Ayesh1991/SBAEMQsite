/* ============================================================
   wallet.js — the prepaid balance, in Sri Lankan rupees.

   How the money works
     You pay into the account and upload the slip. The slip is read
     once by a vision model — the cheapest call in the app — which
     pulls out the amount, the reference you typed in the remark and
     the bank's own transaction number. That becomes a TOP-UP REQUEST,
     which the site owner approves. An AI reading a screenshot is not
     proof of payment, so nothing is credited automatically; approval
     is one click against the slip and the extracted fields.

   The balance is DERIVED, never a running total
     balance = approved top-ups − everything the AI has cost you.
     The spend side comes from ai_token_usage — the same metered rows
     the invoices are built from — priced by the live rate card and
     converted at the dollar rate the developer sets. Nothing to keep
     in sync, nothing that can drift, and the reading of your own slip
     appears in it as a handling fee like any other AI call.

   When it runs out
     Every AI surface asks canSpend() first. At zero the AI stops and
     says so; everything else in AUREUM keeps working.
   ============================================================ */

const Wallet = (() => {
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const cfg = () => window.AUREUM_CONFIG || {};

  const DEFAULT_RATE = 340;          // LKR per USD, until the developer sets one
  const RATE_KEY = 'wallet-rate';
  let _rate = null, _state = null;

  const lkr = n => 'LKR ' + Number(n || 0).toLocaleString('en-LK', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const rate = () => _rate == null ? DEFAULT_RATE : _rate;

  async function loadRate() {
    if (_rate != null) return _rate;
    try {
      const loader = () => Backend.getWalletConfig();
      const c = (typeof Cache !== 'undefined') ? await Cache.wrap(RATE_KEY, 10 * 60 * 1000, loader) : await loader();
      _rate = Number(c?.usdRate) > 0 ? Number(c.usdRate) : DEFAULT_RATE;
      _state = Object.assign({ minTopUp: 300, packs: [300, 500, 1000, 2000] }, c || {});
    } catch { _rate = DEFAULT_RATE; }
    return _rate;
  }
  const settings = () => _state || { minTopUp: 300, packs: [300, 500, 1000, 2000] };
  function bustRate() { _rate = null; _state = null; if (typeof Cache !== 'undefined') Cache.bust(RATE_KEY); }

  /* ---------------- checking a slip against the account ----------------

     A slip credits the balance on the spot only if it says all four things:
     the right account, an amount, a date, and the payer's own user number.
     Anything missing and it goes for approval the way it always did.

     Account numbers are compared as DIGITS with leading zeros stripped,
     because the same account is printed both ways: 0087612781 on one bank's
     receipt and 87612781 on another's. Nothing else about the number is
     normalised — a different account is a different account.

     This is a provisional credit, not a verification. The developer still
     confirms it against the bank; until then it is flagged as unconfirmed
     and carries the deadline by which it will be looked at. */
  const digits = s => String(s == null ? '' : s).replace(/\D/g, '');
  const bare = s => digits(s).replace(/^0+/, '');
  function sameAccount(a, b) {
    const x = bare(a), y = bare(b);
    return !!x && !!y && x === y;
  }
  const beneficiary = () => {
    const w = settings();
    const c = cfg().wallet || {};
    return Object.assign({ account: '', bank: '', name: '' }, c.beneficiary || {}, w.beneficiary || {});
  };
  const instantOn = () => {
    const w = settings(), c = cfg().wallet || {};
    const v = w.instantActivation != null ? w.instantActivation : c.instantActivation;
    return v !== false && !!beneficiary().account;
  };
  const instantHours = () => Number(settings().instantHours || (cfg().wallet || {}).instantHours) || 24;

  /** Everything the slip has to show, and whether it showed it. */
  function slipCheck(fields, userRef) {
    const acct = beneficiary().account;
    // the receiving side only — a slip whose sender is this account is money
    // going the other way (mirrors maybeCreditSlip on the server)
    const onSlip = [fields.accountTo, fields.payee, ...(fields.accounts || [])];
    const fromIsUs = sameAccount(fields.accountFrom, acct);
    const ref = digits(fields.reference);
    const want = digits(userRef);
    return {
      account: { ok: !!acct && !fromIsUs && onSlip.some(v => sameAccount(v, acct)), label: 'Paid into ' + (acct || '—') },
      amount:  { ok: Number(fields.amount) > 0, label: 'Amount' },
      date:    { ok: !!String(fields.date || '').trim(), label: 'Transfer date' },
      reference: { ok: !!want && ref === want, label: 'Your reference (' + userRef + ')' }
    };
  }
  const slipComplete = c => Object.values(c).every(x => x.ok);

  /* ================= the balance =================

     THE METER STARTS WHEN YOU JOIN, NOT WHEN YOU SIGNED UP.

     This got somebody's balance badly wrong, and the arithmetic was
     never the problem — the START DATE was. A user had been using
     AUREUM for months and paying for it directly, outside the app.
     Then the prepaid system arrived, they topped up LKR 100, and the
     balance read MINUS 898: every rupee of AI they had ever used, from
     long before there was a wallet to charge it to, deducted from a
     top-up that was never meant to cover it. They had already paid for
     that usage once.

     So spend is counted from the day of the FIRST APPROVED TOP-UP.
     Everything before that was settled some other way and is none of
     this ledger's business. It is still shown — under its own heading,
     so the numbers reconcile and nobody thinks usage went missing — but
     it is not deducted.

     A user with NO top-up has not joined the prepaid system at all.
     They have no prepaid balance to run down, so the wallet does not
     gate them; the `paid` flag governs them exactly as it did before
     any of this existed. The meter starts the moment they top up. */

  /** The day the account joined the prepaid system, as YYYY-MM-DD. */
  const joinedOn = tops => {
    const days = (tops || [])
      .filter(t => t.status === 'approved')
      .map(t => String(t.created_at || t.createdAt || '').slice(0, 10))
      .filter(Boolean)
      .sort();
    return days[0] || null;
  };
  /* Usage rows carry a DAY, not an instant, so the comparison is by day
     and a top-up made at three in the afternoon forgives that morning.
     Erring towards the user is the right direction for a rounding rule
     nobody can see. */
  const chargeable = (rows, since) => (since ? (rows || []).filter(r => String(r.day || '') >= since) : []);
  const earlier = (rows, since) => (since ? (rows || []).filter(r => String(r.day || '') < since) : (rows || []));
  const usd = rows => (typeof Billing !== 'undefined')
    ? (rows || []).reduce((n, r) => n + Billing.lineCost(r), 0) : 0;

  let _cached = null, _at = 0;
  async function summary(force) {
    if (!force && _cached && Date.now() - _at < 30000) return _cached;
    await loadRate();
    try { if (typeof Billing !== 'undefined') await Billing.loadRates(); } catch {}
    const [tops, rows] = await Promise.all([
      Backend.listMyTopUps().catch(() => []),
      Backend.listMyTokenUsage().catch(() => [])
    ]);
    const creditedLkr = tops.filter(t => t.status === 'approved')
      .reduce((n, t) => n + (Number(t.amount_lkr) || 0), 0);
    const since = joinedOn(tops);
    const spentUsd = usd(chargeable(rows, since));
    const beforeUsd = usd(earlier(rows, since));
    const spentLkr = spentUsd * rate();
    const byFeature = (typeof Billing !== 'undefined') ? Billing.personalByFeature(chargeable(rows, since)) : [];
    _cached = {
      creditedLkr, spentUsd, spentLkr, balanceLkr: creditedLkr - spentLkr,
      /* what was used before the wallet existed — shown, never charged */
      since, onPrepaid: !!since, beforeUsd, beforeLkr: beforeUsd * rate(),
      rate: rate(), topUps: tops, byFeature,
      usage: rows,                 // the metered rows themselves, for the statement
      pending: tops.filter(t => t.status === 'pending').length
    };
    _at = Date.now();
    return _cached;
  }
  function bust() { _cached = null; _at = 0; }

  /* IS THE PREPAID SYSTEM BEING ENFORCED?

     The developer's own setting wins, and it is only OFF when somebody
     deliberately turned it off. The old test read the STATIC config file
     and ignored the saved one entirely, so the toggle in Rates &
     settings changed the server's behaviour and not the browser's — and
     the two then disagreed about whether a user could spend. One
     question, one answer, live setting first. */
  function enforcing() {
    /* There is no till in local mode. Top-ups, the metered rows and the
       rate card all live in the cloud backend; a browser-only deployment
       has no way to have been paid and no way to have spent, so every
       account there reads as a balance of exactly zero. Enforcing that
       would tell a brand-new local user their credit had run out before
       they had done anything at all. */
    if (typeof Backend !== 'undefined' && Backend.mode !== 'cloud') return false;
    const saved = settings();
    if (saved && saved.enforce != null) return saved.enforce !== false;
    return (cfg().wallet?.enforce) !== false;
  }

  /** Every AI surface asks this before spending. */
  async function canSpend() {
    try {
      const u = await Backend.currentUser();
      if (u && u.isDeveloper) return true;                 // the owner is never gated
      await loadRate();                                    // brings the saved wallet settings with it
      if (!enforcing()) return true;                       // prepaid off = nothing changes
      const s = await summary();
      /* Never topped up = never joined. There is no prepaid balance to
         have run out, so this is not the gate that applies to them —
         the `paid` flag is, as it was before the wallet existed. */
      if (!s.onPrepaid) return true;
      return s.balanceLkr > 0;
    } catch { return true; }                               // never block on a read failure
  }
  const blockedMessage = () =>
    'Your AUREUM balance has run out, so the AI features are paused. Top up in Profile → Billing & balance and they come straight back.';

  /* ================= the empty wallet =================

     THE FAILURE HAS TO SAY WHY, AND IT HAS TO SAY IT WHERE IT HAPPENED.

     An AI feature that simply stops working reads as a broken app. The
     three things somebody needs at that moment are: what happened (the
     balance is gone), what it cost them (nothing — the request was never
     sent), and what to do about it (top up, one tap away). A red line in
     a corner of a panel is none of those, so this is a dialog: it stops
     the page, says the number, and offers the button.

     Once per session, not once per attempt. Being told six times that
     your balance is empty is being shouted at. */
  let toldThisSession = false;
  /**
   * @param bal      the balance, or null when it could not be read
   * @param credited what has ever been paid in — a nought balance that was
   *                 never topped up is a NEW account, not an exhausted one,
   *                 and telling somebody their credit "has run out" on the
   *                 day they joined is both wrong and rude.
   */
  function emptyPopup(bal, credited) {
    if (document.querySelector('.wl-empty')) return;
    const fresh = !credited;
    const el = document.createElement('div');
    el.className = 'os-modal wl-empty';
    const n = bal == null ? null : lkr(bal);
    el.innerHTML = `
      <div class="os-modal-back" data-close></div>
      <div class="os-modal-box" role="dialog" aria-modal="true" aria-label="Balance empty">
        <div class="os-modal-head">
          <div><p class="kicker">BALANCE</p><h3>${fresh ? 'The AI features need a balance' : 'The AI features are paused'}</h3></div>
          <button class="os-modal-x" data-close aria-label="Close">✕</button>
        </div>
        <div class="os-modal-body">
          <p class="wl-empty-n">${n ? esc(n) : (fresh ? 'Nothing topped up yet' : 'Your balance has run out')}</p>
          <p>${fresh
            ? 'AUREUM is prepaid: the AI features draw on a balance you top up, and this account has not been '
              + 'topped up yet. Nothing has been charged and nothing is owed.'
            : 'Everything that costs money to run — marking, the tutor, flashcards, the spoken examiner, the case '
              + 'discussions — is paused until the balance is back above zero.'}
            <strong>Nothing was charged for the request you just made</strong>: it was never sent.</p>
          <p class="muted">The rest of AUREUM is untouched. Stations, schemes, your attempts, the printouts, the
            simulator questions and everything you have already been marked on are all still here.</p>
        </div>
        <div class="os-modal-foot">
          <a class="btn btn-gold" href="#/billing">Top up →</a>
          <button class="btn btn-ghost btn-sm" data-close>Not now</button>
        </div>
      </div>`;
    document.body.appendChild(el);
    const shut = () => { el.remove(); window.removeEventListener('hashchange', shut); document.removeEventListener('keydown', key); };
    const key = e => { if (e.key === 'Escape') shut(); };
    el.querySelectorAll('[data-close]').forEach(b => b.addEventListener('click', shut));
    el.querySelector('a')?.addEventListener('click', shut);
    window.addEventListener('hashchange', shut);
    document.addEventListener('keydown', key);
  }

  /**
   * The one call an AI surface makes before spending. Returns true to go
   * ahead; shows the dialog and returns false when the wallet is empty.
   *
   * The server refuses the same request independently — this is here so
   * the refusal arrives before a fifteen-minute recording is uploaded,
   * not after.
   */
  async function guard() {
    if (await canSpend()) return true;
    let s = null;
    try { s = await summary(); } catch {}
    emptyPopup(s ? s.balanceLkr : null, s ? s.creditedLkr : 0);
    return false;
  }

  /** Once per session, on arrival, so nobody discovers it mid-station. */
  async function nudge() {
    if (toldThisSession) return;
    try {
      await loadRate();
      if (!enforcing()) return;
      const u = await Backend.currentUser();
      if (!u || u.isDeveloper) return;
      const s = await summary();
      if (!s.onPrepaid) return;                 // never joined; nothing has run out
      if (s.balanceLkr > 0) return;
      toldThisSession = true;
      emptyPopup(s.balanceLkr, s.creditedLkr);
    } catch {}
  }

  /* THE SAME ARITHMETIC, WHEREVER IT IS ASKED.

     The developer's Users & access panel shows what each person has left,
     and a user's own Billing page shows the same number. If those two are
     computed in two places they will one day disagree, and the person who
     notices will be the one being told their balance is empty when their
     own page says it is not. Credited minus spent, converted at the one
     rate, once. */
  const balanceFrom = (creditedLkr, spentUsd) => creditedLkr - spentUsd * rate();

  /**
   * Everybody's balance, for the developer's Users & access panel.
   *
   * Takes the RAW metered rows rather than a per-user total, because the
   * total cannot answer the only question that matters here: was this
   * spent before or after they joined? A pre-computed all-time figure is
   * exactly what produced a balance of minus nine hundred rupees for an
   * account that had topped up a hundred and spent a fraction of it.
   *
   * Personal rows only. The shared platform pools the panel adds to its
   * COST column are the developer's own outgoings, attributed for
   * invoicing; they were never charged to anybody's wallet, and adding
   * them here would make this disagree with the user's own page.
   */
  function balances(topUps, usageRows) {
    const mine = {}, tops = {};
    (topUps || []).forEach(t => {
      const id = t.user_id || t.user_email;
      if (!id) return;
      (tops[id] || (tops[id] = [])).push(t);
    });
    (usageRows || []).forEach(r => {
      const id = r.userId || r.user_id;
      if (!id) return;
      (mine[id] || (mine[id] = [])).push(r);
    });
    const out = {};
    for (const id of new Set([...Object.keys(tops), ...Object.keys(mine)])) {
      const ts = tops[id] || [], rows = mine[id] || [];
      const creditedLkr = ts.filter(t => t.status === 'approved')
        .reduce((n, t) => n + (Number(t.amount_lkr) || 0), 0);
      const since = joinedOn(ts);
      const spentUsd = usd(chargeable(rows, since));
      const beforeUsd = usd(earlier(rows, since));
      out[id] = {
        creditedLkr, spentUsd, spentLkr: spentUsd * rate(),
        balanceLkr: balanceFrom(creditedLkr, spentUsd),
        since, onPrepaid: !!since, beforeUsd, beforeLkr: beforeUsd * rate()
      };
    }
    return out;
  }

  /** Charge is a no-op by design — spend is metered server-side and derived. */
  async function charge() { bust(); }

  /* ---------------- reading a payment slip ---------------- */

  async function readSlip(file) {
    const token = await Backend.getAccessToken();
    if (!token) throw new Error('Sign in first.');
    const img = await shrink(file);
    const res = await fetch(cfg().ai.apiBase, {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
      body: JSON.stringify({ action: 'slip', provider: 'gemini', image: { mime: img.mime, data: img.b64 } })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `Could not read the slip (HTTP ${res.status}).`);
    let d = null;
    const raw = String(data.text || '').trim().replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
    try { d = JSON.parse(raw); } catch {
      const a = raw.indexOf('{'), b = raw.lastIndexOf('}');
      if (a >= 0 && b > a) { try { d = JSON.parse(raw.slice(a, b + 1)); } catch {} }
    }
    if (!d) throw new Error('The slip could not be read. Try a clearer screenshot, or enter the details by hand.');
    /* Whether this slip credited itself was decided by the server, off the
       image, before this line ran — the browser is told the verdict, it does
       not reach it. See maybeCreditSlip in functions/api/explain.js. */
    return { fields: d, usage: data.usage || {}, preview: img.dataUrl,
      verdict: { credited: !!data.credited, match: data.match || null, reason: data.reason || '',
        confirmBy: data.confirmBy || 0, beneficiary: data.beneficiary || '', id: data.topUpId,
        flags: data.flags || [], risk: data.risk || '' } };
  }

  /* A slip only has to be legible, so it is shrunk hard before it is sent:
     fewer pixels is fewer image tokens, and the whole point of this call is
     that it costs almost nothing. */
  function shrink(file, max = 1100) {
    return new Promise((resolve, reject) => {
      if (/pdf/i.test(file.type)) {
        // a PDF cannot be resized in the browser; send it as-is if it is small
        if (file.size > 4 * 1024 * 1024) return reject(new Error('That PDF is too large — please send a screenshot instead.'));
        const fr = new FileReader();
        fr.onload = () => { const s = String(fr.result); resolve({ mime: file.type, b64: s.split(',')[1], dataUrl: s }); };
        fr.onerror = () => reject(new Error('Could not read that file.'));
        return fr.readAsDataURL(file);
      }
      const fr = new FileReader();
      fr.onload = () => {
        const im = new Image();
        im.onload = () => {
          const scale = Math.min(1, max / Math.max(im.width, im.height));
          const c = document.createElement('canvas');
          c.width = Math.round(im.width * scale); c.height = Math.round(im.height * scale);
          c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
          const dataUrl = c.toDataURL('image/jpeg', 0.72);
          resolve({ mime: 'image/jpeg', b64: dataUrl.split(',')[1], dataUrl });
        };
        im.onerror = () => reject(new Error('That file is not an image the browser can open.'));
        im.src = String(fr.result);
      };
      fr.onerror = () => reject(new Error('Could not read that file.'));
      fr.readAsDataURL(file);
    });
  }

  /* ================= Profile → Billing & balance ================= */

  async function renderBilling(view, user) {
    view.innerHTML = `<section class="page narrow"><p class="muted">Loading your balance…</p></section>`;
    const s = await summary(true);
    /* Not on the prepaid system is not the same as empty: nothing has run
       out for somebody who has not started. */
    const low = !s.onPrepaid ? '' : s.balanceLkr <= 0 ? 'is-empty' : s.balanceLkr < 100 ? 'is-low' : '';
    const packs = settings().packs || [300, 500, 1000, 2000];
    const ben = beneficiary();

    view.innerHTML = `
      <section class="page narrow">
        <a class="link muted dev-back" href="#/profile">← Profile</a>
        <header data-animate>
          <p class="kicker">PREPAID · SRI LANKAN RUPEES</p>
          <h1 class="page-title">Billing &amp; balance</h1>
        </header>

        <div class="card wl-balance ${low}" data-animate>
          <div class="wl-bal-main">
            <span class="wl-bal-label">Your balance</span>
            <strong class="wl-bal-n">${lkr(s.balanceLkr)}</strong>
            <span class="muted tiny">Topped up ${lkr(s.creditedLkr)} · used ${lkr(s.spentLkr)}
              ($${s.spentUsd.toFixed(4)} at LKR ${s.rate}/USD)${
              s.since ? ` since ${esc(s.since)}` : ''}</span>
            ${/* WHERE THE OLD USAGE WENT.

                  Somebody who used AUREUM before the wallet existed, and
                  paid for it another way, must not see that usage
                  deducted from the first top-up they make. It is not
                  hidden either — a figure that quietly vanishes is a
                  figure somebody spends an evening looking for. It is
                  named, and shown not to count. */
              s.beforeLkr > 0.005 ? `<span class="muted tiny wl-bal-before">
              ${lkr(s.beforeLkr)} of AI was used before you topped up${s.since ? ' on ' + esc(s.since) : ''}.
              That was settled outside this balance and is <strong>not</strong> charged here.</span>` : ''}
          </div>
          <div class="wl-bal-side">
            ${!s.onPrepaid
              ? `<span class="wl-chip">Top up to start your balance</span>`
              : s.balanceLkr <= 0
              ? `<span class="wl-chip bad">AI paused — top up to resume</span>`
              : `<span class="wl-chip good">AI active</span>`}
            ${s.pending ? `<span class="wl-chip">${s.pending} top-up awaiting approval</span>` : ''}
          </div>
        </div>

        <div class="card" data-animate>
          <h3 class="card-title">Top up</h3>
          ${ben.account ? `<div class="wl-acct">
            <span class="wl-acct-k">Pay into</span>
            <strong class="wl-acct-n">${esc(ben.account)}</strong>
            <button class="btn btn-ghost btn-sm" id="wl-bd">🏦 Billing details</button>
          </div>` : ''}
          <ol class="wl-steps">
            <li><strong>Pay into the account${ben.account ? ` above` : ` shown by the site owner`}.</strong> Put your user number
              <code class="wl-uno">${esc(userNo(user))}</code> in the <strong>remark / reference</strong> field —
              that is how the payment is matched to you.</li>
            <li><strong>Upload the slip</strong> below — the bank's PDF, a screenshot, or a photo.</li>
            ${instantOn() ? `<li><strong>It is credited straight away</strong> if the slip shows the account, the amount,
              the date and your reference. Otherwise it goes to the site owner for approval.</li>`
              : `<li>It is read automatically and sent for approval. Once approved the balance appears here.</li>`}
          </ol>
          <div class="wl-packs">${packs.map(p => `<span class="wl-pack">${lkr(p)}</span>`).join('')}
            <span class="muted tiny">common amounts — any amount works</span></div>

          <label class="btn btn-gold" style="cursor:pointer;margin-top:14px">⬆ Upload a payment slip
            <input type="file" id="wl-file" accept="image/*,application/pdf" hidden></label>
          <div id="wl-slip"></div>
        </div>

        <!-- The box is ALWAYS in the page; wireDrive decides what goes in it,
             including nothing. Making the container itself conditional meant
             the developer's "why is it not set up" checklist had nowhere to
             render — the panel was hidden twice over, and fixing only one of
             them fixed nothing. -->
        ${typeof Drive !== 'undefined' ? `<div class="card" data-animate id="wl-drive" hidden></div>` : ''}

        <div class="card" data-animate>
          <h3 class="card-title">↔ Send credit to another user</h3>
          <p class="muted">If a colleague is out of balance in the middle of a circuit and cannot get to a bank, you can
            move some of yours across. It leaves your balance and arrives in theirs immediately — there is nothing to
            approve, and no fee. Your own number is <code class="wl-uno">${esc(userNo(user))}</code>; ask them for theirs.</p>
          <div class="wl-send">
            <label class="wl-f"><span>Their user number</span>
              <input type="text" id="wl-to" inputmode="numeric" maxlength="8" placeholder="e.g. 10042" autocomplete="off"></label>
            <label class="wl-f"><span>Amount (LKR)</span>
              <input type="number" id="wl-amt" min="1" step="1" placeholder="500"></label>
            <label class="wl-f"><span>Note (optional)</span>
              <input type="text" id="wl-note" maxlength="120" placeholder="for the OSCE circuit"></label>
            <button class="btn btn-gold" id="wl-send-go" style="align-self:end">Check the name</button>
          </div>
          <div id="wl-send-out"></div>
        </div>

        <div class="card" data-animate>
          <div class="es-inbox-head">
            <h3 class="card-title">Where the money went</h3>
            <button class="btn btn-ghost btn-sm" id="wl-pb">📗 Full statement</button>
          </div>
          ${s.byFeature.length ? `
          <div class="table-scroll"><table class="table">
            <thead><tr><th>Feature</th><th>Calls</th><th>Tokens</th><th>Cost</th></tr></thead>
            <tbody>${s.byFeature.map(f => `<tr>
              <td>${f.icon} ${esc(f.label)}</td><td class="muted">${f.calls}</td>
              <td class="muted">${(f.inputTokens + f.outputTokens).toLocaleString('en-US')}</td>
              <td><strong>${lkr(f.cost * s.rate)}</strong> <span class="muted tiny">$${f.cost.toFixed(4)}</span></td>
            </tr>`).join('')}</tbody>
          </table></div>` : `<p class="muted">Nothing spent yet.</p>`}
        </div>

        <div class="card" data-animate>
          <h3 class="card-title">Top-up history</h3>
          ${s.topUps.length ? `
          <div class="table-scroll"><table class="table">
            <thead><tr><th>When</th><th>Amount</th><th>Reference</th><th>Status</th></tr></thead>
            <tbody>${s.topUps.slice().sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0)).map(t => `
              <tr><td class="muted">${esc(new Date(t.created_at || Date.now()).toLocaleDateString('en-GB', { dateStyle: 'medium' }))}</td>
                <td><strong>${lkr(t.amount_lkr)}</strong></td>
                <td class="muted">${esc(t.reference || '—')}</td>
                <td>${t.status === 'approved' ? '<span class="good">Approved</span>'
                   : t.status === 'declined' ? `<span class="bad">Declined</span>${t.note ? ` <span class="muted tiny">${esc(t.note)}</span>` : ''}`
                   : '<span class="gold">Awaiting approval</span>'}</td></tr>`).join('')}</tbody>
          </table></div>` : `<p class="muted">No top-ups yet.</p>`}
        </div>
      </section>`;
    FX.viewIn(view);

    view.querySelector('#wl-bd')?.addEventListener('click', () => billingDetails(ben));
    wireSend(view, s, user);
    wireDrive(view, user);
    view.querySelector('#wl-pb').addEventListener('click', () => passbook(s));

    view.querySelector('#wl-file').addEventListener('change', async e => {
      const f = e.target.files[0]; e.target.value = '';
      if (!f) return;
      const host = view.querySelector('#wl-slip');
      host.innerHTML = `<div class="ai-loading"><span></span><span></span><span></span></div>
        <p class="muted tiny">Reading the slip…</p>`;
      try {
        const { fields, usage, preview, verdict } = await readSlip(f);
        showSlip(host, fields, preview, usage, user, view, verdict);
      } catch (err) {
        host.innerHTML = `<p class="ai-error">${esc(err.message || err)}</p>`;
      }
    });
  }

  const userNo = u => String(u?.userNo || u?.user_no || (u?.id || '').replace(/\D/g, '').slice(-5) || '00001').padStart(5, '0');

  /* ---------------- the Drive connection ----------------
     Shown wherever the money is, because it is the same kind of fact: a
     thing that is either working or is not, and that you need to KNOW is
     not working rather than discover when a recording has gone. While the
     Google app is in Testing the grant lapses after about a week, so a
     stale connection is the normal case, not an exception. */
  function wireDrive(view, user) {
    const host = view.querySelector('#wl-drive');
    if (!host || typeof Drive === 'undefined') return;

    /* AN UNCONFIGURED FEATURE MUST NOT BE INVISIBLE TO THE PERSON
       CONFIGURING IT.

       Hiding this panel until `driveSave.clientId` is filled in is right for
       everyone else — there is nothing they can do about it and a dead
       button is worse than no button. It is wrong for the developer, who is
       the one working through the Google setup and for whom "I finished
       step 6 and the panel is not there" is indistinguishable from "the
       feature is broken".

       So the developer sees it either way, and when it is not configured it
       says exactly which of the three values is missing. */
    if (!Drive.configured()) {
      const devEmail = (window.AUREUM_CONFIG || {}).developer?.email;
      const dev = (user?.email && devEmail && user.email === devEmail)
        || sessionStorage.getItem('aureum-dev') === '1';
      if (!dev) return;
      const c = (window.AUREUM_CONFIG || {}).driveSave || {};
      const rows = [
        ['clientId', c.clientId, 'the OAuth client ID from step 4 — ends in .apps.googleusercontent.com'],
        ['apiKey', c.apiKey, 'the browser API key from step 5 — begins AIzaSy'],
        ['appId', c.appId, 'the Cloud project NUMBER from step 1 — digits only']
      ];
      const missing = rows.filter(r => !String(r[1] || '').trim());
      host.hidden = false;
      host.innerHTML = `
        <h3 class="card-title">☁ Recordings in your Drive <span class="wl-dv-off-pill">not set up</span></h3>
        <p class="muted">Only you can see this box. Drive saving is switched off for everybody until the three
          values from <code>docs/drive-setup.md</code> are in <code>js/config.js</code> → <code>driveSave</code>
          <strong>and the site has been deployed with them</strong>. Editing config.js on your machine changes
          nothing until the new file is live.</p>
        <ul class="wl-dv-check">
          ${rows.map(([k, v, hint]) => `<li class="${String(v || '').trim() ? 'is-set' : 'is-missing'}">
            <span>${String(v || '').trim() ? '✓' : '✗'}</span>
            <code>${k}</code> — ${String(v || '').trim()
              ? '<em class="muted tiny">set</em>'
              : `<em class="muted tiny">${esc(hint)}</em>`}</li>`).join('')}
        </ul>
        <p class="muted tiny">${missing.length
          ? `${missing.length} of 3 still empty in the <strong>deployed</strong> config.`
          : 'All three are present here — if the button still does not appear, the browser is holding an old copy of config.js. Hard-refresh, or bump the <code>?v=</code> number.'}</p>`;
      return;
    }

    const paint = () => {
      const st = Drive.status();
      /* THE MISSED ONES, COUNTED.
         Until v90 a recording that could not be copied left no trace at
         all, so a folder that had quietly stopped filling looked exactly
         like a fortnight with no stations in it. Every miss now leaves a
         row, and the ones still inside their 24 hours can be fetched
         back off the server and sent up. */
      const waiting = Drive.pending();
      const savable = Drive.recoverable();
      const missBox = waiting.length ? `
        <div class="wl-dv-miss">
          <p><strong>${waiting.length} recording${waiting.length === 1 ? '' : 's'} did not reach Drive.</strong>
            ${savable.length
              ? `${savable.length} ${savable.length === 1 ? 'is' : 'are'} still on the server and can be copied up now.`
              : 'All of them are past their 24 hours on the server, so there is nothing left to copy.'}</p>
          <ul class="wl-dv-misslist">${waiting.slice(-6).reverse().map(x => {
            const alive = savable.some(y => y.id === x.id);
            return `<li class="${alive ? 'is-live' : 'is-gone'}">
              <span>${esc(x.topic || 'Recording')}</span>
              <em class="muted tiny">${esc(new Date(x.when || Date.now()).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' }))}
                — ${alive ? 'recoverable' : 'past its 24 hours'}${x.why ? ' · ' + esc(x.why) : ''}</em></li>`;
          }).join('')}</ul>
          ${waiting.length > 6 ? `<p class="muted tiny">…and ${waiting.length - 6} older.</p>` : ''}
          <div class="wl-dv-acts">
            ${savable.length && st.code === 'connected'
              ? `<button class="btn btn-gold btn-sm" id="wl-dv-drain">⤒ Copy these ${savable.length} up now</button>` : ''}
            <button class="btn btn-ghost btn-sm" id="wl-dv-clear">Clear the list</button>
          </div>
        </div>` : '';
      const body = {
        disconnected: `<p class="muted">Your OSCE recordings are kept on the AUREUM server for 24 hours and then
            deleted. Connect a Google Drive folder and a copy of every recording is saved there as well — yours,
            for as long as you keep it.</p>
          <p class="muted tiny">AUREUM can only see the folder you choose and the files it puts in it. It cannot
            read anything else in your Drive.</p>
          <button class="btn btn-gold" id="wl-dv-go">Connect a Drive folder</button>
          ${missBox}`,
        stale: `<p class="wl-dv-warn">⚠ ${esc(st.label)}. Recordings are still kept on the server for 24 hours, but
            nothing has been copied to Drive since. Google ends the permission after about a week — reconnecting
            takes two taps.</p>
          ${st.error ? `<p class="muted tiny">Google said: ${esc(st.error)}</p>` : ''}
          <button class="btn btn-gold" id="wl-dv-go">Reconnect Drive</button>
          <button class="btn btn-ghost btn-sm" id="wl-dv-off">Turn it off</button>
          ${missBox}`,
        connected: `<p class="good">✓ Saving to <strong>${esc(st.folder || 'your folder')}</strong>${
            st.saved ? ` — ${st.saved} recording${st.saved === 1 ? '' : 's'} so far` : ' — nothing saved yet'}${
            st.last ? `, last on ${esc(new Date(st.last).toLocaleDateString('en-GB', { dateStyle: 'medium' }))}` : ''}.</p>
          <p class="muted tiny">A copy is sent to Drive <strong>as soon as a station or a case is marked</strong> —
            not at the end of the day. The separate 24-hour copy on the AUREUM server is unrelated and is what the
            player on a report reads from.</p>
          <p class="muted tiny">Google ends this permission after about a week while the app is unverified. If it
            lapses, this box says so — the recordings are not lost, they simply stop being copied.</p>
          <div class="wl-dv-acts">
            <button class="btn btn-ghost btn-sm" id="wl-dv-back">⤒ Copy the ones still on the server</button>
            <button class="btn btn-ghost btn-sm" id="wl-dv-go">Choose a different folder</button>
            <button class="btn btn-ghost btn-sm" id="wl-dv-off">Disconnect</button>
          </div>
          <p class="muted tiny">Anything marked <em>before</em> you connected was never copied — the upload happens
            at marking time and there was nowhere to send it. Whatever is still inside its 24 hours can be picked
            up now.</p>
          ${missBox}`
      }[st.code] || '';
      /* WHY THIS KEEPS ASKING — FOR THE ONE PERSON WHO CAN STOP IT.

         "I have to reconnect almost every time" has two causes and only
         one of them was ours. The one that was ours is fixed: a token
         request that failed because the browser blocked Google's popup
         used to be recorded as a dead grant, which meant a manual
         reconnection after something that was never a permission problem
         at all.

         The other is Google's, and it is a setting rather than a bug: an
         OAuth app left in Testing has its grants expired after seven
         days, for every user, no matter what the app does. Publishing the
         consent screen ends that. The `drive.file` scope is non-sensitive,
         so publishing does not put this app into the paid security
         assessment — which is the reason the scope was chosen.

         Shown to the developer only. Nobody else can act on it. */
      const devEmail = (window.AUREUM_CONFIG || {}).developer?.email;
      const isDev = (user?.email && devEmail && user.email === devEmail)
        || sessionStorage.getItem('aureum-dev') === '1';
      const devNote = isDev ? `
        <details class="dev-collapse wl-dv-dev">
          <summary><span class="card-title">Why it asks so often — and the one setting that stops it</span><span class="dc-caret">▸</span></summary>
          <p class="muted tiny">Two different things expire, and only the second is fixable from here.</p>
          <ul class="wl-dv-why">
            <li><strong>The access token lasts one hour.</strong> By design — a browser-side token client is given no
              refresh token, so nothing long-lived about anyone's Google account is stored on this site. It is renewed
              silently and you never see it happen. This is not what makes you reconnect.</li>
            <li><strong>The grant lasts seven days while the OAuth app is in Testing.</strong> This is the one you are
              feeling. In the Google Cloud console, <em>APIs &amp; Services → OAuth consent screen → Publish app</em>.
              With only the <code>drive.file</code> scope — which is what this uses — the app is not sensitive and
              publishing does not require Google's paid verification. After publishing, a connection lasts until it is
              revoked.</li>
            <li><strong>A blocked popup used to look like an expired grant.</strong> Fixed here: only a real refusal
              from Google (<code>access_denied</code>, <code>consent_required</code>, <code>login_required</code>,
              <code>invalid_grant</code>) now marks the connection stale. A popup Safari would not open, a dropped
              network or a backgrounded tab leaves it alone, and the next upload simply tries again.</li>
          </ul>
        </details>` : '';

      host.hidden = false;
      host.innerHTML = `<h3 class="card-title">☁ Recordings in your Drive ${Drive.badgeHtml()}</h3>${body}${devNote}
        <div class="dev-status" id="wl-dv-msg"></div>`;

      /* SENDING UP WHAT THE OUTBOX REMEMBERS.
         The row holds the server path, not the tape, so this fetches the
         24-hour copy back and puts it in Drive. A row whose copy has been
         swept is dropped rather than kept forever promising a rescue that
         can no longer happen. */
      async function drainOutbox(say) {
        const rows = Drive.recoverable();
        if (!rows.length) return { done: 0, gone: 0, failed: 0 };
        let done = 0, gone = 0, failed = 0;
        for (let i = 0; i < rows.length; i++) {
          say?.(`Copying ${i + 1} of ${rows.length}…`);
          const r = rows[i];
          let url = null;
          try {
            url = r.kind === 'case' ? await Backend.getCaseAudioUrl(r.path) : await Backend.getOsceAudioUrl(r.path);
          } catch {}
          if (!url) { Drive.forget(r.id); gone++; continue; }
          try {
            const blob = await (await fetch(url)).blob();
            const ext = /mp4|aac/.test(blob.type || '') ? 'm4a' : 'webm';
            const label = (r.kind === 'case' ? 'CASE — ' : '') + (r.topic || 'Recording');
            const up = await Drive.upload(blob, Drive.nameFor(label, r.when || Date.now(), ext),
              { description: 'AUREUM — copied up from the outbox' });
            if (!up) { failed++; continue; }
            Drive.forget(r.id);
            done++;
          } catch { failed++; }
        }
        return { done, gone, failed };
      }

      host.querySelector('#wl-dv-go')?.addEventListener('click', async e => {
        e.target.disabled = true;
        const msg = host.querySelector('#wl-dv-msg');
        msg.innerHTML = '<span class="muted">Waiting for Google…</span>';
        try {
          await Drive.connect();
          /* Reconnecting is the moment the waiting tapes become sendable,
             and asking the user to find a second button for it is how
             they get missed. */
          let tail = '';
          if (Drive.recoverable().length) {
            msg.innerHTML = '<span class="muted">Connected — copying up the ones that were waiting…</span>';
            const r = await drainOutbox(t => { msg.innerHTML = `<span class="muted">${esc(t)}</span>`; });
            tail = r.done ? ` ${r.done} waiting recording${r.done === 1 ? '' : 's'} copied up.` : '';
            if (r.failed) tail += ` ${r.failed} would not upload.`;
          }
          paint();
          const fresh = host.querySelector('#wl-dv-msg');
          if (fresh) fresh.innerHTML = `<span class="good">✓ Connected.${esc(tail)}</span>`;
        }
        catch (err) { msg.innerHTML = `<span class="bad">${esc(err.message || err)}</span>`; e.target.disabled = false; }
      });
      host.querySelector('#wl-dv-off')?.addEventListener('click', () => {
        if (!confirm('Stop saving recordings to Drive? Anything already saved stays in your folder.')) return;
        Drive.disconnect(); paint();
      });
      host.querySelector('#wl-dv-drain')?.addEventListener('click', async e => {
        e.target.disabled = true;
        const msg = host.querySelector('#wl-dv-msg');
        const r = await drainOutbox(t => { msg.innerHTML = `<span class="muted">${esc(t)}</span>`; });
        paint();
        const fresh = host.querySelector('#wl-dv-msg');
        if (fresh) {
          fresh.innerHTML = r.done
            ? `<span class="good">✓ ${r.done} copied to Drive.</span>${r.failed ? ` <span class="bad">${r.failed} would not upload.</span>` : ''}${
                r.gone ? ` <span class="muted tiny">${r.gone} had already been swept.</span>` : ''}`
            : `<span class="muted">Nothing could be copied${r.gone ? ` — ${r.gone} past their 24 hours` : ''}${
                r.failed ? `, ${r.failed} refused` : ''}.</span>`;
        }
      });
      host.querySelector('#wl-dv-clear')?.addEventListener('click', () => {
        if (!confirm('Forget the list of recordings that did not reach Drive? The recordings themselves are not affected.')) return;
        Drive.forgetAll(); paint();
      });

      /* CATCHING UP ON WHAT WAS MARKED BEFORE THE FOLDER EXISTED.

         The Drive copy is made at marking time, so a station marked an hour
         before connecting was never sent anywhere — and its tape is still
         sitting on the server with most of its 24 hours left. Leaving that
         to expire because of an accident of ordering is a waste of the one
         thing that cannot be recreated.

         Only attempts from the last 24 hours are even looked at, and only
         those with a stored path and no Drive record: everything else is
         skipped without a request. */
      host.querySelector('#wl-dv-back')?.addEventListener('click', async e => {
        const msg = host.querySelector('#wl-dv-msg');
        e.target.disabled = true;
        msg.innerHTML = '<span class="muted">Looking for recordings still on the server…</span>';
        try {
          const since = Date.now() - 24 * 3600e3;
          const recent = [];
          for (const [list, kind] of [[await Backend.listOsceAttempts().catch(() => []), 'osce'],
                                      [await Backend.listCaseAttempts().catch(() => []), 'case']]) {
            (list || []).forEach(r => { if ((r.created || 0) >= since) recent.push({ id: r.id, kind, topic: r.topic }); });
          }
          if (!recent.length) {
            msg.innerHTML = '<span class="muted">Nothing sat in the last 24 hours — there is nothing left to pick up.</span>';
            e.target.disabled = false; return;
          }
          let done = 0, skipped = 0, failed = 0;
          for (let i = 0; i < recent.length; i++) {
            msg.innerHTML = `<span class="muted">Checking ${i + 1} of ${recent.length}…</span>`;
            const a = recent[i].kind === 'osce'
              ? await Backend.getOsceAttempt(recent[i].id).catch(() => null)
              : await Backend.getCaseAttempt(recent[i].id).catch(() => null);
            if (!a || !a.audioPath || a.drive) { skipped++; continue; }
            let url = null;
            try {
              url = recent[i].kind === 'osce'
                ? await Backend.getOsceAudioUrl(a.audioPath)
                : await Backend.getCaseAudioUrl(a.audioPath);
            } catch {}
            if (!url) { skipped++; continue; }        // already swept
            try {
              const blob = await (await fetch(url)).blob();
              const label = (recent[i].kind === 'case' ? 'CASE — ' : '') + (a.station?.topic || a.case?.topic || recent[i].topic || 'Recording');
              const ext = /mp4|aac/.test(blob.type || '') ? 'm4a' : 'webm';
              const up = await Drive.upload(blob, Drive.nameFor(label, a.created || Date.now(), ext),
                { description: 'AUREUM — copied up after connecting Drive' });
              if (!up) { failed++; continue; }
              a.drive = { id: up.id, link: up.link, name: up.name };
              if (recent[i].kind === 'osce') await Backend.saveOsceAttempt(a).catch(() => {});
              else await Backend.saveCaseAttempt(a).catch(() => {});
              done++;
            } catch { failed++; }
          }
          const summary = done
            ? `<span class="good">✓ ${done} recording${done === 1 ? '' : 's'} copied to Drive.</span>`
              + (failed ? ` <span class="bad">${failed} would not upload.</span>` : '')
              + (skipped ? ` <span class="muted tiny">${skipped} already there or already swept.</span>` : '')
            : `<span class="muted">Nothing to copy — ${skipped} already in Drive or past their 24 hours${
                failed ? `, ${failed} would not upload` : ''}.</span>`;
          /* paint() rebuilds the whole panel, message box included, so the
             repaint has to happen BEFORE the summary is written or the
             result of the press disappears the instant it appears. */
          paint();
          const fresh = host.querySelector('#wl-dv-msg');
          if (fresh) fresh.innerHTML = summary;
          return;                       // the button was replaced by paint()
        } catch (err) {
          msg.innerHTML = `<span class="bad">${esc(err.message || err)}</span>`;
        }
        e.target.disabled = false;
      });
    };
    paint();
    Drive.onChange(() => { if (host.isConnected) paint(); });
  }

  /* ---------------- sending credit to another user ----------------
     Two steps on purpose. The first resolves the number to a NAME and
     shows it; only then does the button become one that moves money.
     Typing 10024 for 10042 is the easiest mistake in the world to make,
     and a transfer cannot be taken back — so the name is shown before
     anything happens, not after.

     The balance is checked on the server, not here. This page could be
     made to say anything. */
  function wireSend(view, s, user) {
    const btn = view.querySelector('#wl-send-go');
    const out = view.querySelector('#wl-send-out');
    if (!btn) return;
    const toEl = view.querySelector('#wl-to');
    const amtEl = view.querySelector('#wl-amt');
    const noteEl = view.querySelector('#wl-note');
    let confirmed = null;                 // the number whose name is on screen

    const reset = () => { confirmed = null; btn.textContent = 'Check the name'; btn.classList.remove('is-armed'); };
    [toEl, amtEl].forEach(el => el.addEventListener('input', () => { if (confirmed) { reset(); out.innerHTML = ''; } }));

    const call = async (action, extra) => {
      const token = await Backend.getAccessToken();
      if (!token) throw new Error('Sign in first.');
      const res = await fetch(cfg().ai.apiBase, {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
        body: JSON.stringify(Object.assign({ action, to: toEl.value }, extra))
      });
      const d = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(d.error || `That did not work (HTTP ${res.status}).`);
      return d;
    };

    btn.addEventListener('click', async () => {
      const amount = Number(amtEl.value);
      const to = String(toEl.value).replace(/\D/g, '');
      if (!to) { out.innerHTML = '<p class="bad">Enter the number you are sending to.</p>'; return; }
      if (!(amount > 0)) { out.innerHTML = '<p class="bad">Enter an amount.</p>'; return; }
      /* The balance is only in the way of the SEND. Looking up whose number
         this is costs nothing and is worth doing at any balance — being
         told "you cannot afford it" when all you asked was "who is 10042?"
         is an answer to a question nobody asked. The server checks the
         balance again regardless; this is only to fail early. */
      if (confirmed === to && amount > (s.balanceLkr || 0)) {
        out.innerHTML = `<p class="bad">That is more than your balance of ${lkr(s.balanceLkr)}.</p>`; return;
      }
      btn.disabled = true;
      try {
        if (confirmed !== to) {
          const q = await call('quotecredit');
          confirmed = to;
          btn.textContent = `Send ${lkr(amount)} to ${q.to.name}`;
          btn.classList.add('is-armed');
          out.innerHTML = `<p class="wl-send-who">Number <code>${esc(q.to.no)}</code> is
            <strong>${esc(q.to.name)}</strong>. If that is the right person, press the button again to send
            ${lkr(amount)}. <span class="muted">A transfer cannot be reversed from here.</span></p>`;
        } else {
          const r = await call('sendcredit', { amount, note: noteEl.value });
          out.innerHTML = `<p class="good">✓ ${lkr(r.amount)} sent to ${esc(r.to.name)} (${esc(r.to.no)}).
            Your balance is now ${lkr(r.balance)}.</p>`;
          toEl.value = ''; amtEl.value = ''; noteEl.value = '';
          reset(); bust();
          // redraw so the passbook and the balance show the debit at once
          setTimeout(() => renderBilling(view, user), 1400);
        }
      } catch (e) {
        out.innerHTML = `<p class="bad">${esc(e.message || e)}</p>`;
        reset();
      }
      btn.disabled = false;
    });
  }

  /* ---------------- dialogs ---------------- */

  function modal(label, inner, cls) {
    document.querySelector('.wl-modal')?.remove();
    const wrap = document.createElement('div');
    wrap.className = 'os-modal wl-modal ' + (cls || '');
    wrap.innerHTML = `<div class="os-modal-back" data-close></div>
      <div class="os-modal-box" role="dialog" aria-modal="true" aria-label="${esc(label)}">${inner}</div>`;
    document.body.appendChild(wrap);
    const shut = () => { wrap.remove(); document.removeEventListener('keydown', onKey); };
    const onKey = e => { if (e.key === 'Escape') shut(); };
    document.addEventListener('keydown', onKey);
    wrap.querySelectorAll('[data-close]').forEach(b => b.addEventListener('click', shut));
    return { wrap, shut };
  }

  /** Who to pay, in full — the thing you actually type into a banking app. */
  function billingDetails(ben) {
    const rows = [['Account number', ben.account], ['Account name', ben.name], ['Bank', ben.bank]]
      .filter(r => r[1]);
    const { wrap } = modal('Billing details', `
      <div class="os-modal-head">
        <div><p class="kicker">PAY INTO</p><h3>Billing details</h3></div>
        <button class="os-modal-x" data-close aria-label="Close">✕</button>
      </div>
      <div class="os-modal-body">
        <dl class="wl-bd">${rows.map(([k, v]) => `
          <div class="wl-bd-row">
            <dt>${esc(k)}</dt>
            <dd><span class="wl-bd-v">${esc(v)}</span>
              <button class="link-btn" data-copy="${esc(v)}">copy</button></dd>
          </div>`).join('')}</dl>
        <p class="muted tiny">Put your user number in the <strong>remark / reference</strong> field of the transfer —
          without it the payment cannot be matched to your account, and it will wait for the site owner instead of
          crediting straight away.</p>
      </div>
      <div class="os-modal-foot"><button class="btn btn-ghost btn-sm" data-close>Close</button></div>`);
    wrap.addEventListener('click', async e => {
      const b = e.target.closest('[data-copy]'); if (!b) return;
      try { await navigator.clipboard.writeText(b.dataset.copy); const t = b.textContent; b.textContent = '✓ copied';
        setTimeout(() => b.textContent = t, 1400); } catch { /* clipboard refused; the number is on screen anyway */ }
    });
  }

  /* Every credit and debit, newest first, with a running balance — the same
     shape as a bank passbook.

     One honest limitation is written on the page rather than papered over:
     top-ups carry a real timestamp, but AI spend is metered per day × model ×
     feature, not per call, so a debit line is that day's total for one
     mechanism and has a date without a time. Inventing a time would make the
     statement look more precise than the meter behind it. */
  function passbook(s) {
    const entries = [];
    (s.topUps || []).forEach(t => {
      if (t.status === 'declined') return;
      const when = new Date(t.created_at || Date.now());
      entries.push({ at: when.getTime(), timed: true, credit: Number(t.amount_lkr) || 0, debit: 0,
        title: t.extracted?.manual ? 'Credit added by the site owner' : 'Top-up',
        detail: [t.reference && t.reference !== 'manual' ? 'ref ' + t.reference : '',
                 t.extracted?.bank || '', t.extracted?.txnId ? 'txn ' + t.extracted.txnId : '',
                 t.note || ''].filter(Boolean).join(' · '),
        state: t.status === 'pending' ? 'pending'
             : (t.extracted?.provisional && !t.extracted?.confirmed) ? 'provisional' : '' });
    });
    (s.usage || []).forEach(r => {
      const cost = (typeof Billing !== 'undefined' ? Billing.lineCost(r) : 0) * s.rate;
      if (!(cost > 0)) return;
      entries.push({ at: new Date(r.day + 'T23:59:59').getTime(), timed: false, credit: 0, debit: cost,
        title: (typeof Billing !== 'undefined' ? Billing.featureIcon(r.feature) + ' ' + Billing.featureLabel(r.feature) : r.feature),
        detail: `${r.calls} call${r.calls === 1 ? '' : 's'} · ${(r.inputTokens + r.outputTokens).toLocaleString('en-US')} tokens · ${r.model}` });
    });
    entries.sort((a, b) => a.at - b.at);

    // a running balance only makes sense forwards; the table then reads newest first
    let bal = 0;
    entries.forEach(e => { if (e.state !== 'pending') bal += e.credit - e.debit; e.balance = bal; });
    const rows = entries.slice().reverse();
    const fmt = e => {
      const d = new Date(e.at);
      return e.timed
        ? d.toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' })
        : d.toLocaleDateString('en-GB', { dateStyle: 'medium' });
    };

    modal('Statement', `
      <div class="os-modal-head">
        <div><p class="kicker">EVERY CREDIT AND DEBIT</p><h3>Statement</h3>
          <p class="muted tiny">${rows.length} entr${rows.length === 1 ? 'y' : 'ies'} ·
            topped up ${lkr(s.creditedLkr)} · used ${lkr(s.spentLkr)} · balance ${lkr(s.balanceLkr)}</p></div>
        <button class="os-modal-x" data-close aria-label="Close">✕</button>
      </div>
      <div class="os-modal-body">
        ${rows.length ? `<div class="table-scroll"><table class="table wl-pb">
          <thead><tr><th>Date</th><th>Detail</th><th class="num">Credit</th><th class="num">Debit</th><th class="num">Balance</th></tr></thead>
          <tbody>${rows.map(e => `
            <tr class="${e.state || ''}">
              <td class="muted nowrap">${esc(fmt(e))}${e.timed ? '' : '<span class="wl-pb-day">day total</span>'}</td>
              <td><strong>${esc(e.title)}</strong>${e.detail ? `<span class="wl-pb-d">${esc(e.detail)}</span>` : ''}
                ${e.state === 'pending' ? '<span class="wl-pb-tag">awaiting approval — not in the balance</span>' : ''}
                ${e.state === 'provisional' ? '<span class="wl-pb-tag gold">credited, owner still to confirm</span>' : ''}</td>
              <td class="num good">${e.credit ? lkr(e.credit) : ''}</td>
              <td class="num bad">${e.debit ? lkr(e.debit) : ''}</td>
              <td class="num"><strong>${lkr(e.balance)}</strong></td>
            </tr>`).join('')}</tbody>
        </table></div>` : `<p class="muted">Nothing has gone in or out yet.</p>`}
        <p class="muted tiny">AI usage is metered per day for each mechanism, so a debit line is that day's total for
          it and carries a date rather than a time. Top-ups carry the exact moment they arrived.</p>
      </div>
      <div class="os-modal-foot"><button class="btn btn-ghost btn-sm" data-close>Close</button></div>`, 'wl-pb-modal');
  }

  function showSlip(host, f, preview, usage, user, view, verdict) {
    const amt = Number(f.amount) || 0;
    const cur = String(f.currency || 'LKR').toUpperCase();
    const myRef = userNo(user);
    const v = verdict || {};
    const cost = `<p class="muted tiny">Reading this slip cost ${((usage.in || 0) + (usage.out || 0)).toLocaleString('en-US')} tokens
      — added to your usage as a handling fee.</p>`;

    /* Credited already. Nothing to submit, nothing to correct — the server
       read the account, the amount, the date and the reference off the image
       itself and wrote the credit before this page was drawn. */
    if (v.credited) {
      const by = v.confirmBy ? new Date(v.confirmBy) : null;
      host.innerHTML = `
        <div class="wl-slip wl-slip-done" data-animate>
          <div class="wl-slip-img">${/^data:image/.test(preview) ? `<img src="${preview}" alt="The slip you uploaded">` : '<span>PDF</span>'}</div>
          <div class="wl-slip-fields">
            <p class="wl-instant">⚡ Topped up ${lkr(amt)} — your balance is live now</p>
            <p class="muted">This slip named the account, the amount, the date and your reference
              <code>${esc(myRef)}</code>, so it was credited without waiting.
              ${by ? `The site owner confirms it against the bank statement by
                <strong>${esc(by.toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' }))}</strong>.` : ''}</p>
            <div class="wl-read">
              ${[['Paid to', f.payee], ['Account', f.accountTo], ['Date', f.date], ['Bank', f.bank], ['Transaction', f.txnId]]
                .filter(x => x[1]).map(([k, val]) => `<span><b>${k}</b> ${esc(val)}</span>`).join('')}
            </div>
            ${cost}
          </div>
        </div>`;
      bust();
      setTimeout(() => renderBilling(view, user), 2400);
      return;
    }

    /* Not credited: say exactly which of the four things was missing, then
       fall back to the approval queue that has always been there. */
    const m = v.match || null;
    const rows = m
      ? [['Paid into ' + (v.beneficiary || 'the right account'), m.account],
         ['An amount', m.amount], ['A transfer date', m.date],
         [`Your reference (${myRef})`, m.reference]]
      : [];
    const why = { off: 'Instant top-up is switched off at the moment.',
      'no-account': 'The site owner has not set the account number yet.',
      'not-configured': 'Instant top-up is not finished being set up on the server.',
      duplicate: 'This slip has already been used — the same transfer cannot be credited twice.',
      'day-limit': 'You have reached the limit for top-ups credited without a check today. This one still goes through once the site owner approves it.',
      screened: '' }[v.reason];
    // when the screening stopped it, the reasons ARE the explanation
    const blockers = (v.flags || []).filter(x => x.level === 'block');

    const warn = [];
    if (cur !== 'LKR') warn.push(`The slip says <strong>${esc(cur)}</strong>, not rupees — check the amount before submitting.`);
    if (!amt) warn.push('No amount could be read — type it in.');
    if ((f.confidence || 0) < 0.5) warn.push('This does not look like a completed payment slip.');

    /* The amount is whatever the SLIP says, and is not editable. Letting it
       be typed meant a 100-rupee transfer could be submitted as 10,000 and
       the approver had to catch it by eye. If nothing could be read it has to
       be typed, and that is recorded so the developer's queue can say so. */
    host.innerHTML = `
      <div class="wl-slip" data-animate>
        <div class="wl-slip-img">${/^data:image/.test(preview) ? `<img src="${preview}" alt="The slip you uploaded">` : '<span>PDF</span>'}</div>
        <div class="wl-slip-fields">
          <h4>What was read from the slip</h4>
          ${amt ? `<div class="wl-f wl-fixed"><span>Amount</span>
            <strong class="wl-amt-n">${lkr(amt)}</strong>
            <span class="muted tiny">read from the slip — it cannot be changed here. If it is wrong, upload the right slip.</span>
          </div><input type="hidden" id="wl-amt" value="${amt}">`
          : `<label class="wl-f"><span>Amount (LKR) — none could be read from this slip</span>
              <input type="number" id="wl-amt" value="" min="1" step="0.01"></label>
             <p class="muted tiny">Type what you actually paid. The site owner checks it against the slip before it is
               credited, so an amount that does not match will be declined.</p>`}
          <label class="wl-f"><span>Your reference / remark</span><input type="text" id="wl-ref" value="${esc(f.reference || '')}" placeholder="${esc(myRef)}"></label>
          <div class="wl-read">
            ${[['Paid to', f.payee], ['Account', f.accountTo], ['Date', f.date], ['Bank', f.bank],
               ['Transaction', f.txnId], ['Status', f.status]]
              .filter(x => x[1]).map(([k, val]) => `<span><b>${k}</b> ${esc(val)}</span>`).join('')}
          </div>
          ${rows.length || why || blockers.length ? `<div class="wl-check">
            <p class="wl-check-h">This one needs the owner's approval</p>
            ${rows.length ? `<ul class="wl-check-list">${rows.map(([label, ok]) =>
              `<li class="${ok ? 'ok' : 'no'}"><span>${ok ? '✓' : '○'}</span>${esc(label)}</li>`).join('')}</ul>` : ''}
            ${blockers.length ? `<ul class="wl-check-list wl-blockers">${blockers.map(b =>
              `<li class="no"><span>!</span>${esc(b.text)}</li>`).join('')}</ul>` : ''}
            <p class="muted tiny">${why ? esc(why)
              : blockers.length ? 'Nothing is lost — the site owner checks it against the bank statement and credits it by hand.'
              : `A slip showing all four is topped up the moment you upload it. Correcting a field here does not change that —
                 the check is made on the image itself, not on what is typed.`}</p>
          </div>` : ''}
          ${warn.length ? `<p class="wl-warn">⚠ ${warn.join(' ')}</p>` : ''}
          ${cost}
          <button class="btn btn-gold" id="wl-submit">Send for approval</button>
          <p class="dev-row-msg" id="wl-msg"></p>
        </div>
      </div>`;

    host.querySelector('#wl-submit').addEventListener('click', async e => {
      const amount = Number(host.querySelector('#wl-amt').value);
      const reference = host.querySelector('#wl-ref').value.trim();
      const msg = host.querySelector('#wl-msg');
      if (!(amount > 0)) { msg.textContent = 'Enter the amount you paid.'; msg.className = 'dev-row-msg bad'; return; }
      e.target.disabled = true; msg.textContent = 'Sending…'; msg.className = 'dev-row-msg muted';
      try {
        await Backend.createTopUp({
          amount_lkr: amount, reference: reference || myRef,
          slip: preview.length < 700000 ? preview : null,   // keep small slips for the approver to see
          extracted: Object.assign({}, f, m ? { matched: m, beneficiary: v.beneficiary } : null,
            // the screening the server already did travels with the row, so
            // the approver sees why this one did not credit itself
            { risk: v.risk || '', flags: v.flags || [], autoReason: v.reason || '' },
            // an amount the reader could not find, and the payer typed, is the
            // one number on the row that nothing has checked — say so
            amt ? null : { amountTyped: amount }),
          status: 'pending'
        });
        bust();
        msg.textContent = '✓ Sent. You will see the balance once it is approved.';
        msg.className = 'dev-row-msg good';
        setTimeout(() => renderBilling(view, user), 1200);
      } catch (err) { msg.textContent = err.message || String(err); msg.className = 'dev-row-msg bad'; e.target.disabled = false; }
    });
  }

  /* A compact balance strip for the Profile page. */
  async function badge() {
    try {
      const s = await summary();
      return { balanceLkr: s.balanceLkr, text: lkr(s.balanceLkr), empty: s.balanceLkr <= 0 };
    } catch { return null; }
  }

  return { rate, loadRate, bustRate, settings, summary, bust, canSpend, blockedMessage, charge,
    guard, nudge, emptyPopup, balances, balanceFrom, enforcing,
    readSlip, renderBilling, badge, lkr, userNo, DEFAULT_RATE,
    beneficiary, instantOn, instantHours, slipCheck, slipComplete, sameAccount };
})();
