/* ============================================================
   osce.js — spoken OSCE stations.

   A station is one 15-minute viva: a scenario, then six or so
   questions worth 50 marks in total, with a marking scheme behind
   each. Source JSON is `ogr-osce-v1` (the shape the station files
   already use), published by the developer like papers and CPD.

   How a station runs
     1. BRIEF   — the scenario, on screen, untimed. The examiner's
        reading allowance is shown as guidance, not enforced: you
        press "Start the station" when you have read it.
     2. STATION — the 15-minute clock starts, the microphone starts,
        and question 1 appears. You SPEAK your answer; "Next" moves
        on. The clock never stops for the questions — that is the
        point of the exercise.
     3. DEBRIEF — the recording is offered as a download, every
        answer is transcribed on screen, and the whole thing can be
        marked against the scheme.

   Speech
     The live transcript uses the browser's own recogniser, which
     costs nothing. The audio is captured separately by MediaRecorder
     so you always get the tape even where recognition is unavailable
     (older Safari) — and where it is, the transcript is editable
     before marking, because no recogniser is perfect on drug names.

   Pausing
     Real life interrupts. Pause stops the clock and the recorder;
     resume continues both. The station's state (elapsed, answers,
     transcripts) is saved after every step, so closing the tab and
     coming back resumes where you were — the audio, which cannot
     survive a reload, starts a fresh track and is offered separately.
   ============================================================ */

const OSCE = (() => {
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const cfg = () => window.AUREUM_CONFIG || {};
  const KEY = 'osce-stations';
  const TTL = 15 * 60 * 1000;

  /* ---------------- data ---------------- */

  async function stations() {
    const loader = () => Backend.getOsceStations().then(r => r || []);
    const list = (typeof Cache !== 'undefined')
      ? await Cache.wrap(KEY, TTL, loader, { keepIfEmptied: true })
      : await loader();
    return list.slice().sort((a, b) => String(a.topic || '').localeCompare(String(b.topic || '')));
  }
  function bustStations() { if (typeof Cache !== 'undefined') Cache.bust(KEY); }

  /* ---------------- YOUR OWN ROWS, READ ONCE ----------------

     Supabase bills egress — bytes leaving the database — and the free tier
     is not generous. listOsceAttempts() was being called from EIGHT places:
     the bank, a station page, My attempts, the simulator, the progress
     page, the study documents page, twice more inside the report. Opening
     the OSCE tab and clicking through it pulled your whole attempt history
     five or six times in a minute, and it grows with every station you sit.

     It is also the easiest thing in the app to cache correctly, because
     there is exactly one writer: you. Nobody else can add to your attempts,
     so the cache cannot go stale behind your back — it only has to be
     dropped when YOU write, which is a handful of call sites rather than a
     guess about other people.

     Ten minutes, and busted on every write. */
  const ATT_KEY = 'osce-attempts', ATT_TTL = 10 * 60 * 1000;
  async function myAttempts() {
    const loader = () => Backend.listOsceAttempts().then(r => r || []);
    if (typeof Cache === 'undefined') return loader();
    return await Cache.wrap(ATT_KEY, ATT_TTL, loader, { keepIfEmptied: true });
  }
  function bustAttempts() { if (typeof Cache !== 'undefined') Cache.bust(ATT_KEY); }

  /* INVALIDATION THAT CANNOT BE FORGOTTEN.

     Calling bustAttempts() by hand at each write site works right up until
     somebody adds a write and does not — and the failure is silent and
     confusing: a station you have just sat still counts as unsat, the
     fresh-only tick offers it again, and nothing anywhere says why.

     So the two writers are wrapped once, here. Any caller at all — this
     file, the marksheet, a test, whatever gets written next year — drops
     the cache by writing, because writing is what makes it stale. */
  (function guardAttemptCache() {
    if (typeof Backend === 'undefined' || Backend.__attCacheGuarded) return;
    Backend.__attCacheGuarded = true;
    ['saveOsceAttempt', 'deleteOsceAttempt'].forEach(fn => {
      const real = Backend[fn];
      if (typeof real !== 'function') return;
      Backend[fn] = async function (...args) {
        try { return await real.apply(Backend, args); }
        finally { bustAttempts(); }
      };
    });
  })();

  const DECK_KEY = 'osce-decks';
  async function decks() {
    const loader = () => Backend.listOsceDecks().then(r => r || []);
    if (typeof Cache === 'undefined') return loader();
    return await Cache.wrap(DECK_KEY, ATT_TTL, loader, { keepIfEmptied: true });
  }
  function bustDecks() { if (typeof Cache !== 'undefined') Cache.bust(DECK_KEY); }
  /* The bank list holds CARDS — no questions, no marking points — so opening
     the tab costs a few KB however big the bank grows. A station's questions
     are fetched only when that station is actually opened. */
  const fullCache = new Map();
  async function station(id) {
    if (fullCache.has(id)) return fullCache.get(id);
    let st = null;
    try { st = await Backend.getOsceStation(id); } catch {}
    if (!st) st = (await stations().catch(() => [])).find(x => x.id === id) || null;
    if (st) fullCache.set(id, st);
    return st;
  }
  /* ---------------- collections (the bins a station lives in) ----------------
     A station's bin is one string in its record, so filing costs nothing and
     needs no migration. The list of bins is developer-editable and stored
     alongside the other app config; config.js holds the ones every
     deployment starts with. Anything published before bins existed has no
     `collection` and shows as Unfiled until it is moved. */
  const COLL_KEY = 'osce-collections';
  const UNFILED = { id: '', label: 'Unfiled' };

  /* MERGE, DO NOT REPLACE.

     The saved list used to win outright, which was fine while config.js only
     ever supplied a starting set. It stops being fine the moment a release
     ships a NEW bin: the developer has already saved a list, that list has no
     bin the release just added, and the bin simply never appears — with
     nothing anywhere to say why. Created OSCE is exactly that case.

     So the two lists are merged by id. The saved row wins on label and
     priority, because those are the developer's edits and a release must not
     undo them; a shipped bin the saved list has never heard of is appended.
     Removing a bin is still possible — it is done by saving a list, and a
     shipped bin is only re-added if it is not there under that id at all. */
  function mergeColls(saved, shipped) {
    const out = (saved || []).slice();
    const have = new Set(out.map(c => c.id));
    (shipped || []).forEach(c => { if (!have.has(c.id)) out.push(Object.assign({}, c)); });
    return out;
  }
  let _colls = null;
  async function collections() {
    if (_colls) return _colls;
    const fallback = (cfg().osce?.collections || []).slice();
    try {
      const saved = (typeof Cache !== 'undefined')
        ? await Cache.wrap(COLL_KEY, TTL, () => Backend.getOsceCollections(), { keepIfEmptied: true })
        : await Backend.getOsceCollections();
      _colls = (saved && saved.length) ? mergeColls(saved, fallback) : fallback;
    } catch { _colls = fallback; }
    return _colls;
  }
  /** The bin candidates may write into. One place, so nothing hard-codes it. */
  const createdId = () => cfg().osce?.createdCollection || 'created';
  function bustCollections() { _colls = null; if (typeof Cache !== 'undefined') Cache.bust(COLL_KEY); }
  const collLabel = (list, id) => (list.find(c => c.id === id) || (id ? { label: id } : UNFILED)).label;

  /* ---------------- images on a question ----------------
     A CTG, a partogram, a scan. The FILES live in storage — the question
     carries a path and a URL, never the bytes, so a station full of pictures
     costs the bank list exactly nothing. Older stations imported from JSON
     may carry a bare URL instead, which works the same way.

     They are shown at a readable size and open full-screen on a click,
     because half of what a CTG station tests is whether you can actually
     read the trace. */
  const imagesOf = q => (q.images || []).map(im => ({
    url: im.url || (typeof Backend !== 'undefined' && Backend.osceImageUrl ? Backend.osceImageUrl(im.path) : im.path) || '',
    caption: im.caption || ''
  })).filter(im => im.url);

  function imageStrip(q, cls) {
    const ims = imagesOf(q);
    if (!ims.length) return '';
    return `<div class="os-imgs ${cls || ''} ${ims.length > 1 ? 'is-many' : ''}">
      ${ims.map(im => `
        <figure class="os-img">
          <button class="os-img-b" data-zoom="${esc(im.url)}" data-cap="${esc(im.caption)}"
            aria-label="${esc(im.caption || 'Enlarge the image')}">
            <img src="${esc(im.url)}" alt="${esc(im.caption || 'Image shown with this question')}" loading="lazy">
            <span class="os-img-zoom">⤢</span>
          </button>
          ${im.caption ? `<figcaption>${esc(im.caption)}</figcaption>` : ''}
        </figure>`).join('')}
    </div>`;
  }

  /** Full-screen, pannable when zoomed. One delegated listener per host. */
  function wireLightbox(host) {
    if (!host || host.dataset.lb === '1') return;
    host.dataset.lb = '1';
    host.addEventListener('click', e => {
      const b = e.target.closest('[data-zoom]'); if (!b) return;
      e.preventDefault();
      document.querySelector('.os-lightbox')?.remove();
      const box = document.createElement('div');
      box.className = 'os-lightbox';
      box.innerHTML = `
        <button class="os-lb-x" aria-label="Close">✕</button>
        <div class="os-lb-stage"><img src="${esc(b.dataset.zoom)}" alt="${esc(b.dataset.cap || '')}"></div>
        ${b.dataset.cap ? `<p class="os-lb-cap">${esc(b.dataset.cap)}</p>` : ''}
        <p class="os-lb-hint">Click the image to zoom · Esc to close</p>`;
      document.body.appendChild(box);
      const img = box.querySelector('img');
      img.addEventListener('click', ev => { ev.stopPropagation(); img.classList.toggle('is-big'); });
      const shut = () => { box.remove(); document.removeEventListener('keydown', onKey); };
      const onKey = ev => { if (ev.key === 'Escape') shut(); };
      document.addEventListener('keydown', onKey);
      box.addEventListener('click', ev => { if (ev.target === box || ev.target.closest('.os-lb-x')) shut(); });
    });
  }

  const qsOf = st => st.questions || [];
  const qCount = st => st.q_count != null ? st.q_count : qsOf(st).length;
  /* ---------------- headings inside a scheme ----------------

     A long scheme wants sections — "History", "Investigations",
     "Counselling" — and an examiner asked for them. The temptation is to
     give marking_points a richer shape, an array of objects with a type.
     That would touch the manual sheet, the AI prompt, the report, the
     print, the importer and every station already stored, and would break
     the last of those.

     So a heading is a marking point whose text begins with "# ". It stays
     a string in the same array, every existing station keeps working, and
     the only rule anything has to learn is this one:

       A HEADING IS NEVER WORTH MARKS.

     Which matters, because the marks for a question are divided equally
     between its points — a heading that counted would quietly take a
     share of the marks away from the real ones. */
  const HEAD_RE = /^\s*#\s+/;
  const isHeading = p => HEAD_RE.test(String(p == null ? '' : p));
  const headText = p => String(p == null ? '' : p).replace(HEAD_RE, '').trim();
  /** The points that actually carry marks. */
  const scorable = pts => (pts || []).filter(p => !isHeading(p));

  /* MATCHING A MARKING BACK TO ITS QUESTION.

     Station ids come from whatever JSON built the station — plain numbers
     from one importer, "Q1" strings from another — and a marking that came
     back from somewhere else uses whichever it happened to see. An exact
     lookup therefore misses silently, and the report draws four questions
     with no question on them, which is what a real Claude-marked station
     looked like.

     So: compare loosely, and fall back to position. Position is a genuine
     fallback here rather than a guess, because a marking lists the
     questions in the order it was asked them. */
  const qKey = v => String(v == null ? '' : v).trim().toLowerCase().replace(/^q[\s._-]*/, '');
  function questionFor(list, id, index) {
    const l = list || [];
    const want = qKey(id);
    return (want && l.find(q => qKey(q.id) === want)) || l[index] || {};
  }

  const ptCount = st => st.points_count != null ? st.points_count : qsOf(st).reduce((n, q) => n + scorable(q.marking_points).length, 0);
  const marksOf = st => st.total_marks || qsOf(st).reduce((n, q) => n + (q.marks || 0), 0) || 50;
  const passOf = st => st.pass_mark != null ? st.pass_mark
    : Math.round(marksOf(st) * ((st.pass_mark_percent || 70) / 100));
  const minsOf = st => st.station_time_min || 15;

  /* ---------------- the role player ----------------

     Some stations are not a viva. Somebody plays the woman who has just
     been told her baby has a lethal anomaly, and the candidate has to
     talk to her — and what is being examined is as much the talking as
     the knowledge. Those stations come with an actor brief: who she is,
     how she is when the door opens, what she knows, what she will only
     say if asked the right question, and what she must never volunteer.

     THE BRIEF IS A SECRET ON THE SAME FOOTING AS THE MARKING SCHEME, and
     for a sharper reason. A scheme tells you what the marks are for. A
     brief tells you the answers themselves: read "she is frightened her
     husband will blame her" beforehand and there is nothing left to
     elicit, which is the entire station. So it travels exactly where the
     scheme travels — to the examiner, to Claude, to the mark-by-hand
     sheet, into the printed pack — and exactly nowhere else until the
     station is over.

     IT IS A PLAIN FIELD ON THE STATION, NOT A SECOND KIND OF STATION.
     `role_player` sits beside `questions`. Every station without one is
     untouched, every feature that already works keeps working, and the
     only thing anything new has to learn is `hasRole()`.

     Nothing here invents. The fields are exactly the ones an actor brief
     in a real source document carries, and a field the source is silent
     on is absent rather than filled in — an invented backstory is a
     different station from the one that was written. */

  /* NORMALISED IN THE READER, NOT IN EACH IMPORTER.

     Briefs arrive from a station-writing project, from a hand-edited
     JSON, from a file somebody typed in a hurry — under `role_player`,
     `rolePlayer` or `roleplay`, with `background_facts` sometimes a
     paragraph instead of a list, and `reveal_only_if_asked` sometimes
     `{trigger, reveals}` and sometimes `{if, then}`. Every one of those
     is a station somebody wrote and wants to sit.

     Coercing here means the importer, the editor, the prompt, the sheet
     and the report all see one shape, and a new importer cannot forget
     to do it. The alternative — normalise on the way in — leaves every
     station already stored in whatever shape it happened to arrive in. */
  const roleSrc = st => (st && typeof st === 'object')
    ? (st.role_player || st.rolePlayer || st.roleplay || st.role_play || null) : null;
  const asList = v => {
    if (Array.isArray(v)) return v.map(x => (typeof x === 'string' ? x : String(x?.text ?? x?.fact ?? ''))).filter(x => x.trim());
    const s = String(v == null ? '' : v).trim();
    if (!s) return [];
    // a paragraph of bullet-ish lines is a list somebody typed as prose
    return s.split(/\n+|(?:^|\s)[·•\-–]\s+/).map(x => x.trim()).filter(Boolean);
  };
  function roleOf(st) {
    const raw = roleSrc(st);
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
    const str = v => String(v == null ? '' : v).trim();
    const rev = (Array.isArray(raw.reveal_only_if_asked) ? raw.reveal_only_if_asked
      : Array.isArray(raw.revealOnlyIfAsked) ? raw.revealOnlyIfAsked : [])
      .map(x => (typeof x === 'string'
        ? { trigger: '', reveals: x }
        : { trigger: str(x?.trigger ?? x?.if ?? x?.when), reveals: str(x?.reveals ?? x?.then ?? x?.reveal ?? x?.text) }))
      .filter(x => x.trigger || x.reveals);
    return {
      character_name: str(raw.character_name ?? raw.name),
      character_role: str(raw.character_role ?? raw.role),
      age_and_context: str(raw.age_and_context ?? raw.context),
      opening_state: str(raw.opening_state ?? raw.opening),
      background_facts: asList(raw.background_facts ?? raw.facts),
      reveal_only_if_asked: rev,
      do_not_volunteer: asList(raw.do_not_volunteer ?? raw.doNotVolunteer),
      emotional_arc: asList(raw.emotional_arc ?? raw.arc),
      tone_and_manner: str(raw.tone_and_manner ?? raw.tone)
    };
  }
  const hasRole = st => {
    const r = roleOf(st);
    if (!r) return false;
    return !!(r.character_name || r.character_role || r.opening_state
      || r.background_facts.length || r.reveal_only_if_asked.length);
  };
  /** "Mrs Nadeeka, her partner" — the one line a badge can carry. */
  function roleLabel(st) {
    const r = roleOf(st); if (!r) return '';
    return [r.character_name, r.character_role].filter(Boolean).join(' — ')
      || r.character_role || r.character_name || 'a role player';
  }
  const roleList = v => Array.isArray(v) ? v.filter(x => String(x || '').trim()) : [];

  /**
   * The brief as plain text, for a prompt or a clipboard.
   * Sections the source was silent on are omitted entirely rather than
   * printed empty — an empty heading reads as "there is nothing to know
   * here", which is a different and wrong claim from "this was not
   * written down".
   */
  function roleText(st) {
    const r = roleOf(st); if (!r) return '';
    const L = ['═══ ROLE PLAYER ═══'];
    const kv = (k, v) => { if (String(v || '').trim()) L.push(`${k}: ${String(v).trim()}`); };
    kv('character_name', r.character_name);
    kv('character_role', r.character_role);
    kv('age_and_context', r.age_and_context);
    if (String(r.opening_state || '').trim()) L.push('', 'opening_state: ' + String(r.opening_state).trim());
    const block = (head, items, fn) => {
      const rows = roleList(items); if (!rows.length) return;
      L.push('', head + ':');
      rows.forEach(x => L.push('  - ' + fn(x)));
    };
    block('background_facts', r.background_facts, x => String(x));
    const rev = (r.reveal_only_if_asked || []).filter(x => x && (x.trigger || x.reveals));
    if (rev.length) {
      L.push('', 'reveal_only_if_asked:');
      rev.forEach(x => {
        L.push(`  - trigger: ${String(x.trigger || '').trim()}`);
        L.push(`    reveals: ${String(x.reveals || '').trim()}`);
      });
    }
    block('do_not_volunteer', r.do_not_volunteer, x => String(x));
    block('emotional_arc', r.emotional_arc, x => String(x));
    kv('\ntone_and_manner', r.tone_and_manner);
    return L.join('\n');
  }

  /**
   * The brief as HTML. `mode` decides how loud the secrecy warning is:
   * 'brief'  — the examiner is about to play it, warn hard
   * 'after'  — the station is over, it is teaching now
   */
  function roleHtml(st, mode) {
    const r = roleOf(st); if (!hasRole(st)) return '';
    const rows = (head, items, fn) => {
      const list = roleList(items); if (!list.length) return '';
      return `<div class="os-rp-sec"><h5>${head}</h5><ul>${list.map(x => `<li>${fn(x)}</li>`).join('')}</ul></div>`;
    };
    const rev = (r.reveal_only_if_asked || []).filter(x => x && (x.trigger || x.reveals));
    return `<div class="os-rp is-${mode || 'brief'}">
      <div class="os-rp-head">
        <span class="os-rp-tag">🎭 Role player</span>
        <strong>${esc(roleLabel(st))}</strong>
        ${r.age_and_context ? `<span class="muted tiny">${esc(r.age_and_context)}</span>` : ''}
      </div>
      ${mode === 'after' ? '' : `<p class="os-rp-warn">The candidate must not see any of this. It is the answer sheet
        for the conversation — read out, it is the station.</p>`}
      ${r.opening_state ? `<div class="os-rp-sec"><h5>How the scene opens</h5><p>${esc(r.opening_state)}</p></div>` : ''}
      ${rows('What the character knows', r.background_facts, x => esc(x))}
      ${rev.length ? `<div class="os-rp-sec"><h5>Only if asked</h5>
        <ul class="os-rp-rev">${rev.map(x => `<li>
          <span class="os-rp-trig">${esc(x.trigger || '')}</span>
          <span class="os-rp-rvl">${esc(x.reveals || '')}</span></li>`).join('')}</ul></div>` : ''}
      ${rows('Never volunteer', r.do_not_volunteer, x => esc(x))}
      ${rows('How the character shifts', r.emotional_arc, x => esc(x))}
      ${r.tone_and_manner ? `<div class="os-rp-sec"><h5>Tone and manner</h5><p>${esc(r.tone_and_manner)}</p></div>` : ''}
      <p class="os-rp-foot">Nothing here is marked. The marks come from the scheme${
        mode === 'after' ? '' : ' — unless the scheme itself has a communication section'}.</p>
    </div>`;
  }

  /** 45 → "45 min", 120 → "2 h", 135 → "2 h 15". */
  const hours = mins => mins < 60 ? mins + ' min'
    : (mins % 60 ? `${Math.floor(mins / 60)} h ${mins % 60}` : `${mins / 60} h`);
  const fmt = s => { s = Math.max(0, Math.round(s)); const m = Math.floor(s / 60);
    return `${String(m).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`; };

  /* ---------------- the examiner's voice ----------------
     The browser's own speech synthesiser: free, offline, on every platform
     that matters. Hearing the question read out is most of what makes this
     feel like the real thing rather than a form. */
  const VOICE_KEY = 'aureum.osce.voice';
  const voiceOn = () => { try { return localStorage.getItem(VOICE_KEY) !== '0'; } catch { return true; } };
  const setVoiceOn = v => { try { localStorage.setItem(VOICE_KEY, v ? '1' : '0'); } catch {} };

  /* ---------------- WHICH voice ----------------

     Two are available and they are not simply better and worse.

     The STUDIO voice (Groq) sounds more like a person, and — this is the
     part that is easy to miss — it is the only one that reaches the
     RECORDING directly. The browser's speech synthesiser exposes no
     audio stream that could be mixed into the tape; there is no API for
     it. So with the browser voice the examiner is on the tape only if
     the microphone hears the speaker, which is what the "record the
     examiner's voice too" tick does by turning echo cancellation off.

     The DEVICE voice is instant, free, works with no signal, never
     queues behind a quota, and on a good iPad it is frankly clearer than
     the studio one. That is a real preference and the owner of this site
     holds it, so it is the DEFAULT — and the other is one tap away on
     the brief screen, where the choice is made before the clock starts
     rather than discovered in the middle of a station. */
  const VSRC_KEY = 'aureum.osce.voicesrc';
  const VSRC = { DEVICE: 'device', STUDIO: 'studio' };
  const voiceSrc = () => { try { return localStorage.getItem(VSRC_KEY) === VSRC.STUDIO ? VSRC.STUDIO : VSRC.DEVICE; } catch { return VSRC.DEVICE; } };
  const setVoiceSrc = v => { try { localStorage.setItem(VSRC_KEY, v === VSRC.STUDIO ? VSRC.STUDIO : VSRC.DEVICE); } catch {} };
  /** Is the studio voice wanted AND available? Everything asks this, not groqOn. */
  const studioVoice = () => voiceOn() && voiceSrc() === VSRC.STUDIO && groqOn('voice');

  /* Should the tape carry the examiner as well as the candidate?

     The browser's speech synthesiser gives no audio stream that could be
     mixed into the recording — there is no API for it — so the only way to
     get both voices onto one tape is to let the microphone hear the device
     speaker, which means turning echo cancellation OFF. It works on a phone
     or an iPad speaker; with headphones on there is nothing for the mic to
     hear and only the candidate is recorded.

     The marking prompt is told the examiner may be audible, so nothing said
     in the examiner's voice can be credited to the candidate. */
  /* ---------------- which browser is refusing, and how to fix it ----------------

     iPad Chrome gets the microphone and iPad Safari does not, on the same
     device. Both are WebKit underneath, so this is not an engine limit — it
     is that Chrome asks once at the app level while Safari stores a decision
     PER SITE, and a single "Don't Allow" is remembered forever with no
     further prompt: every call rejects instantly with NotAllowedError.

     Clearing it is not one route. The aA menu shows a Microphone row only
     once the site has asked and only on some versions, so the global setting
     and the nuclear option (delete the site's stored data) both have to be
     offered or somebody is left stuck on a screen telling them to tap
     something that is not there. */
  const iOS = () => /iP(hone|ad|od)/.test(navigator.platform || '')
    || (/Mac/.test(navigator.platform || '') && navigator.maxTouchPoints > 1);
  const iosSafari = () => iOS() && !/CriOS|FxiOS|EdgiOS|OPiOS/i.test(navigator.userAgent);
  const homeScreenApp = () => !!navigator.standalone
    || (window.matchMedia?.('(display-mode: standalone)').matches && iOS());

  function micHelp() {
    if (homeScreenApp()) {
      return ['This is the Home Screen version of AUREUM, and iOS gives web apps launched from the Home Screen ' +
        'no microphone at all on some versions.',
        'Open aureum in Safari itself (or Chrome) and sit the station there.'];
    }
    if (iosSafari()) {
      return ['Safari remembers a “Don’t Allow” for a site and never asks again, so this has to be cleared by hand. ' +
        'Try these in order — the first that offers a Microphone row is the one your iOS version uses:',
        '1. Tap <strong>aA</strong> at the left of the address bar → <strong>Website Settings</strong> → ' +
          '<strong>Microphone</strong> → <strong>Allow</strong>.',
        '2. If there is no Microphone row there: <strong>Settings</strong> app → <strong>Apps</strong> → ' +
          '<strong>Safari</strong> (on iOS 17 and earlier, just <strong>Settings → Safari</strong>) → ' +
          '<strong>Microphone</strong> → set it to <strong>Ask</strong> or <strong>Allow</strong>.',
        '3. Still stuck: <strong>Settings → Safari → Advanced → Website Data</strong>, find this site and swipe to ' +
          'delete it. That clears the stored refusal — you will have to sign in again.',
        'Then reload the page and tap the button below.'];
    }
    return ['Your browser is blocking the microphone for this site. Open the padlock or the site-settings menu ' +
      'beside the address bar and set Microphone to Allow, then reload and tap the button below.'];
  }

  /* ---------------- Groq: a real voice, and real transcription ----------------

     Two mechanical jobs on a free tier — reading the question aloud, and
     turning the recording into words. Neither marks anything.

     Everything here is written so that losing it costs QUALITY and nothing
     else. One flag turns the whole layer off for the rest of the session the
     moment the quota is hit, and the browser's own synthesiser and recogniser
     carry on exactly as they did before. A station must never depend on a
     free tier being awake. */
  let groqOff = false;                       // a fault that will not fix itself
  /* A quota is not a fault — it ends. Groq says when, so a rate limit now
     stands the layer down until that moment instead of for the whole visit:
     a one-minute ceiling used to cost every remaining question in the
     station. Only a wait long enough to outlast the station is treated as
     the end of it. */
  let groqUntil = 0;
  const groqWaiting = () => groqUntil > Date.now();
  const groqBackIn = () => Math.max(0, Math.ceil((groqUntil - Date.now()) / 1000));
  /* WHY it is not being used, kept and shown. A decommissioned model failed
     silently for a day — the 400 was in Groq's own log and nowhere on screen —
     so the reason now travels with the fallback instead of disappearing. */
  const groqSay = { source: 'browser', why: '', model: '' };
  function groqReport() { return Object.assign({}, groqSay, { off: groqOff || groqWaiting(), backIn: groqBackIn() }); }
  /* Once the developer has pinned a working model, the layer should come back
     without anyone having to reload the page. */
  function resetGroq() { groqOff = false; groqUntil = 0; groqSay.source = 'browser'; groqSay.why = ''; groqSay.model = ''; }

  const groqCfg = () => cfg().ai?.groq || {};
  const groqOn = k => !groqOff && !groqWaiting() && groqCfg().enabled !== false && groqCfg()[k] !== false;

  async function groqCall(body) {
    const token = await Backend.getAccessToken();
    if (!token) { groqSay.why = 'not signed in'; return null; }
    let res, data = {};
    try {
      res = await fetch(cfg().ai.apiBase, {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
        body: JSON.stringify(body)
      });
      data = await res.json().catch(() => ({}));
    } catch (e) { groqSay.why = 'the network refused'; return null; }
    if (res.ok) { groqSay.why = ''; return data; }
    groqSay.why = data.error || `HTTP ${res.status}`;
    groqSay.model = data.model || '';
    /* A missing grant, a missing key or a retired model will not come back on
       their own, so the layer stands down for the visit. A quota WILL come
       back: it waits out the reset Groq named and then tries again, unless
       the wait is longer than a station, in which case it is over for now. */
    if (res.status === 429) {
      const wait = Number(data.retryAfter) || 0;
      if (wait > 0 && wait <= 20 * 60) groqUntil = Date.now() + wait * 1000;
      else groqOff = true;
    } else if ([403, 503].includes(res.status) || /decommission|not_found|no .* model/i.test(groqSay.why)) {
      groqOff = true;
    }
    return null;
  }

  /** The examiner's line as playable audio, or null to fall back to the browser. */
  async function groqVoice(text) {
    if (!groqOn('voice') || !text) return null;
    const d = await groqCall({ action: 'tts', text, voice: groqCfg().voiceName || '' });
    if (d?.audio) { groqSay.source = 'groq'; groqSay.model = d.model || ''; }
    return d?.audio ? { data: d.audio, mime: d.mime || 'audio/wav' } : null;
  }

  /** The whole station, transcribed. `hint` biases the spelling of drug names. */
  async function groqTranscribe(blob, hint) {
    if (!groqOn('whisper') || !blob) return null;
    const d = await groqCall({ action: 'transcribe', prompt: hint,
      audio: { mime: blob.type || 'audio/webm', data: await toBase64(blob) } });
    return d?.text ? { text: d.text, model: d.model } : null;
  }

  /* ================= the coaching extras =================

     Marks are one thing; how you SOUNDED is another, and the second is
     what a mock examiner tells you afterwards. These are opt-in for two
     honest reasons: each one lengthens the prompt and so costs money, and
     several of them are only answerable when the model has heard the
     recording. Asking for pronunciation feedback on a typed transcript
     would produce something confident and worthless, so those options
     switch themselves off when there is no audio and say why. */

  const COACH_KEY = 'aureum.osce.coach';
  const COACH = [
    { id: 'delivery', label: 'Delivery and structure',
      note: 'Whether you led with the headline, signposted, and finished each answer instead of trailing off.',
      audio: false },
    { id: 'articulation', label: 'Articulation and clarity',
      note: 'Filler words, half-sentences, thinking aloud, and whether an examiner could follow you first time.',
      audio: true },
    { id: 'pronunciation', label: 'Pronunciation of drug and eponym names',
      note: 'Only the ones that cost you credibility in a viva — and how to say them.',
      audio: true },
    { id: 'pace', label: 'Pace, pauses and timing',
      note: 'Rushing, dead air, and how the fifteen minutes were spent across the questions.',
      audio: true },
    { id: 'technique', label: 'Exam technique for the real day',
      note: 'What to do differently in the room: how to open, how to buy thinking time, how to recover a bad start.',
      audio: false }
  ];
  function coachWanted() {
    try {
      const v = JSON.parse(localStorage.getItem(COACH_KEY) || 'null');
      if (Array.isArray(v)) return v;
    } catch {}
    return ['delivery', 'technique'];              // the two that work without audio
  }
  function setCoachWanted(list) { try { localStorage.setItem(COACH_KEY, JSON.stringify(list)); } catch {} }
  /** Which of the chosen ones are actually answerable for this attempt. */
  const coachFor = (wanted, hasAudio) =>
    COACH.filter(c => wanted.includes(c.id) && (hasAudio || !c.audio)).map(c => c.id);

  function coachPicker(hasAudio) {
    const want = coachWanted();
    return `<div class="os-coach">
      <p class="os-coach-h"><strong>Ask for coaching as well as marks</strong>
        <span class="muted tiny">Each one adds a little to the cost. ${hasAudio
          ? 'The recording is going, so all of them can be answered.'
          : 'Without a recording, only the two that read the transcript can be answered.'}</span></p>
      ${COACH.map(c => {
        const off = c.audio && !hasAudio;
        return `<label class="os-coach-o ${off ? 'is-off' : ''}">
          <input type="checkbox" data-coach="${c.id}" ${want.includes(c.id) && !off ? 'checked' : ''} ${off ? 'disabled' : ''}>
          <span><strong>${esc(c.label)}</strong><br><span class="muted tiny">${esc(c.note)}${
            off ? ' — needs the recording, so it is unavailable for this one.' : ''}</span></span>
        </label>`;
      }).join('')}
    </div>`;
  }
  function wireCoachPicker(host) {
    host.querySelectorAll('[data-coach]').forEach(el => el.addEventListener('change', () => {
      const on = [...host.querySelectorAll('[data-coach]')].filter(x => x.checked).map(x => x.dataset.coach);
      setCoachWanted(on);
    }));
  }

  /* ================= copying a station out =================

     The same idea as "Copy question" on an SBA, with one difference that
     matters: what must be LEFT OUT is bigger here. A station's marking
     scheme IS the answer, in full, point by point — pasting it into
     NotebookLM and asking "what should I have said?" would be asking a
     tool to read back the answer sheet.

     So the scheme never goes, and neither does the candidate's own
     transcript: what they said is not the station, and it would steer
     whatever they ask next. What goes is what an examiner would hand a
     candidate — the scenario, the questions, the marks each carries, and
     what an image showed. Enough for another tool to work the station out
     from first principles, which is the point of asking it. */

  function stationAsText(st, opts = {}) {
    const qs = qsOf(st);
    const L = [];
    L.push(`OSCE STATION — ${st.topic || 'untitled'}`);
    L.push(`${minsOf(st)} minutes · ${qs.length} question${qs.length === 1 ? '' : 's'} · ${marksOf(st)} marks in total`);
    L.push('');
    L.push('SCENARIO');
    L.push(String(st.scenario || '').trim());
    L.push('');
    L.push('QUESTIONS');
    qs.forEach((q, i) => {
      L.push('');
      if (q.reveal_before) L.push(`[New information given at this point: ${q.reveal_before}]`);
      L.push(`${i + 1}. ${String(q.prompt || '').trim()}   (${q.marks} marks)`);
      const ims = imagesOf(q);
      if (ims.length) {
        L.push(`   [The candidate is shown ${ims.length === 1 ? 'an image' : ims.length + ' images'}: ${
          ims.map(im => im.caption || 'no caption').join('; ')}]`);
      }
    });
    if (opts.ask !== false) {
      L.push('');
      L.push('---');
      L.push('This is a station from the Sri Lankan PGIM MD Part II (Obstetrics & Gynaecology) OSCE.');
      L.push('The marking scheme has deliberately not been included.');
      L.push('For each question, work out what a full-mark answer would contain at Part II depth,');
      L.push('with the doses, thresholds and time windows that carry the marks, and cite the');
      L.push('RCOG / NICE / SLCOG guidance behind each. Then say which points a candidate is most');
      L.push('likely to miss under time pressure.');
    }
    return L.filter(x => x != null).join('\n').replace(/\n{3,}/g, '\n\n').trim();
  }

  async function copyOut(text, btn, label) {
    let ok = false;
    try { await navigator.clipboard.writeText(text); ok = true; } catch {}
    if (!ok) {
      try {
        const ta = document.createElement('textarea');
        ta.value = text; ta.setAttribute('readonly', '');
        ta.style.cssText = 'position:fixed;top:-1000px;opacity:0';
        document.body.appendChild(ta); ta.select(); ta.setSelectionRange(0, text.length);
        ok = document.execCommand('copy'); ta.remove();
      } catch {}
    }
    if (!btn) return ok;
    const was = btn.textContent;
    btn.textContent = ok ? '✓ copied' : '✗ could not copy';
    btn.classList.toggle('is-done', ok);
    setTimeout(() => { if (btn.isConnected) { btn.textContent = label || was; btn.classList.remove('is-done'); } }, 2200);
    return ok;
  }

  /* ================= the prompting examiner =================

     A real examiner does not read a question and go silent for four
     minutes. They wait, and when you stop they push: "anything else?",
     "you have covered the diagnosis — what about the monitoring?". That
     pressure is most of what makes the room feel like the room, and it is
     what the earlier version deliberately removed because a fixed "anything
     further?" after every answer told you, for free, that your answer was
     thin. A probe is only honest if it is EARNED — if there really is a
     marking point you have not said.

     So the engine is built on three ideas:

     1. WHAT IS STILL MISSING IS WORKED OUT LOCALLY. Every marking point is
        matched against the running transcript by token overlap. No model,
        no network, no quota — and it runs on every keystroke without
        costing anything. This is the same rules-first principle as the
        blueprint tagger, and here it also means the probing keeps working
        when Groq is rate-limited.

     2. THE MOMENT IS CHOSEN BY SILENCE, not by a timer. The microphone
        level says when the candidate has stopped talking, which is exactly
        when a real examiner interjects. Probing over someone mid-sentence
        would be worse than not probing at all.

     3. THE LEVEL BUYS FREQUENCY AND SHARPNESS. At the bottom it never
        speaks. In the middle it nudges generically, from a pool of lines
        fetched once per station so a nudge costs nothing. At the top it
        asks about the specific point you have missed, which is the only
        part that needs a model — one small call, and only then.

     A probe never names the answer. "What about monitoring?" is a
     legitimate examiner's push; "you forgot magnesium sulphate" hands over
     the mark. The prompt on the server is explicit about that, and the
     generic pool cannot leak anything by construction. */

  const PROMPT_KEY = 'aureum.osce.promptlevel';
  /* `Number(null)` is 0, not NaN. So an untouched browser — which has no
     stored level at all — read as "0", and 0 means SILENT. Every new
     candidate was given an examiner that had been switched off, and the
     default of 35 written just below could never once have been reached.
     Read the raw string first and only then make it a number. */
  function promptLevel() {
    try {
      const raw = localStorage.getItem(PROMPT_KEY);
      if (raw == null || raw === '') return 35;
      const n = Number(raw);
      return Number.isFinite(n) && n >= 0 ? Math.min(100, n) : 35;
    } catch { return 35; }
  }
  function setPromptLevel(n) { try { localStorage.setItem(PROMPT_KEY, String(Math.max(0, Math.min(100, n | 0)))); } catch {} }

  /* HOW LONG A PAUSE IS A PAUSE.

     This used to be derived from the push dial — turn the examiner up and
     it also grew impatient, from fourteen seconds down to five. Two
     different things wearing one control, and the wrong one of them was
     what actually needed adjusting.

     They are separate now. The dial decides how HARD (how many pushes, how
     pointed); this decides how LONG the examiner lets a silence run first.
     Three seconds is the default because that is roughly the pause a real
     examiner tolerates before helping — but someone who thinks in long
     silences can take it to fifteen and never be interrupted. */
  const SILENCE_KEY = 'aureum.osce.silencems';
  const SILENCE_MIN = 1500, SILENCE_MAX = 15000, SILENCE_DEF = 3000;
  function silenceWait() {
    try {
      const n = Number(localStorage.getItem(SILENCE_KEY));
      return Number.isFinite(n) && n >= SILENCE_MIN ? Math.min(SILENCE_MAX, n) : SILENCE_DEF;
    } catch { return SILENCE_DEF; }
  }
  function setSilenceWait(ms) {
    try { localStorage.setItem(SILENCE_KEY, String(Math.max(SILENCE_MIN, Math.min(SILENCE_MAX, ms | 0)))); } catch {}
  }

  /** How the dial translates into behaviour. */
  function promptPlan(level) {
    if (level <= 0) return { off: true, silenceMs: silenceWait() };
    return {
      off: false,
      silenceMs: silenceWait(),
      // at most one nudge per question at the bottom, three at the top
      maxPerQuestion: level < 34 ? 1 : level < 67 ? 2 : 3,
      // how often the nudge is about a SPECIFIC missing point
      pointedChance: level < 34 ? 0 : (level - 33) / 67,
      // never two probes on top of each other
      cooldownMs: Math.max(6000, 16000 - (level / 100) * 9000)
    };
  }

  const PROMPT_WORDS = [
    'Anything else?',
    'What else would you add?',
    'Go on.',
    'Can you expand on that?',
    'Is there anything further?',
    'And?'
  ];

  /* Which marking points the candidate has plausibly said. Token overlap,
     deliberately generous on the point's side and strict on length: a point
     counts as said when most of its significant words have appeared. It is
     not marking — the marker does that properly at the end — it is only
     good enough to decide whether a push is warranted. */
  const STOP = new Set(['the', 'and', 'for', 'with', 'that', 'this', 'from', 'have', 'has', 'was', 'are', 'not',
    'you', 'your', 'her', 'his', 'their', 'any', 'all', 'can', 'may', 'should', 'would', 'must', 'give', 'consider',
    'patient', 'woman', 'mother', 'baby', 'about', 'into', 'onto', 'per', 'via', 'each', 'also', 'other', 'more']);
  const sig = s => String(s || '').toLowerCase().replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/).filter(w => w.length > 3 && !STOP.has(w));

  function saidAlready(point, transcript) {
    const want = sig(point);
    if (!want.length) return true;                 // nothing to look for
    const have = new Set(sig(transcript));
    const hit = want.filter(w => have.has(w)).length;
    return hit / want.length >= 0.6;
  }
  /** The points of one question that have not been covered yet. */
  function missingPoints(q, transcript) {
    return scorable(q.marking_points).filter(p => !saidAlready(p, transcript));
  }

  const BOTH_KEY = 'aureum.osce.bothvoices';
  const examinerOnTape = () => { try { return localStorage.getItem(BOTH_KEY) !== '0'; } catch { return true; } };
  const setExaminerOnTape = v => { try { localStorage.setItem(BOTH_KEY, v ? '1' : '0'); } catch {} };
  const canSpeak = () => typeof speechSynthesis !== 'undefined';

  function speak(text, opts = {}) {
    if (!canSpeak() || !voiceOn() || !text) return;
    try {
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(String(text));
      u.rate = opts.rate || 0.96; u.pitch = opts.pitch || 1; u.lang = 'en-GB';
      // prefer a British voice so it sounds like the examiner, not a satnav
      const v = (speechSynthesis.getVoices() || []).find(x => /en-GB/i.test(x.lang) && !/google/i.test(x.name))
        || (speechSynthesis.getVoices() || []).find(x => /en-GB/i.test(x.lang));
      if (v) u.voice = v;
      speechSynthesis.speak(u);
    } catch {}
  }
  const hush = () => { try { speechSynthesis?.cancel(); } catch {} };

  /* There is deliberately no "Anything further?" here any more.
     A real PGIM examiner asks the question and then waits — the prompting,
     the nudge and the second chance are what a teaching session does, not
     what an examination does. Being asked "is there anything else?" also
     tells you, for free, that the answer was thin, which is a hint the real
     room does not give. The station now reads the question and leaves the
     silence alone; the shortfall shows up where it belongs, in the marks. */

  /* ---------------- which model marks it ---------------- */

  /* Which models can be sent the RECORDING rather than a typed transcript is
     declared per model in config.js, not decided here — see the note beside
     `geminiModels` there. In short: Gemini takes the compressed tape as it
     is; GPT takes audio but only as WAV or MP3, so the browser re-encodes it
     first; Claude's API takes text, images and PDFs and no audio at all, so
     there is nothing to switch on for it. */
  const MODEL_KEY = 'aureum.osce.model';
  function modelChoices() {
    const ai = cfg().ai || {};
    const price = m => { try { const r = Billing.rateFor(m); return { in: r.in || 0, out: r.out || 0 }; } catch { return { in: 0, out: 0 }; } };
    const add = (out, provider, m, fallbackAudio) => out.push({
      key: provider + '|' + m.id, provider, model: m.id, label: m.label, rate: price(m.id),
      audio: m.audio != null ? !!m.audio : fallbackAudio,
      audioFormat: m.audioFormat || '',            // '' = send the recording as recorded
      why: m.why || ''
    });
    const out = [];
    (ai.geminiModels || [{ id: ai.geminiModel, label: 'Gemini Flash-Lite', audio: true }])
      .forEach(m => add(out, 'gemini', m, true));
    (ai.gptModels || (ai.gptModel ? [{ id: ai.gptModel, label: 'GPT' }] : []))
      .forEach(m => add(out, 'gpt', m, false));
    (ai.claudeModels || [{ id: ai.claudeModel || 'claude-haiku-4-5-20251001', label: 'Claude Haiku 4.5' }])
      .forEach(m => add(out, 'claude', m, false));
    // cheapest first, so the price actually informs the choice
    return out.sort((a, b) => (a.rate.in + a.rate.out) - (b.rate.in + b.rate.out));
  }
  /** Why a model cannot be sent the tape — shown instead of a bare "text only". */
  function noAudioReason(choice) {
    if (choice.why) return choice.why;
    if (choice.provider === 'claude') return 'Claude reads text, images and PDFs — its API does not take audio at all.';
    return `${choice.label} is set as text-only in the site configuration.`;
  }
  function chosenModel() {
    const all = modelChoices();
    let k = null; try { k = localStorage.getItem(MODEL_KEY); } catch {}
    /* The list is ordered cheapest-first so the price informs the choice, but
       the DEFAULT is the cheapest model that can actually listen to the
       recording. Defaulting to the cheapest of all would quietly disable the
       accurate route to save a rupee, which is the wrong trade on a station
       that took fifteen minutes to sit. */
    return all.find(m => m.key === k)
      || all.find(m => m.audio)
      || all[0]
      || { provider: 'gemini', model: cfg().ai?.geminiModel, label: 'Gemini', rate: { in: 0, out: 0 }, audio: true };
  }
  const setModel = k => { try { localStorage.setItem(MODEL_KEY, k); } catch {} };

  /* ================= the tool icons =================

     Drawn, not emoji: 📋 and 📄 are a different picture on every
     platform and these four sit in a row where they have to read as a
     set. Each is 20×20 on a 24 grid, 1.6 stroke, currentColor — so they
     take the button's colour and the hover with it.

     The copy icon is the standard two-rectangles one rather than a page,
     because that is the shape every application on the device already
     uses for copy and nobody should have to learn ours. */
  const ICONS = {
    read: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" aria-hidden="true">
      <path d="M12 6.4S10.2 4.8 6.9 4.8c-1.3 0-2.2.2-2.7.4v13c.5-.2 1.4-.4 2.7-.4 3.3 0 5.1 1.6 5.1 1.6"
        stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>
      <path d="M12 6.4s1.8-1.6 5.1-1.6c1.3 0 2.2.2 2.7.4v13c-.5-.2-1.4-.4-2.7-.4-3.3 0-5.1 1.6-5.1 1.6"
        stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>
      <path d="M12 6.4v13" stroke="currentColor" stroke-width="1.6"/>
    </svg>`,
    scheme: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" aria-hidden="true">
      <rect x="5" y="3.6" width="14" height="16.8" rx="2.2" stroke="currentColor" stroke-width="1.6"/>
      <path d="M8.6 8.4h6.8M8.6 12h6.8M8.6 15.6h4.2" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
    </svg>`,
    hand: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" aria-hidden="true">
      <path d="M4.6 7.2h6.2M4.6 12h6.2M4.6 16.8h4.4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
      <path d="M13.6 15.2l5.2-5.2a1.7 1.7 0 0 1 2.4 2.4l-5.2 5.2-3 .6.6-3z"
        stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>
    </svg>`,
    copy: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" aria-hidden="true">
      <rect x="8.8" y="8.8" width="11" height="11" rx="2" stroke="currentColor" stroke-width="1.6"/>
      <path d="M15.2 5.6a2 2 0 0 0-2-1.6H6.2a2 2 0 0 0-2 2v7a2 2 0 0 0 1.6 2"
        stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
    </svg>`,
    play: `<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true">
      <path d="M8.4 5.6l10 6.4-10 6.4z" fill="currentColor"/>
    </svg>`,
    /* A QR code drawn as a QR code: three finders and a scatter of
       modules. A camera glyph or a bare square would not say what happens
       when it is pressed. */
    qr: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" aria-hidden="true">
      <rect x="3.5" y="3.5" width="6.4" height="6.4" rx="1.3" stroke="currentColor" stroke-width="1.5"/>
      <rect x="14.1" y="3.5" width="6.4" height="6.4" rx="1.3" stroke="currentColor" stroke-width="1.5"/>
      <rect x="3.5" y="14.1" width="6.4" height="6.4" rx="1.3" stroke="currentColor" stroke-width="1.5"/>
      <rect x="5.9" y="5.9" width="1.7" height="1.7" fill="currentColor"/>
      <rect x="16.5" y="5.9" width="1.7" height="1.7" fill="currentColor"/>
      <rect x="5.9" y="16.5" width="1.7" height="1.7" fill="currentColor"/>
      <path d="M14.1 14.1h2.2v2.2h-2.2zM18.3 14.1h2.2v2.2h-2.2zM16.3 18.3h2.2v2.2h-2.2z" fill="currentColor"/>
    </svg>`
  };

  /* ================= the bank (#/osce) ================= */

  async function renderBank(view, user, opts) {
    view.innerHTML = shell('bank', `<div id="os-body"><p class="muted">Loading OSCE stations…</p></div>`);
    FX.viewIn(view);
    const [everything, past, colls, bpMods] = await Promise.all([
      stations().catch(() => []),
      myAttempts().catch(() => []),
      collections().catch(() => []),
      // only fetched to put a name on the filter strip; never blocks the page
      (opts && opts.bp && typeof OsceBlueprint !== 'undefined')
        ? OsceBlueprint.get().catch(() => []) : Promise.resolve([]),
      /* The candidate's own ★ and ↓, fetched alongside everything else so
         the cards are drawn already marked. Held by the module, not
         returned here — every card asks it directly. */
      (typeof Stars !== 'undefined') ? Stars.load().catch(() => null) : Promise.resolve(null),
      (typeof Bucket !== 'undefined') ? Bucket.load().catch(() => null) : Promise.resolve(null),
      (typeof Course !== 'undefined') ? Course.load().catch(() => null) : Promise.resolve(null)
    ]);
    /* THE COURSE FILTER, APPLIED ONCE AND AT THE TOP.
       Everything below counts, bins, ranks and searches `list`, so cutting
       the course out here means the chip counts, the statistics and the
       search index all agree without a single one of them knowing that
       courses exist. Filtering per-card instead would leave bins claiming
       stations that are not on the page.

       This is not the lock. The database already refused to send content
       this candidate may not read — see can_read_tracks() in the schema.
       What this removes is content they MAY read and are not sitting. */
    const list = (typeof Course !== 'undefined') ? everything.filter(st => Course.fits(st)) : everything;
    /* ARRIVED FROM "THE GAP" ON THE PROGRESS PAGE.
       A module filter is not a bin and not a search: it cuts across both,
       and it is temporary — you came here to sit one station in it and
       then you are done. So it is a strip with a way out, not a chip
       added to the row of bins. */
    const wantBp = String(opts?.bp || '');
    const bpName = wantBp
      ? ((bpMods || []).find(m => m.id === wantBp)?.name || wantBp)
      : '';
    // recordings older than a day are not worth storing; take them out while we are here
    Backend.sweepOsceAudio?.().catch(() => {});
    const bestOf = {};
    past.forEach(a => { const p = a.result?.percent; if (p != null && (bestOf[a.station_id] == null || p > bestOf[a.station_id])) bestOf[a.station_id] = p; });
    const body = view.querySelector('#os-body');

    /* One chip per bin that actually holds something, plus "All". A bin
       nobody has filed anything into is noise, so it is not drawn. */
    const counts = {};
    list.forEach(st => { const c = st.collection || ''; counts[c] = (counts[c] || 0) + 1; });
    /* Created OSCE is the exception to "a bin nobody has filed anything into
       is noise": it is the one bin you reach in order to PUT something in it,
       so an empty one still has to be reachable. */
    const madeId = createdId();
    /* THE CANDIDATE'S OWN BIN.

       A star is not a collection — the developer files stations into
       bins, the candidate stars them — but the place a candidate goes
       looking for "the ones I marked" is the same strip of chips, so
       that is where it is. It is drawn only when something is in it:
       an empty ★ chip on every account would be furniture.

       ↓ gets a chip too, and for a reason worth stating: a mark you
       cannot review is a mark you stop trusting. Being able to see what
       you have pushed down, and change your mind, is what makes it safe
       to push things down at all. */
    const starN = (typeof Stars !== 'undefined') ? Stars.counts() : { star: 0, low: 0 };
    /* Both chips are always DRAWN and hidden while empty, rather than
       drawn only when they have something in them: the first star of the
       day has to be able to make its chip appear without redrawing the
       page under the finger that pressed it. */
    const bkN = (typeof Bucket !== 'undefined') ? Bucket.count() : 0;
    const bins = [{ id: '*', label: 'All stations', n: list.length }].concat(
      [{ id: '@bucket', label: '🧺 Bucket', n: bkN, hide: !bkN }],
      [{ id: '@star', label: '★ Starred', n: starN.star, hide: !starN.star }],
      colls.filter(c => counts[c.id] || c.id === madeId).map(c => ({ id: c.id, label: c.label, n: counts[c.id] || 0 })),
      counts[''] ? [{ id: '', label: UNFILED.label, n: counts[''] }] : [],
      [{ id: '@low', label: '↓ Less important', n: starN.low, hide: !starN.low }]
    );
    /* A subject remembered from another course is not a subject here: the
       chip for it is not on the page, so honouring it would filter the
       bank to nothing with no lit chip to explain why. */
    let sub = (typeof Course !== 'undefined' && Course.subjects().includes(bankView.sub)) ? bankView.sub : '';

    if (!list.length) {
      body.innerHTML = `<div class="card" data-animate">
        <h3 class="card-title">No OSCE stations yet</h3>
        <p class="muted">The site owner publishes stations here. Each one is a 15-minute spoken viva with its own
          marking scheme — you answer out loud, the whole station is recorded, and your answers are marked against
          the scheme point by point.</p></div>`;
      return;
    }

    body.innerHTML = `
      <div class="os-hero" data-animate>
        <div class="os-hero-glow" aria-hidden="true"></div>
        <p class="kicker">SPOKEN CLINICAL EXAMINATION</p>
        <h1 class="page-title">OSCE stations</h1>
        <p class="muted">Fifteen minutes, spoken out loud, marked against the real scheme. Read the scenario, start the
          clock, and answer each question as you would to an examiner. Everything is recorded so you can hear yourself
          back — the fastest way to find out that you ramble.</p>
        <div class="os-hero-acts">
          <a class="btn btn-gold" href="#/osce/sim">🎓 Exam simulator — several stations back to back</a>
        </div>
      </div>

      <div class="os-stats" data-animate>
        <div class="os-stat"><strong>${list.length}</strong><span>Stations</span></div>
        <div class="os-stat"><strong>${past.length}</strong><span>Attempts</span></div>
        <div class="os-stat"><strong>${Object.keys(bestOf).length}</strong><span>Stations tried</span></div>
        <div class="os-stat"><strong>${past.length ? Math.round(past.reduce((s, a) => s + (a.result?.percent || 0), 0) / past.length) + '%' : '—'}</strong><span>Average</span></div>
      </div>

      <div class="es-search-wrap" data-animate>
        <div class="es-search-row">
          <span class="es-search-ico">🔎</span>
          <input type="search" id="os-search" class="es-search" autocomplete="off" spellcheck="false"
            placeholder="Search stations — e.g. HELLP, sepsis, shoulder dystocia, consent">
          <button class="es-search-x" id="os-search-x" hidden aria-label="Clear search">✕</button>
        </div>
        <p class="muted tiny es-search-hint">Searches the topic, the scenario and every marking point across all
          ${list.length} station${list.length > 1 ? 's' : ''}, best match first. Abbreviations work — PPH, PET, LSCS,
          CTG — and so does either spelling of haemorrhage, oestrogen or caesarean.</p>
        <div id="os-searchnote"></div>
      </div>

      ${wantBp ? `<div class="os-bpfilter" id="os-bpfilter" data-animate>
        <span class="os-bpfilter-k">SHOWING ONLY</span>
        <strong>${esc(bpName)}</strong>
        <span class="muted tiny" id="os-bpfilter-n"></span>
        <a class="btn btn-ghost btn-sm" href="#/osce">✕ Show every station</a>
      </div>` : ''}

      ${bins.length > 1 ? `<div class="os-bins" id="os-bins" data-animate>
        ${bins.map((b, i) => `<button class="os-bin ${i === 0 ? 'active' : ''}${
          b.id === '@star' || b.id === '@low' ? ' os-bin-mine' : ''}" data-bin="${esc(b.id)}"${b.hide ? ' hidden' : ''}>
          ${esc(b.label)}<i>${b.n}</i></button>`).join('')}
      </div>` : ''}

      ${/* SUBJECT, AND WHY IT IS A SECOND ROW AND NOT MORE CHIPS.
            A bin says where a station came from; a subject says what it is
            about. A final MBBS candidate wants both at once — "the
            paediatrics ones, out of the PERA set" — and one row of chips
            cannot express an AND. Two rows can, and a course with a single
            subject draws no row at all. */
        (typeof Course !== 'undefined') ? Course.subjectBar(sub) : ''}

      ${/* WHAT THE FILTER TOOK, SAID OUT LOUD.
            A bank that silently holds back stations is the failure mode of
            every filter that is switched on somewhere else: the candidate
            searches for a station they know exists, finds nothing, and
            concludes the search is broken. It matters most to whoever
            WRITES the stations — publish one tagged to a course you are
            not on and it would vanish from your own bank with nothing to
            explain it — so the line names the number and where to change
            it, and appears only when something was actually removed. */
        (everything.length > list.length) ? `<p class="muted tiny os-course-note" data-animate>
          ${everything.length - list.length} station${everything.length - list.length > 1 ? 's' : ''}
          belong${everything.length - list.length > 1 ? '' : 's'} to another course and
          ${everything.length - list.length > 1 ? 'are' : 'is'} not shown here.
          <a href="#/profile">Change your course</a> to see ${everything.length - list.length > 1 ? 'them' : 'it'}.
        </p>` : ''}

      ${/* A star that cannot be saved must say so BEFORE it is pressed,
            not after. This is the only state in which the ★ is not
            trustworthy, and it is a state the site owner can fix in one
            action. */
        (typeof Stars !== 'undefined' && Stars.trouble()) ? `<div class="card os-star-broken" data-animate>
        <p><strong>⚠ Your ★ marks cannot be saved at the moment.</strong> ${esc(Stars.trouble())}</p>
        <p class="muted tiny">Marks are stored against your account, not this device, so they follow you to your
          phone and your laptop — but that needs the table on the database.</p>
      </div>` : ''}
      <div id="os-made"></div>
      <div id="os-bucketbar"></div>
      <div id="os-starpack"></div>

      <div class="os-grid" id="os-grid" data-animate>${list.map(st => card(st, bestOf[st.id], colls, user)).join('')}</div>
      <p class="muted" id="os-none" hidden>No station mentions that.</p>`;

    const input = body.querySelector('#os-search');
    const clear = body.querySelector('#os-search-x');
    const grid = body.querySelector('#os-grid');
    const none = body.querySelector('#os-none');
    // opening a station and coming back should land you where you were, not
    // back at the top of two hundred stations
    input.value = bankView.q || '';
    /* The cards carry the topic and the scenario, which is enough for most
       searches. The deep index — every prompt and every marking point — is
       fetched on the FIRST keystroke and never on a visit that does not
       search, which is most of them. */
    /* ONE RECORD PER STATION, THREE FIELDS, KEPT APART.

       The fields are not concatenated. That is the whole point: the
       ranking needs to know WHERE a word was found — a word in the topic
       is what the station is, a word in a marking point is a passing
       mention — and a single blob cannot tell those apart. See the header
       of search.js. */
    const recs = list.map(st => ({ id: st.id, topic: st.topic || '', scenario: st.scenario || '', deep: '' }));
    const recById = {}; recs.forEach(r => recById[r.id] = r);
    let deep = false;
    async function loadDeep() {
      if (deep) return; deep = true;
      try {
        const idx = (typeof Cache !== 'undefined')
          ? await Cache.wrap('osce-search', TTL, () => Backend.getOsceSearchIndex(), { keepIfEmptied: true })
          : await Backend.getOsceSearchIndex();
        (idx || []).forEach(r => {
          const rec = recById[r.id];
          if (!rec || !r.search) return;
          rec.deep = r.search;
          Search.bust(rec);            // its normalised form is now out of date
        });
      } catch { /* topic + scenario search still works without it */ }
    }
    /* A remembered bin that no longer holds anything falls back to All —
       and so does arriving with a module filter, because a remembered bin
       AND a module together routinely show nothing, and "the gap sent me
       somewhere empty" is the failure this path exists to avoid. */
    let bin = (!wantBp && bins.some(b => b.id === bankView.bin)) ? bankView.bin : '*';
    body.querySelectorAll('.os-bin').forEach(x => x.classList.toggle('active', x.dataset.bin === bin));
    /* The Created OSCE panel is drawn only while that bin is the one being
       looked at. It is a whole card of import controls: on every other bin it
       would be in the way, and on All stations it would be lying about where
       the import lands. */
    const madeHost = body.querySelector('#os-made');
    const paintMade = () => {
      if (typeof Created === 'undefined') { madeHost.innerHTML = ''; return; }
      if (bin !== madeId) { Created.closePanel?.(madeHost); madeHost.innerHTML = ''; return; }
      Created.panel(madeHost, user, () => { bustStations(); renderBank(view, user, opts); });
    };

    /* The module a station is tagged to, read once. Cards carry the bin
       in a data attribute but not the blueprint tag, and putting it on
       every card would change the card markup for one temporary filter. */
    const bpOf = {};
    const byIdBank = {};
    list.forEach(st => { bpOf[st.id] = (st.bp && st.bp.module) || ''; byIdBank[st.id] = st; });

    /* Whether the weak matches are being shown, for this search only.
       Reset on every new query: an "everything" that persisted would
       quietly turn the ranking off for the rest of the visit. */
    let showAll = false;
    let lastQ = '';

    const run = () => {
      const raw = input.value.trim();
      clear.hidden = !raw;
      if (raw !== lastQ) { lastQ = raw; showAll = false; }
      bankView.q = input.value; bankView.bin = bin; bankView.sub = sub;

      const inBin = id => bin === '*' ? true
        : bin === '@bucket' ? (typeof Bucket !== 'undefined' && Bucket.has(id))
        : bin === '@star' ? (typeof Stars !== 'undefined' && Stars.starred(id))
        : bin === '@low' ? (typeof Stars !== 'undefined' && Stars.low(id))
        : (byIdBank[id]?.collection || '') === bin;
      /* The bin and the module filter are not relevance, they are a
         question about which shelf to look on — so they are applied
         BEFORE the ranking, not scored into it. Ranking within the wrong
         shelf would put a brilliant match you cannot see at the top. */
      const inSub = id => typeof Course === 'undefined' || Course.fitsSubject(byIdBank[id], sub);
      const pool = recs.filter(r => inBin(r.id) && inSub(r.id) && (!wantBp || bpOf[r.id] === wantBp));

      const res = Search.rank(pool, raw, { showAll });
      const order = {}; const where = {};
      res.rows.forEach((x, i) => { order[x.rec.id] = i; where[x.rec.id] = x.where; });

      let shown = 0;
      grid.querySelectorAll('.os-card').forEach(c => {
        const ok = order[c.dataset.st] != null;
        c.hidden = !ok;
        if (!ok) return;
        shown++;
        /* Reordered by `order`, not by moving nodes: the cards carry
           their own listeners and their own star state, and moving them
           in the DOM to sort a list is how those get lost. */
        c.style.order = order[c.dataset.st];
        /* Say why it is here, but only when that is not obvious — a
           title match speaks for itself. */
        const w = raw ? where[c.dataset.st] : '';
        const tag = c.querySelector('.os-card-why');
        const label = w === 'scheme' ? 'in the marking scheme' : w === 'scenario' ? 'in the scenario' : '';
        if (tag) { tag.textContent = label; tag.hidden = !label; }
      });

      none.hidden = shown > 0;
      none.textContent = raw ? `Nothing in the bank matches “${raw}”.`
        : wantBp ? `No station in ${bpName} is filed here. Try “All stations”, or write one.`
        : bin === '@bucket' ? 'The bucket is empty. Drop stations in with the 🧺 on any card and sit them together.'
        : bin === '@star' ? 'Nothing starred yet. Tap the ★ on any station and it waits for you here.'
        : bin === '@low' ? 'Nothing marked less important yet.'
        : bin === madeId ? 'No stations have been created yet — yours would be the first.'
        : 'Nothing filed here yet.';

      paintSearchNote(res, shown, raw);
      paintBucketBar();
      paintStarPack(shown);
      const nEl = body.querySelector('#os-bpfilter-n');
      if (nEl) nEl.textContent = `${shown} station${shown === 1 ? '' : 's'}`;
      paintMade();
      restoreScroll();
    };

    /* WHAT WAS LEFT OUT, SAID OUT LOUD.

       Hiding a weak result is only honest if the hiding is visible and
       reversible. This is the line that makes the cut a decision the
       reader can overrule rather than a silence they have to guess at. */
    const noteHost = body.querySelector('#os-searchnote');
    function paintSearchNote(res, shown, raw) {
      if (!noteHost) return;
      if (!raw) { noteHost.innerHTML = ''; return; }
      const bits = [`<strong>${shown}</strong> station${shown === 1 ? '' : 's'}, best match first`];
      if (res.loose) bits.push(`nothing matches every word — these match some of them`);
      noteHost.innerHTML = `<div class="os-srch-note">
        <span>${bits.join(' · ')}</span>
        ${res.cut ? `<button class="btn btn-ghost btn-sm" id="os-srch-all">
          ${showAll ? 'Hide' : 'Show'} ${res.cut} weaker match${res.cut === 1 ? '' : 'es'}</button>` : ''}
      </div>`;
      noteHost.querySelector('#os-srch-all')?.addEventListener('click', () => { showAll = !showAll; run(); });
    }
    /* ---------------- the bucket, and the way out of it ----------------

       A cart with no checkout is a list. This is the checkout: it says
       what is in it, how long it will take, and starts the circuit —
       and it is drawn wherever you are in the bank, not only in the
       bucket's own bin, because the whole point is that you fill it
       while looking at something else. */
    const bkBar = body.querySelector('#os-bucketbar');
    function paintBucketBar() {
      if (!bkBar || typeof Bucket === 'undefined') return;
      const n = Bucket.count();
      if (!n) { bkBar.innerHTML = ''; return; }
      const mins = Bucket.ids().reduce((t, id) => t + minsOf(byIdBank[id] || {}), 0);
      bkBar.innerHTML = `
        <div class="card os-bkbar" data-animate>
          <div class="os-bkbar-l">
            <span class="os-bkbar-ico">${Bucket.ICON_IN}</span>
            <div>
              <strong>${n} station${n === 1 ? '' : 's'} in your bucket</strong>
              <span class="muted tiny">${hours(mins)} of examining · sat in the order you collected them ·
                each one leaves the bucket once you have sat it</span>
            </div>
          </div>
          <div class="os-bkbar-acts">
            <a class="btn btn-gold" href="#/osce/sim?bucket=1">▶ Sit them as a circuit</a>
            <button class="btn btn-ghost btn-sm" id="os-bk-see">See what is in it</button>
            <button class="btn btn-ghost btn-sm" id="os-bk-empty">Empty it</button>
          </div>
        </div>`;
      bkBar.querySelector('#os-bk-see')?.addEventListener('click', () => {
        bin = '@bucket';
        body.querySelectorAll('.os-bin').forEach(x => x.classList.toggle('active', x.dataset.bin === bin));
        run();
      });
      bkBar.querySelector('#os-bk-empty')?.addEventListener('click', async e => {
        const b = e.currentTarget;
        /* Asked twice, because emptying it is the one action here that
           throws away a decision rather than making one. */
        if (b.dataset.sure !== '1') {
          b.dataset.sure = '1'; b.textContent = `Empty all ${n}? Tap again`;
          setTimeout(() => { if (b.dataset.sure === '1') { b.dataset.sure = ''; b.textContent = 'Empty it'; } }, 4000);
          return;
        }
        await Bucket.empty();
        Bucket.paint(body); chip('@bucket', 0); paintBucketBar();
        if (bin === '@bucket') { bin = '*';
          body.querySelectorAll('.os-bin').forEach(x => x.classList.toggle('active', x.dataset.bin === bin)); }
        run();
      });
    }

    /* ---------------- the revision pack ----------------

       What the ★ is FOR. A list of starred stations is a list; the thing
       a candidate actually wants in the last week is all of them in one
       document they can read on a bus or print on paper. The scheme
       printer already exists and already takes a station — so this hands
       it all of them at once, in the order they were starred, and the
       week before the exam is one press away from a revision booklet.

       Drawn only in the ★ bin: everywhere else it would be an offer to
       print something you are not looking at. */
    const packHost = body.querySelector('#os-starpack');
    function paintStarPack(shown) {
      if (!packHost) return;
      if (bin !== '@star' || typeof Stars === 'undefined' || !Stars.counts().star) { packHost.innerHTML = ''; return; }
      if (packHost.dataset.n === String(shown)) return;      // no need to redraw on every keystroke
      packHost.dataset.n = String(shown);
      packHost.innerHTML = `
        <div class="card os-starpack" data-animate>
          <h3 class="card-title">★ Your revision list</h3>
          <p class="muted">The stations you marked as worth coming back to. Nobody else sees this list, and starring
            one never changes how it is drawn for anyone else.</p>
          <div class="os-starpack-acts">
            <button class="btn btn-gold" id="os-star-print">🖨 Print all ${shown} marking scheme${shown === 1 ? '' : 's'}</button>
            <a class="btn btn-ghost" href="#/osce/sim">▶ Sit them as a circuit</a>
          </div>
          <p class="muted tiny">The printout is the schemes themselves — every question, every marking point, with a
            box to tick — not a record of how you did. It is what to revise from, and what to hand somebody who is
            going to examine you.</p>
        </div>`;
      packHost.querySelector('#os-star-print')?.addEventListener('click', async e => {
        const b = e.currentTarget;
        const ids = Stars.idsAt(Stars.STAR).filter(id => byIdBank[id]);
        if (!ids.length) return;
        b.disabled = true; b.textContent = `Fetching ${ids.length} scheme${ids.length === 1 ? '' : 's'}…`;
        try {
          /* The bank holds cards, not schemes — the marking points are
             fetched per station and deliberately are not in the list
             payload. So they are fetched here, once, for the print. */
          const full = [];
          for (const id of ids) { const s = await station(id).catch(() => null); if (s) full.push(s); }
          if (!full.length) throw new Error('None of the starred stations could be loaded.');
          printScheme(full);
        } catch (err) {
          alert('Could not build the printout: ' + (err?.message || err));
        }
        b.disabled = false; b.textContent = `🖨 Print all ${ids.length} marking scheme${ids.length === 1 ? '' : 's'}`;
      });
    }

    /* One listener for the whole grid — see the note on Stars.wire. A star
       pressed inside the ★ bin drops the card out of the list it is in,
       which is the right behaviour and would be baffling anywhere else,
       so the whole strip is redrawn from the counts instead. */
    /* One chip updater for both marks. An empty chip you are standing in
       must not vanish under you — it would leave the page filtered to a
       bin with no button to leave it by. */
    const chip = (id, n) => {
      const el = body.querySelector(`.os-bin[data-bin="${id}"]`);
      if (!el) return;
      el.querySelector('i').textContent = n;
      el.hidden = !n && bin !== id;
    };

    if (typeof Bucket !== 'undefined') {
      Bucket.wire(body, () => {
        chip('@bucket', Bucket.count());
        paintBucketBar();
        if (bin === '@bucket') { packHost.dataset.n = ''; run(); }
      });
    }

    if (typeof Stars !== 'undefined') {
      Stars.wire(body, () => {
        const c = Stars.counts();
        chip('@star', c.star); chip('@low', c.low);
        if (bin === '@star' || bin === '@low') { packHost.dataset.n = ''; run(); }
      });
    }

    input.addEventListener('input', async () => { bankView.top = 0; await loadDeep(); run(); });
    clear.addEventListener('click', () => { input.value = ''; bankView.top = 0; run(); input.focus(); });
    body.querySelector('#os-bins')?.addEventListener('click', e => {
      const b = e.target.closest('[data-bin]'); if (!b) return;
      bin = b.dataset.bin; bankView.top = 0;
      body.querySelectorAll('.os-bin').forEach(x => x.classList.toggle('active', x === b));
      run();
    });
    body.querySelector('.tk-subs')?.addEventListener('click', e => {
      const s = e.target.closest('[data-sub]'); if (!s) return;
      sub = s.dataset.sub; bankView.top = 0;
      body.querySelectorAll('.tk-sub').forEach(x => x.classList.toggle('is-on', x === s));
      run();
    });
    // the deep index is only needed when a search is actually in force, so a
    // restored one pays for it and a fresh visit still does not
    if (bankView.q.trim()) { await loadDeep(); }
    run();
    grid.addEventListener('click', () => { bankView.top = window.scrollY; }, true);

    /* THE SEVEN BUTTONS. Delegated, because the cards are re-ordered and
       re-shown by the search rather than rebuilt, and a listener per card
       per keystroke is a listener leak. */
    grid.addEventListener('click', async e => {
      const b = e.target.closest('[data-cact]');
      if (!b) return;
      /* The card is an anchor. Without this, every one of these would
         also open the station's page underneath it — which is what the
         bucket and the star already have to say. */
      e.preventDefault(); e.stopPropagation();
      const a = b.closest('.os-card');
      const id = a?.dataset.st;
      if (!id || b.disabled) return;
      const act = b.dataset.cact;

      if (act === 'play') {
        const sid = 'os-' + Date.now().toString(36);
        await saveSession({ id: sid, stations: [id], at: 0, phase: 'brief', answers: {}, elapsed: 0, started: Date.now() });
        location.hash = '#/osce/run/' + sid;
        return;
      }
      if (act === 'hand') { location.hash = '#/osce/mark/' + encodeURIComponent(id); return; }
      if (act === 'qr') {
        if (typeof QR === 'undefined') return;
        QR.show({
          hash: '#/osce/station/' + encodeURIComponent(id),
          kicker: 'OPEN IT ON ANOTHER DEVICE',
          title: a.dataset.topic || 'This station',
          note: 'Whoever is preparing with you points a phone at this and lands on the same station.'
        });
        return;
      }

      /* The rest need the whole station — the questions, and for two of
         them the marking scheme. The card does not carry either, so it is
         fetched here, and the button says it is working: on a slow
         connection this is a second or two, and a button that looks like
         it did nothing gets pressed again.

         The icon is left alone throughout. `copyOut` reports itself by
         replacing a button's TEXT, which on an icon would paint the SVG
         source across the card — so the state is a class instead, and the
         tick is drawn in CSS. */
      b.disabled = true; b.classList.add('is-busy');
      let st = null;
      try { st = await station(id); } catch {}
      b.disabled = false; b.classList.remove('is-busy');
      if (!st) { flashAct(b, false); return; }

      if (act === 'read') readingMode(st);
      else if (act === 'scheme') showScheme(st);
      else if (act === 'copy') flashAct(b, await copyOut(stationAsText(st)));
      else if (act === 'ai' && typeof AiOsce !== 'undefined') AiOsce.openDialog(st);
    });
  }

  /* Where the candidate was in the bank, kept for the length of the visit.
     Deliberately in memory rather than storage: coming back from a station
     should feel like going back, but a new session should start clean. */
  const bankView = { q: '', bin: '*', sub: '', top: 0 };
  let scrollTimer = null;
  function restoreScroll() {
    if (!bankView.top) return;
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(() => { window.scrollTo({ top: bankView.top, behavior: 'instant' }); bankView.top = 0; }, 40);
  }

  /** The day a station went into AUREUM, short enough for a card. */
  function addedOn(st) {
    const raw = st.created_at || st.created_on;
    if (!raw) return '';
    const d = new Date(raw);
    if (isNaN(d)) return '';
    return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
  }

  /* ---------------- the seven things you can do with a station -------

     Every one of these was already on the station's own page, behind one
     more tap and a page of reading you have usually done before. The card
     is where you are when you decide; this puts the decision and the doing
     in the same place. Pressing the card itself still opens the page, as
     it always did — a button stops the anchor, exactly as the bucket and
     the star already do.

     `need` says whether the whole station has to be fetched first. A card
     carries the summary only, deliberately: the questions and the marking
     scheme stay in the database until something actually needs them. */
  const CARD_ACTS = [
    { id: 'play',   need: false, cls: 'is-go',  label: 'Start the station',
      title: 'Start the station — the clock starts straight away' },
    { id: 'read',   need: true,  label: 'Reading mode',
      title: 'Reading mode — the whole station as an article, to read and mark up' },
    { id: 'scheme', need: true,  label: 'Show the marking scheme',
      title: 'Show the marking scheme' },
    { id: 'hand',   need: false, label: 'Mark somebody by hand',
      title: 'Mark somebody who is sitting in front of you, point by point' },
    { id: 'copy',   need: true,  label: 'Copy the station',
      title: 'Copy the scenario and the questions as plain text — WITHOUT the marking scheme' },
    { id: 'ai',     need: true,  cls: 'os-tool-ai', label: 'Sit it against a chat model',
      title: 'OSCE in AI — sit this one against Claude, ChatGPT or Gemini' },
    { id: 'qr',     need: false, label: 'Show the QR code',
      title: 'Show the code — point a phone at it to land on this station' }
  ];

  /** A tick or a cross over an icon button, briefly. */
  function flashAct(b, ok) {
    b.classList.remove('is-done', 'is-bad');
    b.classList.add(ok ? 'is-done' : 'is-bad');
    setTimeout(() => { if (b.isConnected) b.classList.remove('is-done', 'is-bad'); }, 2000);
  }

  function cardActs(st, user) {
    const ai = typeof AiOsce !== 'undefined' && AiOsce.allowed(user);
    return `<div class="os-card-acts" role="group" aria-label="What to do with this station">
      ${CARD_ACTS.filter(a => a.id !== 'ai' || ai).map(a => `
        <button type="button" class="os-cact ${a.cls || ''}" data-cact="${a.id}"
          title="${esc(a.title)}" aria-label="${esc(a.label)}">${
          a.id === 'ai' ? `<span class="ai-marks">${AiOsce.LOGOS.claude}${AiOsce.LOGOS.gpt}${AiOsce.LOGOS.gemini}</span>`
            : ICONS[a.id === 'play' ? 'play' : a.id === 'qr' ? 'qr' : a.id]}</button>`).join('')}
    </div>`;
  }

  function card(st, best, colls, user) {
    const n = qCount(st);
    const cl = (colls || []).length ? collLabel(colls, st.collection || '') : '';
    const when = addedOn(st);
    return `
      <a class="os-card" data-st="${esc(st.id)}" data-coll="${esc(st.collection || '')}"
         data-topic="${esc(st.topic || st.id)}"
         href="#/osce/station/${encodeURIComponent(st.id)}">
        ${/* The day it went into AUREUM. Small, and at the top left where
              it is out of the way of everything that is about the station
              itself — it says how old the bank's newest additions are,
              which is the question it is there to answer. */''}
        ${when ? `<span class="os-card-when" title="Added to AUREUM on ${esc(when)}">${esc(when)}</span>` : ''}
        ${/* The bucket sits to the LEFT of the star because the two mean
              different things and the order says which is which: what you
              are going to sit, then what you want to keep. */''}
        <span class="os-card-marks">
          ${typeof Bucket !== 'undefined' ? Bucket.html(st.id, true) : ''}
          ${typeof Stars !== 'undefined' ? Stars.html(st.id, true) : ''}
        </span>
        <div class="os-card-top">
          <span class="os-card-time">${minsOf(st)} min</span>
          ${st.image_count ? `<span class="os-card-img" title="${st.image_count} image${st.image_count === 1 ? '' : 's'} — a CTG, a partogram or a scan">🖼 ${st.image_count}</span>` : ''}
          ${cl ? `<span class="os-card-coll">${esc(cl)}</span>` : ''}
          ${best != null ? `<span class="os-card-best ${best >= (st.pass_mark_percent || 70) ? 'good' : 'bad'}">best ${best}%</span>` : ''}
        </div>
        <h3>${esc(st.topic || st.id)}</h3>
        <span class="os-card-why" hidden></span>
        <p class="os-card-sc">${esc(st.scenario || '')}</p>
        ${st.created_by_name ? `<p class="os-card-by">✍️ written by ${esc(st.created_by_name)}</p>` : ''}
        <div class="os-card-foot">
          <span>${n} question${n === 1 ? '' : 's'} · ${marksOf(st)} marks</span>
        </div>
        ${cardActs(st, user)}
      </a>`;
  }

  /* ================= one station's brief (#/osce/station/:id) ================= */

  async function renderStation(view, id, user, query) {
    const st = await station(id);
    if (!st) { view.innerHTML = shell('bank', `<p class="muted">That station is no longer published. <a class="link" href="#/osce">Back</a></p>`); FX.viewIn(view); return; }
    let past = [];
    try { past = (await myAttempts()).filter(a => a.station_id === id); } catch {}

    view.innerHTML = shell('bank', `
      <a class="link muted dev-back" href="#/osce">← OSCE stations</a>
      <header data-animate>
        <p class="kicker">STATION · ${minsOf(st)} MINUTES · ${marksOf(st)} MARKS</p>
        <h1 class="page-title">${esc(st.topic || '')}</h1>
        ${/* Marked HERE as well as on the card, because this is the page
              you are on when you find out a station is hard — and the
              moment you learn it is worth revising is the moment you want
              to say so, not two taps later back in the bank. */
          typeof Stars !== 'undefined' ? `<div class="os-star-row" id="os-star-row">
          ${typeof Bucket !== 'undefined' ? Bucket.html(st.id) : ''}
          ${Stars.html(st.id)}
          <span class="muted tiny os-star-say" id="os-star-say"></span>
        </div>` : ''}
        ${st.created_by_name ? `<p class="muted os-by">✍️ Written by <strong>${esc(st.created_by_name)}</strong>${
          st.created_on ? ' · ' + esc(new Date(st.created_on).toLocaleDateString()) : ''}${
          st.source_meta?.origin ? ' · from ' + esc(st.source_meta.origin) : ''}</p>` : ''}
      </header>
      <div class="card os-brief" data-animate>
        <h3 class="card-title">The scenario</h3>
        <p class="os-scenario">${esc(st.scenario || '')}</p>
        <div class="os-brief-grid">
          <div><strong>${qCount(st)}</strong><span>questions</span></div>
          <div><strong>${marksOf(st)}</strong><span>marks</span></div>
          <div><strong>${passOf(st)}</strong><span>to pass (${st.pass_mark_percent || 70}%)</span></div>
          <div><strong>${minsOf(st)}</strong><span>minutes</span></div>
        </div>
        ${/* THE CANDIDATE IS TOLD THERE IS A CHARACTER, AND NOTHING ELSE.
              Knowing you are about to talk to somebody rather than answer a
              viva changes how you prepare, and that is fair — it is on the
              door of the real station too. Who she is and what she is
              hiding is not, so only the fact appears here. */
          hasRole(st) ? `<div class="os-rp-flag">
          <span class="os-rp-tag">🎭 Role player</span>
          <p>Somebody is in the chair — this is a conversation, not a viva. AUREUM's own examiner reads the
            questions; to have the character played, sit it in <strong>OSCE in AI</strong> or hand the brief to
            whoever is examining you.</p>
        </div>` : ''}
        <p class="muted tiny os-warn">You will answer <strong>out loud</strong>. The browser asks for the microphone
          when the station starts; the whole ${minsOf(st)} minutes is recorded and offered as a download at the end.
          Nothing is uploaded unless you ask for AI marking.</p>
        ${/* ONE VERB, THEN FOUR TOOLS.

              Start is the thing you came here to do, so it keeps its
              words. The other four are tools you reach for knowing what
              they are, and five sentences competing on one line made the
              one that matters harder to find rather than easier. They
              are icons with a tooltip and a spoken label — the label is
              not optional: an icon-only button with no aria-label is a
              button a screen reader cannot name.

              "Add it to a simulator session" is gone. It went to a page
              that then drew a round at random and had forgotten this
              station entirely, which is not what it said. The bucket
              does what it promised: see js/bucket.js. */''}
        <div class="os-brief-acts">
          <button class="btn btn-gold btn-lg" id="os-start">▶ Start the station</button>
          <div class="os-tools" role="group" aria-label="Tools for this station">
            <button class="os-tool" id="os-read" type="button" aria-label="Reading mode"
              title="Reading mode — the whole station as an article to read before the exam">${ICONS.read}</button>
            <button class="os-tool" id="os-scheme" type="button" aria-label="Show the marking scheme"
              title="Show the marking scheme">${ICONS.scheme}</button>
            <button class="os-tool" id="os-hand" type="button" aria-label="Mark somebody by hand"
              title="Mark somebody who is sitting in front of you, point by point">${ICONS.hand}</button>
            <button class="os-tool" id="os-copy" type="button" aria-label="Copy the station"
              title="Copy the scenario and the questions as plain text — WITHOUT the marking scheme — to paste into NotebookLM, Gemini or ChatGPT">${ICONS.copy}</button>
            ${typeof AiOsce !== 'undefined' && AiOsce.allowed(user) ? `
            <button class="os-tool os-tool-ai" id="os-aiosce" type="button" aria-label="Sit this station against a chat model"
              title="OSCE in AI — sit this one against Claude, ChatGPT or Gemini">
              <span class="ai-marks">${AiOsce.LOGOS.claude}${AiOsce.LOGOS.gpt}${AiOsce.LOGOS.gemini}</span>
            </button>` : ''}
          </div>
        </div>
        <p class="muted tiny">Most of these stations exist on paper too — open the scheme if you want to check this is
          the one you meant before you start the clock.</p>
        ${/* THE STATION, HANDED ACROSS THE TABLE.

              Two people preparing together lose a minute every time each
              of them searches the bank for the same station, and the one
              who finds it second is often on a different one. A code on
              the screen removes the search: whoever has it open, the
              others point a phone at it and land on this page.

              Small on purpose. It is a shortcut, not the subject of the
              page, and it opens full size when it needs to be read from
              across a room. */
          typeof QR !== 'undefined' ? `<div class="os-qc" id="os-qc">
          ${QR.card({ hash: '#/osce/station/' + encodeURIComponent(st.id), small: true,
            kicker: 'OPEN IT ON ANOTHER DEVICE',
            title: esc(st.topic || 'This station'),
            note: 'Point a phone at it — anybody preparing with you lands on this station without searching for it.' })}
          <button type="button" class="btn btn-ghost btn-sm" id="os-qc-big">⤢ Show it big</button>
        </div>` : ''}
      </div>
      ${past.length ? `
      <div class="card" data-animate>
        <h3 class="card-title">Your attempts</h3>
        <div class="table-scroll"><table class="table">
          <thead><tr><th>When</th><th>Score</th><th>Result</th><th></th></tr></thead>
          <tbody>${past.slice().sort((a, b) => (b.created || 0) - (a.created || 0)).map(a => `
            <tr><td class="muted">${esc(new Date(a.created || Date.now()).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' }))}</td>
              <td><strong>${a.result?.total ?? '—'}/${a.result?.max ?? marksOf(st)}</strong> · ${a.result?.percent ?? '—'}%</td>
              <td>${a.result?.pass ? '<span class="good">Pass</span>' : '<span class="bad">Below the pass mark</span>'}</td>
              <td><a class="link" href="#/osce/result/${encodeURIComponent(a.id)}">Open →</a></td></tr>`).join('')}</tbody>
        </table></div>
      </div>` : ''}`);
    FX.viewIn(view);
    view.querySelector('#os-start').addEventListener('click', async () => {
      const sid = 'os-' + Date.now().toString(36);
      await saveSession({ id: sid, stations: [st.id], at: 0, phase: 'brief', answers: {}, elapsed: 0, started: Date.now() });
      location.hash = '#/osce/run/' + sid;
    });
    view.querySelector('#os-scheme').addEventListener('click', () => showScheme(st));
    view.querySelector('#os-read')?.addEventListener('click', () => readingMode(st));

    /* The ★ / ↓ pair, and a line saying what each one will actually do —
       a mark whose consequence is invisible is a mark nobody presses. */
    if (typeof Stars !== 'undefined') {
      const row = view.querySelector('#os-star-row');
      const say = view.querySelector('#os-star-say');
      const sayIt = () => {
        if (!say) return;
        const m = Stars.of(st.id);
        const inBk = typeof Bucket !== 'undefined' && Bucket.has(st.id);
        const n = (typeof Bucket !== 'undefined') ? Bucket.count() : 0;
        say.innerHTML = inBk
          ? `In your simulator bucket — <a class="link" href="#/osce/sim">sit ${n} station${n === 1 ? '' : 's'} as one circuit →</a>
             It leaves the bucket once you have actually sat it.`
          : m === Stars.STAR
            ? 'In your ★ revision list — and never skipped in a circuit.'
            : m === Stars.LOW
              ? 'A circuit will offer to skip this one, and can leave it out altogether.'
              : 'Drop it in the bucket to sit later, or star it for the week before the exam.';
      };
      Stars.load().then(() => { Stars.paint(row); sayIt(); }).catch(() => {});
      Stars.wire(row, sayIt);
      if (typeof Bucket !== 'undefined') {
        Bucket.load().then(() => { Bucket.paint(row); sayIt(); }).catch(() => {});
        Bucket.wire(row, sayIt);
      }
      sayIt();
    }
    view.querySelector('#os-hand')?.addEventListener('click', () => {
      location.hash = '#/osce/mark/' + encodeURIComponent(st.id);
    });
    view.querySelector('#os-copy').addEventListener('click', e =>
      copyOut(stationAsText(st), e.currentTarget, '📄 Copy the station'));
    view.querySelector('#os-aiosce')?.addEventListener('click', () => AiOsce.openDialog(st));

    if (typeof QR !== 'undefined') {
      QR.wire(view.querySelector('#os-qc'));
      view.querySelector('#os-qc-big')?.addEventListener('click', () => QR.show({
        hash: '#/osce/station/' + encodeURIComponent(st.id),
        kicker: 'OPEN IT ON ANOTHER DEVICE',
        title: st.topic || 'This station',
        note: 'Whoever is preparing with you points a phone at this and lands on the same station.'
      }));
    }

    /* ARRIVING FROM A CODE.

       `?ai=1` on this route means somebody scanned the code at the foot
       of the OSCE-in-AI dialog. Open that dialog, set the way the code
       said, and do nothing else — a scan must never start a clock by
       itself, because the scan happens while you are still finding your
       seat. */
    const q = new URLSearchParams(String(query || '').replace(/^\?/, ''));
    if (q.get('ai') === '1' && typeof AiOsce !== 'undefined' && AiOsce.allowed(user)) {
      const p = q.get('p');
      AiOsce.openDialog(st, { model: q.get('m') || '', level: p == null ? null : Number(p) });
    }
  }

  /* ================= reading mode =================

     A station is a form when you are sitting it and a DOCUMENT when you
     are revising from it, and those want opposite things. The form wants
     the app's dark chrome, the clock, the buttons. The document wants a
     page: light, quiet, wide margins, serif prose, and nothing that
     blinks.

     So this is deliberately not themed with the rest of AUREUM. It is a
     white page whatever the app is set to, because that is what reading
     twenty minutes of scheme on a train at eleven at night is actually
     comfortable on — and because it is what it will look like if it is
     printed, which is the other way this gets used.

     THE CHARTS EARN THEIR PLACE OR THEY ARE NOT DRAWN

     One chart, from data the scheme actually carries: how the marks are
     spread across the questions. It answers a question a candidate has
     and cannot otherwise see — where the marks are, and therefore where
     the minutes should go — and the suggested minutes are that same
     division carried through, printed on the row rather than drawn a
     second time in a second chart of the same shape.

     A second chart of "points per question" was considered and dropped:
     points and marks are different units, and the only honest ways to
     show them together are two charts or one chart and a number. The
     number is on the row. A station with one question gets no chart at
     all — a one-bar bar chart is a stat tile pretending. */

  const RD_PAL = {
    ink: '#0b0b0b', ink2: '#52514e', ink3: '#86857e',
    rule: '#e4e2dc', surface: '#fcfcfb', bar: '#2a78d6', barSoft: '#cde2fb', accent: '#eb6834'
  };

  /**
   * Marks per question, as a horizontal bar chart.
   * Single series, so no legend — the title names it. Direct-labelled,
   * because a value on every row is right when there are five rows and
   * wrong when there are fifty.
   */
  function rdMarksChart(st) {
    const qs = qsOf(st).filter(q => Number(q.marks) > 0);
    if (qs.length < 2) return '';                 // one bar is not a chart
    const total = qs.reduce((n, q) => n + Number(q.marks || 0), 0) || 1;
    const mins = minsOf(st);
    const max = Math.max(...qs.map(q => Number(q.marks) || 0));
    /* The right-hand reserve is measured from the LONGEST label this
       station will actually draw, not guessed: "14 marks · 6 pts · ~4 min"
       is wider than "5 marks · 4 pts · ~2 min" and a fixed guess let the
       widest row run off the edge of the figure. ~6.15px per character at
       12px in the system stack, rounded up. */
    const longest = Math.max(...qs.map((q, i) => {
      const m = Number(q.marks) || 0;
      const pts = scorable(q.marking_points).length;
      return `${m} marks · ${pts} pt${pts === 1 ? '' : 's'} · ~${Math.round((m / total) * mins)} min`.length;
    }));
    const ROW = 34, BAR = 18, PAD_T = 8, LABEL = 52;
    const RIGHT = Math.ceil(longest * 6.2) + 18;
    const w = 640, h = PAD_T + qs.length * ROW + 6;
    const plot = w - LABEL - RIGHT;

    const bars = qs.map((q, i) => {
      const m = Number(q.marks) || 0;
      const y = PAD_T + i * ROW;
      const len = Math.max(2, (m / max) * plot);
      const pts = scorable(q.marking_points).length;
      const mn = Math.round((m / total) * mins);
      return `
        <text x="${LABEL - 12}" y="${y + BAR / 2 + 4}" text-anchor="end"
          font-size="12" fill="${RD_PAL.ink2}">Q${i + 1}</text>
        <rect x="${LABEL}" y="${y}" width="${len}" height="${BAR}" rx="4" fill="${RD_PAL.bar}"/>
        ${/* Square at the baseline, rounded at the data end — the corner
              radius must never read as part of the value. */''}
        <rect x="${LABEL}" y="${y}" width="4" height="${BAR}" fill="${RD_PAL.bar}"/>
        <text x="${LABEL + len + 10}" y="${y + BAR / 2 + 4}" font-size="12" fill="${RD_PAL.ink}">
          <tspan font-weight="600">${m}</tspan><tspan fill="${RD_PAL.ink3}"> marks · ${pts} pt${pts === 1 ? '' : 's'} · ~${mn} min</tspan>
        </text>`;
    }).join('');

    return `
      <figure class="rd-fig">
        <figcaption class="rd-figcap">
          <strong>Where the marks are</strong>
          <span>and therefore where the minutes should go — ${mins} minutes divided in the same proportion</span>
        </figcaption>
        <svg viewBox="0 0 ${w} ${h}" width="100%" height="${h}" role="img"
          aria-label="Marks for each question: ${qs.map((q, i) => `question ${i + 1}, ${q.marks} marks`).join('; ')}">
          <line x1="${LABEL}" y1="2" x2="${LABEL}" y2="${h - 4}" stroke="${RD_PAL.rule}" stroke-width="1"/>
          ${bars}
        </svg>
        ${/* The table view, so the figure is never the only way to the
              numbers — for a screen reader, for print, and for anyone who
              simply wants to read them. */''}
        <details class="rd-table">
          <summary>The same figures as a table</summary>
          <table>
            <thead><tr><th>Question</th><th>Marks</th><th>Share</th><th>Points</th><th>Suggested</th></tr></thead>
            <tbody>${qs.map((q, i) => {
              const m = Number(q.marks) || 0;
              return `<tr><td>Q${i + 1}</td><td>${m}</td><td>${Math.round((m / total) * 100)}%</td>
                <td>${scorable(q.marking_points).length}</td><td>~${Math.round((m / total) * mins)} min</td></tr>`;
            }).join('')}</tbody>
          </table>
        </details>
      </figure>`;
  }

  /**
   * The pass mark against the total: one ratio against a limit, which is
   * a meter and not a chart. Same ramp, so the fill and the track are
   * the same hue and only the fill reads as the value.
   */
  function rdPassMeter(st) {
    const total = marksOf(st), pass = passOf(st);
    if (!total || !pass) return '';
    const pct = Math.round((pass / total) * 100);
    return `
      <div class="rd-meter">
        <div class="rd-meter-top"><strong>${pass} of ${total} marks to pass</strong><span>${pct}%</span></div>
        <div class="rd-meter-track"><i style="width:${Math.min(100, pct)}%"></i></div>
        <p class="rd-meter-say">Every marking point below is worth the same share of its question, so
          ${pass === total ? 'every point counts' : `missing more than ${total - pass} mark${total - pass === 1 ? '' : 's'} across the whole station is a fail`}.</p>
      </div>`;
  }

  /* ---------------- the pencil case ----------------

     Four tools, and the colours that belong to whichever is chosen. The
     swatches are what anybody actually uses; the well beside them is the
     platform's own colour picker, so "any colour at all" costs one input
     rather than a colour wheel of our own.

     On an iPad the pencil draws and the finger scrolls, always — so
     there is no "drawing mode" to leave. Selecting the highlighter only
     changes what happens when you let go of a selection. */
  function annToolbar() {
    const sw = (list, kind) => list.map(x =>
      `<button type="button" class="an-sw" data-an-c="${kind}|${x.c}" style="--c:${x.c}"
        title="${esc(x.name)}" aria-label="${esc(x.name)}"></button>`).join('');
    return `
      <div class="an-bar" id="an-bar">
        <div class="an-tools" role="group" aria-label="Marking tools">
          <button type="button" class="an-t is-on" data-an-t="read" title="Read — nothing is marked"
            aria-label="Reading">👆</button>
          <button type="button" class="an-t" data-an-t="hl" title="Highlighter — drag along a line and the colour follows the nib"
            aria-label="Highlighter">🖍</button>
          <button type="button" class="an-t" data-an-t="ul" title="Underline — drag along a line to rule under the words"
            aria-label="Underline"><span class="an-t-ul">A</span></button>
          <button type="button" class="an-t" data-an-t="pen" title="Pen — draw with an Apple Pencil or a mouse; a finger still scrolls"
            aria-label="Pen">✒️</button>
          <button type="button" class="an-t" data-an-t="note" title="Sticky note — tap the page to leave a note you can type"
            aria-label="Sticky note">📝</button>
          <button type="button" class="an-t" data-an-t="erase" title="Eraser — tap a mark to remove it"
            aria-label="Eraser">🧽</button>
        </div>
        <div class="an-colours" id="an-colours">
          <span class="an-hl-set">${sw(Annotate.HIGHLIGHTS, 'hl')}
            <label class="an-well" title="Any colour"><input type="color" data-an-well="hl" value="#ffe066"></label></span>
          <span class="an-ul-set" hidden>${sw(Annotate.UNDERLINES, 'ul')}
            <label class="an-well" title="Any colour"><input type="color" data-an-well="ul" value="#e03131"></label></span>
          <span class="an-note-set" hidden>${sw(Annotate.NOTES, 'note')}
            <label class="an-well" title="Any colour"><input type="color" data-an-well="note" value="#fff3b0"></label></span>
          <span class="an-pen-set" hidden>${sw(Annotate.PENS, 'pen')}
            <label class="an-well" title="Any colour"><input type="color" data-an-well="pen" value="#12110f"></label>
            <span class="an-widths">${Annotate.WIDTHS.map((w, i) =>
              `<button type="button" class="an-w ${i === 1 ? 'is-on' : ''}" data-an-w="${w.w}"
                title="${esc(w.name)}" aria-label="${esc(w.name)}"><i style="height:${Math.max(2, w.w)}px"></i></button>`).join('')}</span>
          </span>
        </div>
        <div class="an-acts">
          <button type="button" class="rd-btn an-mini" data-an-undo title="Undo" aria-label="Undo">↶</button>
          <button type="button" class="rd-btn an-mini" data-an-redo title="Redo" aria-label="Redo">↷</button>
          <button type="button" class="rd-btn an-mini" data-an-clear title="Clear every mark" aria-label="Clear every mark">⌫</button>
        </div>
      </div>`;
  }

  /** The pictures a question puts in front of the candidate, in the
      article. Tapping one opens the same zoom viewer the rest of AUREUM
      uses — there is one of those and this is not a second. */
  function rdImages(q) {
    const ims = imagesOf(q);
    if (!ims.length) return '';
    return `<div class="rd-imgs ${ims.length > 1 ? 'is-many' : ''}">
      ${ims.map(im => `
        <figure class="rd-img">
          <button class="rd-img-b" data-zoom="${esc(im.url)}" data-cap="${esc(im.caption)}"
            aria-label="${esc(im.caption || 'Enlarge the image')}">
            <img src="${esc(im.url)}" alt="${esc(im.caption || 'Image shown with this question')}" loading="lazy">
          </button>
          ${im.caption ? `<figcaption>${esc(im.caption)}</figcaption>` : ''}
        </figure>`).join('')}
    </div>`;
  }

  /** The scheme, set as an article. */
  function readingMode(st) {
    document.querySelector('.rd-veil')?.remove();
    const qs = qsOf(st);
    const total = marksOf(st);
    const pts = ptCount(st);

    /* EVERY BLOCK A MARK CAN ATTACH TO CARRIES A STABLE KEY.

       Derived from the station's own structure — q3.p5 is the fifth
       marking point of the third question — and never from position in
       the DOM, so a highlight cannot move to a different sentence the
       next time the page is drawn. See js/annotate.js. */
    const pointList = (q, qi) => {
      const all = q.marking_points || [];
      if (!all.length) return '<p class="rd-none">No marking points are recorded for this question.</p>';
      let out = '', open = false;
      all.forEach((p, pi) => {
        if (isHeading(p)) {
          if (open) { out += '</ul>'; open = false; }
          out += `<h4 class="rd-sec" data-an="q${qi}.h${pi}">${esc(headText(p) || 'Section')}</h4>`;
          return;
        }
        if (!open) { out += '<ul class="rd-points">'; open = true; }
        out += `<li data-an="q${qi}.p${pi}">${esc(p)}</li>`;
      });
      if (open) out += '</ul>';
      return out;
    };

    const wrap = document.createElement('div');
    wrap.className = 'rd-veil';
    wrap.innerHTML = `
      <div class="rd-bar">
        <span class="rd-bar-t">Reading mode</span>
        ${typeof Annotate !== 'undefined' ? annToolbar() : ''}
        <div class="rd-bar-acts">
          <span class="rd-saved" id="rd-saved"></span>
          <span class="rd-zoom" role="group" aria-label="Text size">
            <button class="rd-btn" data-rd-zoom="-1" type="button" title="Smaller text" aria-label="Smaller text">−</button>
            <button class="rd-zoom-n rd-btn" data-rd-zoom="0" type="button"
              title="Back to the normal size" aria-label="Text size, tap to reset">100%</button>
            <button class="rd-btn" data-rd-zoom="1" type="button" title="Larger text" aria-label="Larger text">+</button>
          </span>
          <button class="rd-btn" data-rd-print type="button">Print / Save as PDF</button>
          <button class="rd-btn rd-x" data-rd-close type="button" aria-label="Close reading mode">✕</button>
        </div>
      </div>
      <div class="rd-scroll">
        <article class="rd-doc">
          <p class="rd-kicker">OSCE STATION · ${minsOf(st)} MINUTES · ${qs.length} QUESTION${qs.length === 1 ? '' : 'S'}</p>
          <h1 class="rd-h1" data-an="topic">${esc(st.topic || st.id)}</h1>
          ${st.created_by_name ? `<p class="rd-by">Written by ${esc(st.created_by_name)}</p>` : ''}

          ${st.scenario ? `<p class="rd-stand" data-an="scenario">${esc(st.scenario)}</p>` : ''}

          <div class="rd-facts">
            <div><b>${qs.length}</b><span>questions</span></div>
            <div><b>${total}</b><span>marks</span></div>
            <div><b>${pts}</b><span>marking points</span></div>
            <div><b>${minsOf(st)}</b><span>minutes</span></div>
          </div>

          ${rdPassMeter(st)}
          ${rdMarksChart(st)}

          ${hasRole(st) ? `<div class="rd-role">
            <h3>🎭 There is a role player</h3>
            <p>Somebody is in the chair. This is a conversation, not a viva — and what the character is holding
              back is part of the station. The brief is deliberately not reproduced here: reading it is being given
              the station.</p>
          </div>` : ''}

          ${qs.map((q, i) => `
            <section class="rd-q">
              <div class="rd-q-head">
                <span class="rd-q-n">Question ${i + 1}</span>
                <span class="rd-q-m">${q.marks} marks</span>
              </div>
              <h2 class="rd-q-t" data-an="q${i}.prompt">${esc(q.prompt || '')}</h2>
              ${q.reveal_before ? `<p class="rd-reveal" data-an="q${i}.reveal"><b>Revealed first:</b> ${esc(q.reveal_before)}</p>` : ''}
              ${/* THE IMAGES THEMSELVES, NOT A NOTE THAT THERE ARE SOME.

                    The first version printed "On the table: an image; an
                    image" — which is worse than useless on a station
                    whose first question is "interpret these scans". A
                    scheme you are revising from has to show the thing
                    the candidate is asked to look at. */''}
              ${rdImages(q)}
              ${pointList(q, i)}
            </section>`).join('')}

          <footer class="rd-foot">
            <p><strong>${esc(st.topic || st.id)}</strong> · the marking scheme as written, not a completed marking.</p>
            <p>Read on ${esc(new Date().toLocaleDateString('en-GB', { dateStyle: 'long' }))}.</p>
          </footer>
        </article>
      </div>`;
    document.body.appendChild(wrap);
    wireLightbox(wrap);
    /* The page behind must not scroll under the article — on a phone
       that is how you end up reading two documents at once. */
    try { document.documentElement.classList.add('is-printlock'); } catch {}

    const shut = () => {
      /* Anything not yet written goes now — closing the page must not be
         a way to lose a mark. */
      try { Annotate.unmount(); } catch {}
      wrap.remove(); releaseScroll();
      document.removeEventListener('keydown', onKey);
      window.removeEventListener('hashchange', shut);
    };
    const onKey = e => { if (e.key === 'Escape') shut(); };
    document.addEventListener('keydown', onKey);
    window.addEventListener('hashchange', shut);
    wrap.querySelector('[data-rd-close]').addEventListener('click', shut);
    /* Printing reuses the scheme printer rather than printing the veil:
       the printer already knows about page breaks, the role-player page
       and the tick boxes, and two ways to put this on paper would drift. */
    wrap.querySelector('[data-rd-print]').addEventListener('click', () => printScheme(st));

    /* ---------------- the marks ----------------

       Mounted after the article is in the document, because every
       position is measured from where the blocks actually are. The
       document key names WHAT is annotated, not where it was opened
       from, so the same marks are there whether this was reached from
       the bank or from a circuit. */
    if (typeof Annotate !== 'undefined') {
      const bar = wrap.querySelector('#an-bar');
      const saved = wrap.querySelector('#rd-saved');
      const art = wrap.querySelector('.rd-doc');
      const zn = wrap.querySelector('[data-rd-zoom="0"]');
      const sayState = err => {
        if (zn) zn.textContent = Math.round(Annotate.getZoom() * 100) + '%';
        if (!saved) return;
        if (err) { saved.className = 'rd-saved is-bad'; saved.textContent = String(err); return; }
        const n = Annotate.count();
        saved.className = 'rd-saved' + (Annotate.isDirty() ? ' is-saving' : '');
        saved.textContent = !n ? '' : Annotate.isDirty() ? 'saving…'
          : `${n} mark${n === 1 ? '' : 's'} saved`;
      };

      /* Two fingers do this too, while an instrument is held — see the
         zoom note in annotate.js. The buttons are here because a mouse
         has no pinch and because the number is worth showing. */
      wrap.querySelector('.rd-zoom')?.addEventListener('click', e => {
        const b = e.target.closest('[data-rd-zoom]');
        if (!b) return;
        const d = Number(b.dataset.rdZoom);
        if (!d) Annotate.setZoom(1); else Annotate.zoomBy(d * 0.1);
        sayState();
      });
      Annotate.mount(art, wrap.querySelector('.rd-scroll'), 'osce:' + st.id, sayState);

      bar?.addEventListener('click', e => {
        const t = e.target.closest('[data-an-t]');
        if (t) {
          bar.querySelectorAll('[data-an-t]').forEach(b => b.classList.toggle('is-on', b === t));
          Annotate.setTool(t.dataset.anT);
          /* The colours shown are the ones the chosen tool uses. Showing
             all three sets at once means two thirds of the swatches do
             nothing. */
          const k = t.dataset.anT;
          bar.querySelector('.an-hl-set').hidden = k !== 'hl';
          bar.querySelector('.an-ul-set').hidden = k !== 'ul';
          bar.querySelector('.an-note-set').hidden = k !== 'note';
          bar.querySelector('.an-pen-set').hidden = k !== 'pen';
          return;
        }
        const c = e.target.closest('[data-an-c]');
        if (c) {
          const [kind, col] = c.dataset.anC.split('|');
          c.parentNode.querySelectorAll('[data-an-c]').forEach(x => x.classList.toggle('is-on', x === c));
          if (kind === 'hl') Annotate.setHighlightColour(col);
          else if (kind === 'ul') Annotate.setUnderlineColour(col);
          else if (kind === 'note') Annotate.setNoteColour(col);
          else Annotate.setPenColour(col);
          return;
        }
        const w = e.target.closest('[data-an-w]');
        if (w) {
          w.parentNode.querySelectorAll('[data-an-w]').forEach(x => x.classList.toggle('is-on', x === w));
          Annotate.setPenWidth(Number(w.dataset.anW));
          return;
        }
        if (e.target.closest('[data-an-undo]')) { Annotate.undo(); return; }
        if (e.target.closest('[data-an-redo]')) { Annotate.redo(); return; }
        if (e.target.closest('[data-an-clear]')) {
          const b = e.target.closest('[data-an-clear]');
          /* Asked twice: this is the one control that throws work away. */
          if (b.dataset.sure !== '1') {
            b.dataset.sure = '1'; b.textContent = 'Sure?';
            setTimeout(() => { if (b.dataset.sure === '1') { b.dataset.sure = ''; b.textContent = '⌫'; } }, 3500);
            return;
          }
          b.dataset.sure = ''; b.textContent = '⌫';
          Annotate.clearAll();
        }
      });
      bar?.addEventListener('input', e => {
        const w = e.target.closest('[data-an-well]');
        if (!w) return;
        /* The well is the platform's own picker, so "unlimited colours"
           costs one input rather than a colour wheel of our own. */
        if (w.dataset.anWell === 'hl') Annotate.setHighlightColour(w.value);
        else if (w.dataset.anWell === 'ul') Annotate.setUnderlineColour(w.value);
        else if (w.dataset.anWell === 'note') Annotate.setNoteColour(w.value);
        else Annotate.setPenColour(w.value);
        w.closest('span')?.querySelectorAll('[data-an-c]').forEach(x => x.classList.remove('is-on'));
      });

      /* A FALLBACK, AND ONLY THAT. Marking belongs to the module now:
         the highlighter paints from the nib's own position while the
         hand is still moving, and never selects any text — see "the
         marker" in annotate.js. This catches the one case left, a
         browser that reached the text anyway and made a selection, and
         it costs nothing when there is none. */
      const onRelease = () => {
        const t = Annotate.getTool();
        if (t !== 'hl' && t !== 'ul') return;
        const sel = window.getSelection();
        if (!sel || sel.isCollapsed) return;
        Annotate.markSelection(t);
      };
      art.addEventListener('mouseup', onRelease);
      art.addEventListener('touchend', onRelease);
      /* Re-measured once the images have loaded: a picture that arrives
         late moves everything below it, and every mark's position is
         derived from where its block is now. */
      art.querySelectorAll('img').forEach(im => im.addEventListener('load', () => Annotate.render()));
    }

    requestAnimationFrame(() => wrap.classList.add('is-in'));
    return shut;
  }

  /* ---------------- the scheme, in a dialog ----------------
     Every question and every marking point, exactly as a station will be
     marked. Opened BEFORE the clock starts on purpose: these stations mostly
     exist on paper as well, and the scheme is how you recognise which one
     this is. It is also the fastest route into the editor when a point is
     wrong. */
  /* ---------------- editing a point where you are reading it ----------------
     A pencil on every marking point, wherever a scheme is drawn. It reads
     and writes the WHOLE station through the normal publish path, so an
     inline correction and an edit made in the full editor are the same
     write — there is no second way for a station to change, and therefore
     no second way for it to go wrong. The full editor is untouched and is
     still where questions, marks and images are managed. */
  const schemePencil = (qid, i) =>
    (typeof QuickEdit === 'undefined') ? '' : QuickEdit.pencil(QuickEdit.osceRef(qid, i), 'Edit this marking point');

  /* Move and remove. Rewriting a line was the only thing possible before —
     which is fine until the scheme is missing a point, and then you had to
     leave for the full editor and lose your place in the dialog. */
  const schemeOps = (qid, i) => (typeof QuickEdit === 'undefined') ? '' : `
    <span class="os-sch-ops">
      <button class="os-sch-op" data-qe-move="${esc(String(qid))}|${i}|-1" title="Move up" aria-label="Move up">↑</button>
      <button class="os-sch-op" data-qe-move="${esc(String(qid))}|${i}|1" title="Move down" aria-label="Move down">↓</button>
      <button class="os-sch-op is-x" data-qe-del="${esc(String(qid))}|${i}" title="Remove" aria-label="Remove">✕</button>
    </span>`;

  function wireSchemeEdit(host, stationId) {
    if (typeof QuickEdit === 'undefined' || !stationId) return;
    const api = {
      load: () => Backend.getOsceStation(stationId),
      find: QuickEdit.osceFind,
      save: async doc => { await Backend.publishOsceStation(doc); bustStations(); },
      onSaved: () => bustStations()
    };
    QuickEdit.attach(host, api);
    /* Adding, removing and moving CHANGE THE INDICES of every point after
       the one touched, and every pencil on screen carries an index. So the
       list is rebuilt from the saved station rather than patched in place —
       patching is how you end up editing point 5 and saving point 6.

       Only the scheme dialog draws these controls, so redrawing it is the
       whole of the job. */
    QuickEdit.attachOps(host, api, {
      redraw: async () => {
        fullCache.delete(stationId);
        const open = document.querySelector('.os-modal');
        if (!open) return;
        const st = await station(stationId);
        if (st) { open.remove(); showScheme(st); }
      }
    });
  }

  function showScheme(st) {
    document.querySelector('.os-modal')?.remove();
    const qs = qsOf(st);
    const wrap = document.createElement('div');
    wrap.className = 'os-modal';
    wrap.innerHTML = `
      <div class="os-modal-back" data-close></div>
      <div class="os-modal-box" role="dialog" aria-modal="true" aria-label="Marking scheme">
        <div class="os-modal-head">
          <div>
            <p class="kicker">MARKING SCHEME</p>
            <h3>${esc(st.topic || st.id)}</h3>
            <p class="muted tiny">${qs.length} question${qs.length === 1 ? '' : 's'} ·
              ${marksOf(st)} marks · ${ptCount(st)} marking points · ${passOf(st)} to pass</p>
          </div>
          <button class="os-modal-x" data-close aria-label="Close">✕</button>
        </div>
        <div class="os-modal-body">
          <p class="os-scenario">${esc(st.scenario || '')}</p>
          ${roleHtml(st, 'brief')}
          ${qs.map((q, i) => `
            <div class="os-sch-q">
              <div class="os-sch-h"><span class="os-sch-n">Q${i + 1}</span>
                <p>${esc(q.prompt || '')}</p><span class="os-sch-m">${q.marks} marks</span></div>
              ${q.reveal_before ? `<p class="os-sch-rev"><b>Revealed first:</b> ${esc(q.reveal_before)}</p>` : ''}
              ${imageStrip(q, 'is-small')}
              <ul class="os-sch-pts">${(q.marking_points || []).map((p, pi) => isHeading(p)
                ? `<li class="os-sch-head" data-qe-line><span class="qe-text">${esc(headText(p) || 'Untitled section')}</span>${
                    schemePencil(q.id, pi)}${schemeOps(q.id, pi)}</li>`
                : `<li data-qe-line><span class="qe-text">${esc(p)}</span>${schemePencil(q.id, pi)}${schemeOps(q.id, pi)}</li>`).join('')}
                <li class="os-sch-add">
                  <button class="btn btn-ghost btn-sm" data-qe-add="${esc(String(q.id))}|point">＋ marking point</button>
                  <button class="btn btn-ghost btn-sm" data-qe-add="${esc(String(q.id))}|head">＋ section heading</button>
                </li>
              </ul>
            </div>`).join('')}
        </div>
        <div class="os-modal-foot">
          ${st.edited_by ? `<span class="muted tiny">Last edited by ${esc(st.edited_by)}${
            st.edited_at ? ' on ' + esc(new Date(st.edited_at).toLocaleDateString('en-GB', { dateStyle: 'medium' })) : ''}</span>` : ''}
          <a class="btn btn-gold btn-sm" href="#/osce/mark/${encodeURIComponent(st.id)}">✍️ Mark somebody with it</a>
          <button class="btn btn-ghost btn-sm" id="os-sch-print">🖨 Print / Save as PDF</button>
          <a class="btn btn-ghost btn-sm" href="#/osce/edit/${encodeURIComponent(st.id)}">✎ Edit this scheme</a>
          <button class="btn btn-ghost btn-sm" data-close>Close</button>
        </div>
      </div>`;
    document.body.appendChild(wrap);
    wireLightbox(wrap);
    wireSchemeEdit(wrap, st.id);
    wrap.querySelector('#os-sch-print')?.addEventListener('click', () => printScheme(st));
    const shut = () => {
      wrap.remove();
      document.removeEventListener('keydown', onKey);
      window.removeEventListener('hashchange', shut);
    };
    /* The dialog lives on the BODY, so replacing #view does not remove it —
       navigate away with the scheme open and it stayed floating over the
       next page, swallowing clicks. Anything mounted outside the view has
       to take itself down. */
    window.addEventListener('hashchange', shut);
    const onKey = e => {
      // an open edit box owns Escape; the dialog only gets it when nothing
      // smaller is open inside it
      if (e.key !== 'Escape') return;
      if (document.querySelector('.os-lightbox') || wrap.querySelector('.qe-input') || document.querySelector('.qe-ask')) return;
      shut();
    };
    wrap.querySelectorAll('[data-close]').forEach(b => b.addEventListener('click', shut));
    wrap.querySelector('.os-modal-foot a').addEventListener('click', shut);
    document.addEventListener('keydown', onKey);
  }

  /* ================= my attempts (#/osce/mine) =================
     Every station already sat, with its score, so a past OSCE can be
     reopened from the OSCE tab instead of going round by the dashboard.
     The rows are the light attempt cards — no answers, no schemes — so this
     page costs a few KB however many stations have been sat. */

  /** A marksheet left open — surfaced so it is not lost behind a tab. */
  function openSheetStrip() {
    if (typeof Marksheet === 'undefined') return '';
    const sheets = Marksheet.openSheets();
    if (!sheets.length) return '';
    return `<div class="card os-sheet-open" data-animate>
      <h3 class="card-title">✍️ Marking in progress</h3>
      ${sheets.map(sh => `<div class="os-sheet-row">
        <span><strong>${esc(sh.topic || sh.station_id)}</strong>
          <em class="muted tiny">${sh.candidate ? esc(sh.candidate) : 'no name yet'} ·
            started ${esc(new Date(sh.started || Date.now()).toLocaleTimeString('en-GB', { timeStyle: 'short' }))}</em></span>
        <span><a class="btn btn-gold btn-sm" href="#/osce/mark/${encodeURIComponent(sh.station_id)}">Carry on →</a>
          <button class="btn btn-ghost btn-sm qr-danger" data-sheetdrop="${esc(sh.station_id)}">Discard</button></span>
      </div>`).join('')}
    </div>`;
  }

  async function renderMine(view, user) {
    view.innerHTML = shell('mine', `<div id="os-body"><p class="muted">Loading your attempts…</p></div>`);
    FX.viewIn(view);
    let past = [];
    try { past = (await myAttempts()) || []; }
    catch (e) {
      view.querySelector('#os-body').innerHTML = `<p class="bad">${esc(e.message || e)}</p>`; return;
    }
    const body = view.querySelector('#os-body');
    /* Stations that were recorded but never marked. Drawn ABOVE the marked
       ones and before the empty state, because a queue of unsent work is
       the most urgent thing on this page — and because "nothing sat yet"
       would be a lie while three recordings are waiting. */
    const queueHtml = openSheetStrip() + await pendingPanel(user);
    if (!past.length) {
      body.innerHTML = queueHtml + `<div class="card" data-animate>
        <h3 class="card-title">Nothing marked yet</h3>
        <p class="muted">Once you have sat a station and had it marked, it appears here — the marks, the scheme point by
          point, what you said, and the recording for its first 24 hours.</p>
        <a class="btn btn-gold" href="#/osce">Go to the station bank</a></div>
        <div id="os-bring"></div>`;
      wirePending(view, user);
      /* The importer belongs on the EMPTY page most of all: somebody
         holding their first Claude-marked JSON has nothing else here, and
         returning early used to leave them with no route at all. */
      try { AiOsce?.attemptsPanel?.(body.querySelector('#os-bring'), user, () => renderMine(view, user)); } catch {}
      return;
    }
    const rows = past.slice().sort((a, b) => (b.created || 0) - (a.created || 0));
    const byHand = rows.filter(a => a.source === 'manual').length;
    const byClaude = rows.filter(a => a.source === 'claude').length;
    const full = rows.filter(a => !a.result?.partial);
    const passed = full.filter(a => a.result?.pass).length;
    const avg = full.length ? Math.round(full.reduce((s, a) => s + (a.result?.percent || 0), 0) / full.length) : 0;
    const best = {};
    rows.forEach(a => { const p = a.result?.percent; if (p != null && (best[a.station_id] == null || p > best[a.station_id])) best[a.station_id] = p; });

    body.innerHTML = queueHtml + `
      <header data-animate>
        <p class="kicker">EVERY STATION YOU HAVE SAT</p>
        <h1 class="page-title">My attempts</h1>
        <p class="muted">Open one to see the marking point by point, what you said, and — for the first day — the
          recording. Sitting the same station again is the fastest way to find out whether the feedback stuck.</p>
      </header>

      <div class="os-stats" data-animate>
        <div class="os-stat"><strong>${rows.length}</strong><span>Attempts</span></div>
        <div class="os-stat"><strong>${Object.keys(best).length}</strong><span>Stations tried</span></div>
        <div class="os-stat"><strong>${passed}</strong><span>Passed</span></div>
        <div class="os-stat"><strong>${avg}%</strong><span>Average</span></div>
        ${byHand ? `<div class="os-stat"><strong>${byHand}</strong><span>Marked in person</span></div>` : ''}
        ${byClaude ? `<div class="os-stat"><strong>${byClaude}</strong><span>Marked by Claude</span></div>` : ''}
      </div>

      ${attemptTable(rows.filter(a => a.source !== 'manual' && a.source !== 'claude'), 'ai')}
      ${attemptTable(rows.filter(a => a.source === 'manual'), 'manual')}
      ${attemptTable(rows.filter(a => a.source === 'claude'), 'claude')}
      <div id="os-bring"></div>`;
    wirePending(view, user);
    /* The way back in for an OSCE sat against a chat model. It lives here
       rather than only on the session screen, because the JSON often arrives
       a day later, in a file, from a session whose recording never started. */
    try { AiOsce?.attemptsPanel?.(body.querySelector('#os-bring'), user, () => renderMine(view, user)); } catch {}
  }

  /* ---------------- two kinds of attempt, kept apart ----------------

     A station marked by a model from a recording and a station marked by a
     person sitting opposite you are both real, and neither is a substitute
     for the other. Running them together in one list would make "how am I
     doing" a question with a misleading answer — a good week of face-to-face
     practice would look like a jump in AI performance, and a hard examiner
     would look like a regression.

     So: two tables, each labelled, each explaining what it is. Everything
     downstream — the report, the print sheet, sitting it again — is
     identical, because the attempt itself is the same shape. */
  /* Both sections fold. Which one is open is remembered per person, because
     somebody deep in face-to-face practice wants the hand-marked list open
     and the AI list out of the way, and the opposite is equally true. */
  const FOLD_KEY = 'aureum.osce.attemptfold';
  const foldState = () => { try { return JSON.parse(localStorage.getItem(FOLD_KEY) || '{}'); } catch { return {}; } };
  const setFold = (k, open) => { try { const f = foldState(); f[k] = !!open; localStorage.setItem(FOLD_KEY, JSON.stringify(f)); } catch {} };

  /* Three kinds now, and each is a different thing being measured:

       ai      — sat here, recorded, marked by our marker from the tape
       manual  — sat opposite a person holding the scheme
       claude  — sat against a chat model that examined AND marked it

     Keeping them apart is not tidiness. Averaged together, "how am I doing"
     stops meaning anything: a week of hard face-to-face marking reads as a
     collapse, and a generous AI examiner reads as progress. */
  const KINDS = {
    ai:     { icon: '🎙', label: 'Marked by AI',
              note: 'Sat here, recorded, and marked against the scheme by a model.' },
    manual: { icon: '✍️', label: 'Marked in person',
              note: 'Sat face to face with somebody holding the scheme. No recording — the marks are their judgement, point by point.' },
    claude: { icon: '✦', label: 'Marked by Claude',
              note: 'Examined out loud by a chat model on the other half of the screen, then marked by it against the same scheme. The recording is ours; the marking is its.' }
  };

  function attemptTable(rows, kind) {
    const manual = kind === 'manual';
    const K = KINDS[kind] || KINDS.ai;
    if (!rows.length) {
      return kind === 'ai' ? `<div class="card" data-animate><p class="muted">Nothing marked by AI yet.</p></div>` : '';
    }
    const f = foldState();
    const open = f[kind] !== false;        // open unless it has been shut
    return `
      <details class="card os-att-fold ${manual ? 'os-hand-card' : ''} ${kind === 'claude' ? 'os-claude-card' : ''}" data-animate data-foldkey="${kind}"${open ? ' open' : ''}>
        <summary>
          <h3 class="card-title">${K.icon} ${K.label}
            <span class="os-tbl-n">${rows.length}</span></h3>
          <span class="os-att-sum">${summarise(rows)}</span>
          <span class="dc-caret">▾</span>
        </summary>
        <p class="muted tiny">${K.note}</p>
        <div class="table-scroll"><table class="table">
          <thead><tr><th>When</th><th>Station</th>${manual ? '<th>Examiner</th>' : ''}<th>Score</th><th>Result</th><th></th></tr></thead>
          <tbody>${rows.map(a => {
            const r = a.result || {};
            return `<tr>
              <td class="muted">${esc(new Date(a.created || Date.now()).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' }))}</td>
              <td>${esc(a.topic || a.station_id || '')}</td>
              ${manual ? `<td class="muted tiny">${esc(a.examiner || '—')}</td>` : ''}
              <td><strong>${r.total ?? '—'}/${r.max ?? '—'}</strong> · ${r.percent ?? '—'}%</td>
              <td>${r.partial ? `<span class="warn">Part-marked · ${r.partial.marked}/${r.partial.of} questions</span>`
                : r.pass ? '<span class="good">Pass</span>' : '<span class="bad">Below the pass mark</span>'}</td>
              <td><a class="link" href="#/osce/result/${encodeURIComponent(a.id)}">Open →</a>
                  <a class="link" href="#/osce/station/${encodeURIComponent(a.station_id)}">Sit again</a></td>
            </tr>`;
          }).join('')}</tbody>
        </table></div>
      </details>`;
  }

  /* The one line that has to be right when the section is shut: how many,
     how many passed, and the average. Folding something away should not
     mean losing sight of it. */
  function summarise(rows) {
    const n = rows.length;
    /* A part-marked attempt has no verdict and a percentage out of a
       different denominator, so it is counted in neither figure — and said
       separately rather than quietly dropped. */
    const full = rows.filter(a => !a.result?.partial);
    const part = n - full.length;
    const passed = full.filter(a => a.result?.pass).length;
    const avg = Math.round(full.reduce((t, a) => t + (a.result?.percent || 0), 0) / Math.max(1, full.length));
    if (!full.length) return `${n} part-marked`;
    return `${passed}/${full.length} passed · ${avg}% average${part ? ` · ${part} part-marked` : ''}`;
  }

  /* ================= stations recorded but never marked =================

     WHY THIS EXISTS

     You sit a station on a ward round with one bar of signal, press Mark,
     and the request fails. Before this, that was the end of it: an error
     on screen, the recording alive only in a variable, and the moment the
     tab closed the fifteen minutes were gone with it. Nothing on the site
     remembered the station had ever been sat.

     Now the tape is written to the browser's own store BEFORE the model is
     called, so a failed marking costs a retry and never the station.

     IT NEVER SENDS BY ITSELF. Sending spends credit, and credit is spent
     by a person pressing a button — not by a background task that decided
     the signal looked better. It says it is ready; the press is yours. */

  /* THE TAPE, FROM WHEREVER IT IS STILL READABLE.

     There are two copies of a recording that failed to mark: the local one
     in the queue, and the one in storage for 24 hours. The local one is
     tried first because it needs no network — but a Blob that will not
     read is not a Blob, and rather than reporting "could not read the
     recording" and stopping, the server copy is fetched instead. Two
     copies exist precisely so that one of them can fail. */
  async function usableTape(row, say) {
    if (row.blob) {
      // prove it is readable rather than assuming: this is the exact point
      // where a dead IndexedDB Blob used to take the station down with it
      try {
        await row.blob.slice(0, 1).arrayBuffer();
        return row.blob;
      } catch { say?.('That copy could not be read — fetching the one on the server…'); }
    }
    const path = row.payload?.audioPath;
    if (!path) return null;
    try {
      const url = await Backend.getOsceAudioUrl(path);
      if (!url) return null;
      const res = await fetch(url);
      if (!res.ok) return null;
      return await res.blob();
    } catch { return null; }
  }

  async function pendingPanel(user) {
    if (typeof Pending === 'undefined') return '';
    try { Pending.setOwner(user?.email || ''); } catch {}
    let rows = [];
    try { rows = (await Pending.all()).filter(r => r.kind === 'osce'); } catch { return ''; }
    if (!rows.length) return '';
    const online = navigator.onLine !== false;
    return `
      <div class="card os-pendbox" data-animate>
        <h3 class="card-title">⏳ Recorded, not yet marked <span class="os-pend-pill">${rows.length}</span></h3>
        <p class="muted">These stations were sat and recorded, but the marking did not go through — the connection
          was not there when you pressed. Nothing has been lost. ${online
            ? 'You are online now, so they can be sent.'
            : '<strong>This device is offline.</strong> They will send once you have signal.'}</p>
        <div class="os-pend-list">
          ${rows.map(r => `
            <div class="os-pend-row">
              <div>
                <strong>${esc(r.title || r.id)}</strong>
                <em class="muted tiny">${esc(new Date(r.at).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' }))}
                  · ${fmt(r.secs || 0)}${r.blob ? ` · ${(r.blob.size / 1048576).toFixed(1)} MB` : ' · recording gone'}</em>
                <em class="muted tiny os-pend-why">${esc(Pending.reasonLine(r))}</em>
              </div>
              <div class="os-pend-acts">
                ${r.blob ? `<button class="btn btn-ghost btn-sm" data-pdl="${esc(r.id)}" title="Download the recording">⬇</button>` : ''}
                <button class="btn btn-gold btn-sm" data-psend="${esc(r.id)}" ${online ? '' : 'disabled'}>Send for marking</button>
                <button class="btn btn-ghost btn-sm qr-danger" data-pdel="${esc(r.id)}">Discard</button>
              </div>
            </div>`).join('')}
        </div>
        <p class="os-pend-msg" id="os-pend-msg"></p>
      </div>`;
  }

  function wirePending(view, user) {
    view.querySelectorAll('[data-foldkey]').forEach(d => d.addEventListener('toggle', () => {
      setFold(d.dataset.foldkey, d.open);
    }));
    view.querySelectorAll('[data-sheetdrop]').forEach(b => b.addEventListener('click', () => {
      if (!confirm('Discard that marking sheet? The ticks so far are not kept.')) return;
      Marksheet.wipe(b.dataset.sheetdrop);
      renderMine(view, user);
    }));
    if (typeof Pending === 'undefined') return;
    const msg = view.querySelector('#os-pend-msg');
    const say = h => { if (msg) msg.innerHTML = h; };

    view.querySelectorAll('[data-pdel]').forEach(b => b.addEventListener('click', async () => {
      if (!confirm('Discard that recording? It cannot be recovered.')) return;
      await Pending.drop(b.dataset.pdel);
      renderMine(view, user);
    }));

    view.querySelectorAll('[data-pdl]').forEach(b => b.addEventListener('click', async () => {
      const row = await Pending.get(b.dataset.pdl);
      if (!row?.blob) return;
      const url = URL.createObjectURL(row.blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `OSCE-${String(row.title || 'station').replace(/[^a-z0-9]+/gi, '-')}.${/mp4|aac/.test(row.mime || '') ? 'm4a' : 'webm'}`;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
    }));

    view.querySelectorAll('[data-psend]').forEach(b => b.addEventListener('click', async () => {
      const row = await Pending.get(b.dataset.psend);
      if (!row) return;
      b.disabled = true;
      say('<span class="muted">Loading the station…</span>');
      try {
        const st = await Backend.getOsceStation(row.payload.station_id);
        if (!st) throw new Error('That station is no longer in the bank.');
        const choice = modelChoices().find(m => m.key === row.payload.choiceKey) || chosenModel();
        const blob = await usableTape(row, t => say(`<span class="muted">${esc(t)}</span>`));
        const rec = blob
          ? { blob, mime: blob.type || row.mime, ext: /mp4|aac/.test(blob.type || row.mime || '') ? 'm4a' : 'webm',
              secs: row.secs || 0, bytes: blob.size, url: '' }
          : null;
        say('<span class="muted">Marking…</span>');
        const attempt = await markCore({
          st, ans: row.payload.answers || {}, rec, session: null, choice,
          attemptId: row.id, stamp: row.payload.stamp || null,
          kept: row.payload.audioPath ? { path: row.payload.audioPath, expires: row.payload.audioExpires } : null,
          say: t => say(`<span class="muted">${esc(t)}</span>`)
        });
        location.hash = '#/osce/result/' + encodeURIComponent(attempt.id);
      } catch (e) {
        b.disabled = false;
        say(`<span class="bad">${esc(e.message || e)}</span>`);
      }
    }));
  }

  /* ================= the station editor (#/osce/edit[/:id]) =================
     The same editor the developer console has, in the OSCE tab, so anyone
     preparing can fix a scheme. Saving is open to signed-in users; deleting
     a station is not — see the policy note in supabase/schema.sql. Every
     save records who made it. */

  async function renderEdit(view, id, user) {
    if (!user) {
      view.innerHTML = shell('edit', `<div class="card" data-animate><h3 class="card-title">Sign in to edit</h3>
        <p class="muted">Stations are shared by everyone using AUREUM, so an edit has to have a name against it.</p></div>`);
      FX.viewIn(view); return;
    }
    view.innerHTML = shell('edit', `<div id="os-body"><p class="muted">Loading the stations…</p></div>`);
    FX.viewIn(view);
    const [list, colls] = await Promise.all([stations().catch(() => []), collections().catch(() => [])]);
    const body = view.querySelector('#os-body');
    body.innerHTML = `
      <header data-animate>
        <p class="kicker">STATION EDITOR</p>
        <h1 class="page-title">Edit a station</h1>
        <p class="muted">Change the scenario, the marks, the pass mark, and every question with its marking points.
          Everyone sitting these stations sees the change, so edits are signed with your name.</p>
      </header>
      <div class="es-search-wrap" data-animate>
        <div class="es-search-row">
          <span class="es-search-ico">🔎</span>
          <input type="search" id="oe-find" class="es-search" autocomplete="off"
            placeholder="Find the station to edit — e.g. HELLP, cord prolapse">
        </div>
      </div>
      <div class="os-edit-list" id="oe-list" data-animate></div>
      <div id="os-editor"></div>`;

    const host = body.querySelector('#oe-list');
    const paintList = filter => {
      const f = String(filter || '').trim().toLowerCase();
      const rows = list.filter(s => !f || `${s.topic || ''} ${s.scenario || ''}`.toLowerCase().includes(f));
      host.innerHTML = rows.length ? rows.slice(0, 60).map(s => `
        <button class="os-edit-row" data-edit="${esc(s.id)}">
          <span class="os-edit-t">${esc(s.topic || s.id)}</span>
          <span class="os-edit-m">${qCount(s)} q · ${ptCount(s)} points · ${marksOf(s)} marks</span>
          <span class="os-edit-c">${esc(collLabel(colls, s.collection || ''))}</span>
          <span class="os-edit-go">Edit →</span>
        </button>`).join('') + (rows.length > 60 ? `<p class="muted tiny">${rows.length - 60} more — narrow the search.</p>` : '')
        : `<p class="muted">No station matches that.</p>`;
    };
    paintList('');
    body.querySelector('#oe-find').addEventListener('input', e => paintList(e.target.value));
    host.addEventListener('click', e => {
      const b = e.target.closest('[data-edit]'); if (!b) return;
      location.hash = '#/osce/edit/' + encodeURIComponent(b.dataset.edit);
    });

    if (id) await openEditor(view, id, colls);
  }

  async function openEditor(view, id, colls) {
    const eh = view.querySelector('#os-editor');
    if (!eh) return;
    eh.innerHTML = '<p class="muted">Loading the station…</p>';
    eh.scrollIntoView({ behavior: 'smooth', block: 'start' });
    let st = null;
    try { st = await station(id); } catch {}
    if (!st || !qsOf(st).length) { eh.innerHTML = '<p class="bad">Could not load that station.</p>'; return; }
    if (typeof DevConsole === 'undefined' || !DevConsole.osceEditor) {
      eh.innerHTML = '<p class="bad">The editor could not be loaded.</p>'; return;
    }
    DevConsole.osceEditor(eh, st, colls, () => {
      fullCache.delete(id); bustStations();
      location.hash = '#/osce/edit';
    });
  }

  /* ================= the simulator (#/osce/sim) ================= */

  async function renderSim(view, user, query) {
    const list = await stations().catch(() => []);   // cards only — the circuit needs names, not schemes
    if (typeof Stars !== 'undefined') { try { await Stars.load(); } catch {} }
    if (typeof Bucket !== 'undefined') { try { await Bucket.load(); } catch {} }
    /* Arriving from the bucket bar: the round is already decided, and the
       page should open on it rather than on a draw nobody asked for. */
    const wantBucket = /(^|&)bucket=1(&|$)/.test(String(query || '').replace(/^\?/, ''))
      && typeof Bucket !== 'undefined' && Bucket.count() > 0;
    const modules = await OsceBlueprint.get().catch(() => []);
    let attempts = [];
    try { attempts = (await myAttempts()) || []; } catch {}
    const byId = {}; list.forEach(s => byId[s.id] = s);
    const history = OsceBlueprint.historyOf(attempts, byId);
    const tagged = list.filter(s => OsceBlueprint.tagOf(s));
    const modsWithStations = new Set(tagged.map(s => OsceBlueprint.tagOf(s).module));

    view.innerHTML = shell('sim', `
      <header data-animate>
        <p class="kicker">OSCE EXAM SIMULATOR</p>
        <h1 class="page-title">Build a circuit</h1>
        <p class="muted">The PGIM runs nine stations of fifteen minutes. Sit all nine, or as many as the time you have
          today allows — four stations is an hour. You can pause between stations, or in the middle of one, and pick
          the circuit up later exactly where you left it.</p>
      </header>

      <div class="card os-blind" data-animate>
        <h3 class="card-title">🙈 You will not be told the topic</h3>
        <p class="muted">In the real room the examiner reads you a scenario and starts asking. Nobody says
          “this is a pulmonary embolism station” first — and being told narrows the discussion before it begins.
          So a circuit shows you the scenario and nothing else. The topic, the module and the marking scheme appear
          when the station is over.</p>
      </div>

      <div class="card os-simset" data-animate>
        <h3 class="card-title">How many stations?</h3>
        <div class="os-count" id="os-count">
          ${[1, 2, 3, 4, 6, 8, 9, 12].map(n => `<button class="os-count-b ${n === 9 ? 'active' : ''}" data-n="${n}">
            <strong>${n}</strong><span>${hours(n * 15)}</span></button>`).join('')}
        </div>
        <p class="muted tiny" id="os-count-note"></p>

        <h3 class="card-title" style="margin-top:22px">Which stations?</h3>
        <div class="os-pickmode" id="os-pickmode">
          ${/* The bucket goes FIRST when there is something in it: a
                round somebody has already chosen beats every way of
                choosing one for them. */''}
          ${(typeof Bucket !== 'undefined' && Bucket.count())
            ? `<button class="os-pick-b ${wantBucket ? 'active' : ''}" data-mode="bucket">🧺 My bucket (${Bucket.count()})</button>` : ''}
          <button class="os-pick-b ${wantBucket ? '' : 'active'}" data-mode="blueprint">🗺 Across the blueprint</button>
          <button class="os-pick-b" data-mode="random">🎲 Surprise me</button>
          <button class="os-pick-b" data-mode="unseen">✦ Ones I haven't done</button>
          <button class="os-pick-b" data-mode="pick">☑ Let me choose</button>
        </div>
        <label class="os-fresh" id="os-freshwrap">
          <input type="checkbox" id="os-fresh">
          <span><strong>All stations must be new to me</strong><br>
            <span class="muted tiny" id="os-freshnote"></span></span>
        </label>
        ${/* LEAVING OUT THE ONES YOU HAVE ALREADY JUDGED.

              Nine stations is two and a quarter hours. Spending fifteen
              minutes of it on a station you have already decided is not
              worth your time is the most expensive thing this page can
              do, and until now there was no way to say so.

              Ticked by default the moment there is anything to leave out:
              having marked something ↓ IS the instruction, and having to
              repeat it on every circuit would make the mark pointless.
              It is still a tick and not a rule — untick it and they come
              back, because "less important" is not "never again". */''}
        <label class="os-fresh os-skiplow" id="os-lowwrap" hidden>
          <input type="checkbox" id="os-low" checked>
          <span><strong>Leave out the ones I marked ↓ less important</strong><br>
            <span class="muted tiny" id="os-lownote"></span></span>
        </label>

        <details class="dev-collapse os-simcoach" style="margin-top:14px" open>
          <summary><span class="card-title">Coaching on every station in this circuit</span><span class="dc-caret">▸</span></summary>
          <p class="muted tiny">Asked once here rather than nine times. Whatever is ticked is applied to every station
            in the round — the ones that need the recording are simply skipped on any station where nothing was
            captured.</p>
          <div id="os-sim-coach"></div>
        </details>
        <div id="os-picklist" hidden></div>
        <div id="os-bpnote"></div>

        <div class="os-simset-foot">
          <span class="muted tiny" id="os-sim-sum"></span>
          <button class="btn btn-gold btn-lg" id="os-sim-go">▶ Start the circuit</button>
        </div>
      </div>

      ${list.length ? '' : `<div class="card"><p class="muted">No stations are published yet, so a circuit cannot be built.</p></div>`}`);
    FX.viewIn(view);
    if (!list.length) return;

    let want = 9, mode = wantBucket ? 'bucket' : 'blueprint', chosen = new Set(), freshOnly = false, skipLow = true;
    let done = new Set();
    attempts.forEach(a => done.add(a.station_id));

    /* The bank priorities and the module weights, worked out once. Weight is
       a property of the bank as it stands today — how many topics a module
       actually has stations for, and how many stations those are — so it is
       recomputed on every visit rather than stored and left to rot. */
    const colls = await collections().catch(() => []);
    const priorities = {};
    colls.forEach(c => priorities[c.id] = Number(c.priority ?? (c.id === 'common' ? 1 : 3)));
    const weights = OsceBlueprint.moduleWeights(modules, tagged);

    const pickHost = view.querySelector('#os-picklist');
    const bpNote = view.querySelector('#os-bpnote');
    const sum = view.querySelector('#os-sim-sum');
    const note = view.querySelector('#os-count-note');
    const freshBox = view.querySelector('#os-fresh');
    const freshNote = view.querySelector('#os-freshnote');

    /* The circuit is settled ONCE, when the button is pressed — not on every
       repaint. A pool that reshuffled itself as you looked at it made the
       summary a lie about what you were going to sit. */
    /* The stations this candidate has pushed down, taken out of the draw
       before any other rule runs — including the blueprint balance, which
       would otherwise reach for one to fill a module. Choosing by hand is
       exempt: a station you have just ticked yourself is a station you
       want, whatever you thought of it last month. */
    const lowSet = () => (skipLow && typeof Stars !== 'undefined')
      ? new Set(Stars.idsAt(Stars.LOW)) : new Set();
    const dropLow = arr => { const l = lowSet(); return l.size ? arr.filter(s => !l.has(s.id)) : arr; };

    function pool() {
      /* THE BUCKET IS NOT A DRAW. Everything in it, in the order it was
         collected, and the count control does not apply — you chose
         these one at a time and choosing them again by a number would be
         the page overruling you. */
      if (mode === 'bucket') {
        const byId = {}; list.forEach(s => byId[s.id] = s);
        return Bucket.ids().map(id => byId[id]).filter(Boolean);
      }
      if (mode === 'pick') return list.filter(s => chosen.has(s.id));
      const bank = dropLow(list);
      const bankTagged = dropLow(tagged);
      if (mode === 'blueprint' && bankTagged.length) {
        const c = OsceBlueprint.buildCircuit(bankTagged, history, want,
          { avoid: done, freshOnly, priorities, weights });
        if (c.length) return c;
      }
      /* The plain modes honour the tick too: "all new to me" is a promise
         about the circuit, not about one way of building it. */
      let src = (mode === 'unseen' || freshOnly) ? bank.filter(s => !done.has(s.id)) : bank.slice();
      if (!src.length && !freshOnly) src = bank.slice();
      const bag = src.slice();
      for (let i = bag.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [bag[i], bag[j]] = [bag[j], bag[i]]; }
      return bag.slice(0, want);
    }
    /* Nothing to do, named rather than left as a bare `return` — the
       bucket branch above exits early and a reader should see that
       nothing was skipped by accident. */
    const paintMadeNothing = () => {};

    function paint() {
      const p = pool();
      const mins = p.length * 15;
      const freshLeft = OsceBlueprint.freshCount(tagged, done);
      /* Say plainly when the tick cannot be honoured in full rather than
         quietly handing back a shorter circuit. */
      const short = freshOnly && p.length < want;
      if (mode === 'bucket') {
        sum.innerHTML = `<strong>${p.length}</strong> station${p.length === 1 ? '' : 's'} from your bucket ·
          ${hours(p.length * 15)}`;
        note.textContent = 'Everything in the bucket, in the order you collected it. How many is not a choice here — you already made it.';
        bpNote.innerHTML = `<p class="muted tiny os-bp-warn">These leave the bucket one at a time, as you sit them.
          End the round early and whatever you did not reach is still there tomorrow.</p>`;
        pickHost.hidden = true; pickHost.innerHTML = '';
        view.querySelector('#os-freshwrap').hidden = true;
        const lw = view.querySelector('#os-lowwrap'); if (lw) lw.hidden = true;
        view.querySelector('#os-count').classList.add('is-off');
        view.querySelector('#os-sim-go').disabled = !p.length;
        paintMadeNothing();
        return;
      }
      view.querySelector('#os-count').classList.remove('is-off');
      view.querySelector('#os-freshwrap').hidden = mode === 'pick';
      sum.innerHTML = p.length
        ? `<strong>${p.length}</strong> station${p.length === 1 ? '' : 's'} · ${hours(p.length * 15)}${
            short ? ` <span class="bad">— only ${p.length} new station${p.length === 1 ? '' : 's'} are left</span>` : ''}`
        : freshOnly ? '<span class="bad">You have sat every station already. Untick “all new to me” to revisit some.</span>'
        : 'Choose at least one station.';
      freshNote.textContent = `${freshLeft} of ${tagged.length} blueprint stations are still untried.`;
      view.querySelector('#os-freshwrap').classList.toggle('is-on', freshOnly);

      /* The ↓ tick appears only for somebody who has marked something.
         It also says what it is costing them — a candidate who has
         quietly excluded half the bank should be able to see that. */
      const lowN = (typeof Stars !== 'undefined') ? Stars.counts().low : 0;
      const lowWrap = view.querySelector('#os-lowwrap');
      if (lowWrap) {
        lowWrap.hidden = !lowN || mode === 'pick';
        lowWrap.classList.toggle('is-on', skipLow);
        const ln = view.querySelector('#os-lownote');
        if (ln) ln.textContent = skipLow
          ? `${lowN} station${lowN === 1 ? '' : 's'} you marked ↓ are out of this draw — ${list.length - lowN} left to draw from.`
          : `${lowN} station${lowN === 1 ? '' : 's'} you marked ↓ are back in the draw.`;
      }
      view.querySelector('#os-sim-go').disabled = !p.length;
      note.textContent = mode === 'unseen'
        ? `${list.filter(s => !done.has(s.id)).length} of ${list.length} stations are still untried.`
        : mode === 'blueprint'
          ? `${tagged.length} of ${list.length} stations are placed on the blueprint, across ${modsWithStations.size} modules.`
          : `${list.length} stations are published.`;

      /* What the balancing is about to do, said before it does it. The
         modules it will reach for are the ones sat least — so four stations
         today and four tomorrow cover eight modules, not the same four. */
      if (mode === 'blueprint') {
        if (!tagged.length) {
          bpNote.innerHTML = `<p class="muted tiny os-bp-warn">No station has been placed on the blueprint yet, so this
            falls back to a random draw. Tag them in <strong>Developer → OSCE stations</strong>.</p>`;
        } else {
          const covered = [...new Set(p.map(s => OsceBlueprint.tagOf(s)?.module).filter(Boolean))];
          const bands = {};
          p.forEach(s => { const b = OsceBlueprint.priorityOf(s, priorities); bands[b] = (bands[b] || 0) + 1; });
          const bandTxt = Object.keys(bands).sort((a, b) => b - a)
            .map(b => `${bands[b]} from priority ${b}`).join(', ');
          const heaviest = [...modsWithStations].sort((a, b) => (weights[b] || 0) - (weights[a] || 0))[0];
          bpNote.innerHTML = `<p class="muted tiny os-bp-warn">This draw spans
            <strong>${covered.length}</strong> module${covered.length === 1 ? '' : 's'}, taken from the ones you have sat
            least. Where you are equally behind, the bigger module goes first — ${
            esc(OsceBlueprint.moduleName(modules, heaviest))} is currently the largest slice of the blueprint.
            Banks: ${esc(bandTxt)}.
            <em>Which modules they are is not shown, for the same reason the topics are not.</em></p>`;
        }
      } else { bpNote.innerHTML = ''; }

      if (mode === 'pick') {
        pickHost.hidden = false;
        pickHost.innerHTML = `<div class="os-picks">${list.map(s => `
          <label class="os-pick ${chosen.has(s.id) ? 'is-on' : ''}">
            <input type="checkbox" data-pickst="${esc(s.id)}" ${chosen.has(s.id) ? 'checked' : ''}>
            <span><strong>${esc(s.topic || s.id)}</strong>${(() => {
              const m = (typeof Stars !== 'undefined') ? Stars.of(s.id) : '';
              return m === 'star' ? ' <i class="os-pick-star" title="you starred this">★</i>'
                : m === 'low' ? ' <i class="os-pick-low" title="you marked this less important">↓</i>' : '';
            })()}<em>${qCount(s)} questions · ${marksOf(s)} marks${done.has(s.id) ? ' · attempted' : ''}</em></span>
          </label>`).join('')}</div>`;
      } else { pickHost.hidden = true; pickHost.innerHTML = ''; }
    }
    view.querySelector('#os-count').addEventListener('click', e => {
      const b = e.target.closest('[data-n]'); if (!b) return;
      want = Number(b.dataset.n);
      view.querySelectorAll('.os-count-b').forEach(x => x.classList.toggle('active', x === b));
      paint();
    });
    view.querySelector('#os-pickmode').addEventListener('click', e => {
      const b = e.target.closest('[data-mode]'); if (!b) return;
      mode = b.dataset.mode;
      view.querySelectorAll('.os-pick-b').forEach(x => x.classList.toggle('active', x === b));
      /* Which controls apply is decided in one place — paint() — rather
         than half here and half there, or the bucket mode would re-show
         the ticks it has just explained do not apply to it. */
      paint();
    });
    freshBox.addEventListener('change', () => { freshOnly = freshBox.checked; paint(); });
    view.querySelector('#os-low')?.addEventListener('change', e => { skipLow = e.target.checked; paint(); });
    {
      // a circuit is recorded, so every option is answerable
      const ch = view.querySelector('#os-sim-coach');
      if (ch) { ch.innerHTML = coachPicker(true); wireCoachPicker(ch); }
    }
    pickHost.addEventListener('change', e => {
      const c = e.target.closest('[data-pickst]'); if (!c) return;
      c.checked ? chosen.add(c.dataset.pickst) : chosen.delete(c.dataset.pickst);
      c.closest('.os-pick').classList.toggle('is-on', c.checked);
      paint();
    });
    view.querySelector('#os-sim-go').addEventListener('click', async () => {
      const p = pool(); if (!p.length) return;
      const sid = 'os-' + Date.now().toString(36);
      /* `blind` travels with the session, so a circuit resumed tomorrow is
         still blind — the flag belongs to the sitting, not to the tab it
         was started in. Choosing the stations yourself cannot be blind:
         you have already read the list. */
      /* `fromBucket` travels with the session so that a station sat
         tomorrow, from a circuit resumed on another device, still knows
         to take itself out of the bucket. The alternative — checking the
         bucket at sitting time — would empty it for a station that was
         merely IN it while a different round was running. */
      await saveSession({ id: sid, stations: p.map(s => s.id), at: 0, phase: 'brief', answers: {}, elapsed: 0,
        started: Date.now(), circuit: true, blind: mode !== 'pick' && mode !== 'bucket',
        fromBucket: mode === 'bucket' });
      location.hash = '#/osce/run/' + sid;
    });
    paint();
  }

  /* ================= session state ================= */

  const sKey = id => 'osce:' + id;
  async function saveSession(s) {
    try { localStorage.setItem('aureum.' + sKey(s.id), JSON.stringify(s)); } catch {}
    try { await Backend.saveSession(sKey(s.id), s); } catch {}
    return s;
  }
  async function loadSession(id) {
    let local = null;
    try { local = JSON.parse(localStorage.getItem('aureum.' + sKey(id)) || 'null'); } catch {}
    if (local) return local;
    try { return await Backend.loadSession(sKey(id)); } catch { return null; }
  }
  async function dropSession(id) {
    try { localStorage.removeItem('aureum.' + sKey(id)); } catch {}
    try { localStorage.removeItem('aureum.' + mKey(id)); } catch {}
    try { await Backend.clearSession(sKey(id)); } catch {}
  }

  /* ---------------- where a circuit's marks live ----------------
     NOT inside the session. The runner holds its own copy of the session
     and writes it every five seconds; a result that the background marker
     had just recorded was being overwritten by that stale copy, and the
     station silently went back to "marking…" for ever. Two writers, one
     object, last-write-wins — the oldest bug in the book.

     The marks therefore get their own key, written only by the marker and
     read by the results page. Merging carefully would have worked; not
     sharing the object cannot go wrong in the first place. */
  const mKey = id => 'osce-marks:' + id;
  function loadMarks(sid) {
    try { return JSON.parse(localStorage.getItem('aureum.' + mKey(sid)) || '{}') || {}; } catch { return {}; }
  }
  function saveMark(sid, stationId, entry) {
    const all = loadMarks(sid);
    all[stationId] = Object.assign({}, all[stationId], entry);
    try { localStorage.setItem('aureum.' + mKey(sid), JSON.stringify(all)); } catch {}
    return all;
  }

  /* ================= the runner (#/osce/run/:sid) ================= */

  let live = null;         // the one running station's machinery

  async function renderRun(view, sid, user) {
    stopLive();
    const s = await loadSession(sid);
    if (!s) { location.hash = '#/osce'; return; }
    const st = await station(s.stations[s.at]);
    if (!st || !qsOf(st).length) { location.hash = '#/osce'; return; }
    /* A circuit resumed tomorrow lands here without passing the builder,
       so the marks are fetched here too — the brief reads them straight
       out of the module and must not find it empty. Cached after the
       first call, so this costs nothing on the other eight stations. */
    if (typeof Stars !== 'undefined') { try { await Stars.load(); } catch {} }

    const qs = qsOf(st);
    const total = minsOf(st) * 60;
    const ans = s.answers[st.id] || (s.answers[st.id] = {});
    let qi = s.qi || 0;
    let elapsed = s.elapsed || 0;
    let running = false, tid = null;

    /* A blind sitting never names the station while it is being sat. The
       title is the single biggest giveaway — reading "Pulmonary embolism"
       decides the differential before the candidate has heard the history,
       which is precisely the help the real room does not give. */
    const blind = !!s.blind;

    view.innerHTML = `
      <section class="page os-run${blind ? ' is-blind' : ''}">
        <div class="os-run-bar">
          <div class="os-run-id">
            <span class="os-run-n">${s.circuit ? `Station ${s.at + 1} of ${s.stations.length}` : 'Single station'}</span>
            <span class="os-run-topic">${blind ? '<em class="os-sealed">Topic sealed until the end</em>' : esc(st.topic || '')}</span>
          </div>
          <div class="os-clock" id="os-clock"><span id="os-time">${fmt(total - elapsed)}</span><i id="os-ring"></i></div>
          <div class="os-run-acts">
            <label class="os-pdial" title="How hard the examiner pushes you for the marks you have not said yet">
              <span class="os-pdial-l">Examiner<i id="os-pdial-v">${promptLevel()}</i></span>
              <input type="range" id="os-pdial" min="0" max="100" step="5" value="${promptLevel()}">
            </label>
            <button class="btn btn-ghost btn-sm" id="os-pause" hidden>⏸ Pause</button>
            <button class="btn btn-ghost btn-sm qr-danger" id="os-quit">Leave</button>
          </div>
        </div>
        <div class="os-progress"><i id="os-prog"></i></div>
        <div id="os-stage"></div>
      </section>`;
    FX.viewIn(view);

    const stage = view.querySelector('#os-stage');
    const timeEl = view.querySelector('#os-time');
    const ringEl = view.querySelector('#os-ring');
    const progEl = view.querySelector('#os-prog');
    const pauseBtn = view.querySelector('#os-pause');

    /* The dial is live: an examiner who is pushing too hard three questions
       in can be turned down without leaving the station. */
    const dial = view.querySelector('#os-pdial');
    const dialV = view.querySelector('#os-pdial-v');
    dial.addEventListener('input', () => {
      setPromptLevel(Number(dial.value));
      dialV.textContent = dial.value;
      dial.closest('.os-pdial').classList.toggle('is-off', Number(dial.value) === 0);
    });
    dial.closest('.os-pdial').classList.toggle('is-off', promptLevel() === 0);

    view.querySelector('#os-quit').addEventListener('click', () => {
      if (!confirm('Leave this station? Your answers so far are saved — you can resume from the OSCE tab.')) return;
      stopLive(); location.hash = '#/osce';
    });
    pauseBtn.addEventListener('click', () => running ? pause() : resume());

    /* ---- clock ---- */
    function paintClock() {
      const clock = view.querySelector('#os-clock');
      if (!clock) return;                       // the page has moved on
      const left = Math.max(0, total - elapsed);
      timeEl.textContent = fmt(left);
      const pct = Math.min(100, (elapsed / total) * 100);
      ringEl.style.width = pct + '%';
      clock.classList.toggle('is-low', left <= 120 && left > 0);
      clock.classList.toggle('is-out', left <= 0);
      progEl.style.width = (qs.length ? ((qi) / qs.length) * 100 : 0) + '%';
    }
    function tick() {
      /* Navigating away mid-station replaces the page under us, but the
         interval survives — it then ticks forever against a DOM that is gone,
         throwing on every second and holding the microphone open. Notice the
         page has moved on and stop properly. */
      if (!view.querySelector('#os-clock')) {
        clearInterval(tid); tid = null; running = false;
        persist(); stopLive();
        return;
      }
      elapsed += 1; paintClock();
      if (elapsed % 5 === 0) persist();
      if (elapsed >= total) { finish(true); }
    }
    function startClock() { if (tid) return; running = true; pauseBtn.hidden = false; pauseBtn.innerHTML = '⏸ Pause'; tid = setInterval(tick, 1000); }
    function pause() {
      running = false; if (tid) clearInterval(tid); tid = null;
      pauseBtn.innerHTML = '▶ Resume';
      live?.pause(); persist();
      stage.classList.add('is-paused');
      if (!stage.querySelector('.os-paused')) {
        const p = document.createElement('div');
        p.className = 'os-paused';
        p.innerHTML = `<div class="os-paused-in"><span>⏸</span><h3>Paused</h3>
          <p class="muted">The clock and the recording are stopped. Nothing is lost — press resume when you are back.</p>
          <button class="btn btn-gold" id="os-resume">▶ Resume the station</button></div>`;
        stage.appendChild(p);
        p.querySelector('#os-resume').addEventListener('click', resume);
      }
    }
    function resume() { stage.classList.remove('is-paused'); stage.querySelector('.os-paused')?.remove(); live?.resume(); startClock(); }
    function persist() { s.qi = qi; s.elapsed = elapsed; s.phase = qi >= qs.length ? 'done' : 'station'; saveSession(s); }

    /* The examiner's lines, fetched while the candidate reads the scenario.
       Prefetching is what makes a real voice usable: asking for the audio at
       the moment the question appears would put a network round trip in the
       middle of a timed station.

       Declared HERE, above the phase dispatch, because brief() starts the
       prefetch — and a `const` declared further down would still be in its
       temporal dead zone at that point. The rejection was being swallowed by
       the .catch() on the call, so it looked like the feature simply never
       ran. */
    const voices = new Map();
    let voicesReady = false;
    /* The generic nudges live up here for the SAME reason, and learning it
       twice was one time too many: brief() → prefetchVoices() →
       prefetchNudges() runs before the phase dispatch has finished, and a
       `const` further down is still in its dead zone. The ReferenceError
       went into the .catch() on the prefetch and the examiner simply never
       had a word to say. */
    const nudges = new Map();

    /* ---- the three phases ----
       A debrief re-entered (a circuit stepping back, a re-render) used to be
       called with no recording and would announce that none had been made.
       The tape from the station just finished is still in hand. */
    if (s.phase === 'done' || qi >= qs.length) { debrief(false, lastRec?.station === st.id ? lastRec.rec : null); }
    else if (s.phase === 'station' && elapsed > 0) { brief(true); }
    else { brief(false); }

    function brief(resuming) {
      paintClock();
      // read from what Stars already holds; a circuit page has loaded it
      const lowHere = (typeof Stars !== 'undefined') && Stars.low(st.id);
      stage.innerHTML = `
        <div class="os-sheet" data-animate>
          <p class="kicker">${resuming ? 'RESUMING' : 'READ THE SCENARIO'}</p>
          ${blind
            ? `<h2 class="os-blind-h">Station ${s.at + 1}</h2>
               <p class="muted tiny os-sealed-note">The examiner does not tell you what this station is about.
                 The topic and the marking scheme are revealed once the clock stops.</p>`
            : `<h2>${esc(st.topic || '')}</h2>`}
          <p class="os-scenario big">${esc(st.scenario || '')}</p>
          <p class="muted os-readnote">${resuming
            ? `You were ${fmt(elapsed)} into this station and had answered ${qi} of ${qs.length} questions. The clock picks up where it stopped.`
            : `The examiner allows about ${st.reading_time_min || 1} minute to read. The ${minsOf(st)}-minute clock and the
               recording both start when you press the button — question 1 appears at the same moment.`}</p>
          <div class="os-mic" id="os-mic"></div>
          ${/* CHOSEN BEFORE THE CLOCK, NOT DISCOVERED DURING IT.

                Which voice reads the questions is a preference, not a
                fault to be worked around, and it belongs here for the
                same reason the microphone test does: this is the last
                moment at which changing it costs nothing. */''}
          <div class="os-vsrc" id="os-vsrc">
            <div class="os-vsrc-row">
              <span class="os-vsrc-l">The examiner's voice</span>
              <div class="os-seg" id="os-vsrc-seg">
                <button type="button" data-v="device">🔈 This device</button>
                <button type="button" data-v="studio">🎙 Studio</button>
                <button type="button" data-v="off">🔇 Off</button>
              </div>
            </div>
            <p class="muted tiny" id="os-vsrc-say"></p>
          </div>
          <p class="os-voiceline" id="os-voiceline"></p>
          <div class="os-preflight" id="os-pre">
            <button class="btn btn-ghost btn-sm" id="os-pre-go">🎙 Test the microphone first</button>
            <span class="muted tiny">Worth ten seconds — a blocked microphone is much easier to fix now than four
              questions into a fifteen-minute station.</span>
          </div>
          <div class="os-pdial-box">
            <label class="os-pdial-head">
              <span><strong>How hard should the examiner push?</strong></span>
              <span class="os-pdial-num" id="os-pdial-b-v">${promptLevel()}</span>
            </label>
            <input type="range" id="os-pdial-b" min="0" max="100" step="5" value="${promptLevel()}">
            <div class="os-pdial-scale"><span>Silent</span><span>Nudges</span><span>Pushes hard</span></div>
            <p class="muted tiny" id="os-pdial-say"></p>
            <label class="os-pdial-head os-wait-head">
              <span><strong>How long a pause before it pushes?</strong></span>
              <span class="os-pdial-num" id="os-wait-v">${(silenceWait() / 1000).toFixed(1)}s</span>
            </label>
            <input type="range" id="os-wait" min="${SILENCE_MIN}" max="${SILENCE_MAX}" step="500" value="${silenceWait()}">
            <div class="os-pdial-scale"><span>1.5s — impatient</span><span>15s — lets you think</span></div>
            <p class="muted tiny">The examiner only speaks after you have genuinely stopped. Gaps between words and
              between sentences are not silences and never trigger it — but if you think in long pauses, move this
              right and it will wait.</p>
          </div>
          <details class="dev-collapse os-simcoach" open>
            <summary><span class="card-title">Coaching as well as marks</span><span class="dc-caret">▸</span></summary>
            <p class="muted tiny">Decided here so the debrief is one press. Change it there too if you want —
              nothing is asked of the model until you send the station for marking.</p>
            <div id="os-brief-coach"></div>
          </details>
          ${canSpeak() ? `<label class="os-both">
            <input type="checkbox" id="os-both" ${examinerOnTape() ? 'checked' : ''}>
            <span><strong>Record the examiner's voice too</strong><br>
              <span class="muted tiny">The questions are read aloud through the speaker and the microphone picks them
                up, so the tape sounds like the real room. Turn it off, or wear headphones, and only your own voice is
                recorded. Nothing said in the examiner's voice can earn you marks either way.</span></span>
          </label>` : ''}
          <div id="os-brief-drive"></div>
          <button class="btn btn-gold btn-lg" id="os-go">${resuming ? '▶ Resume the station' : "▶ I've read it — start"}</button>
          ${/* SKIPPING ONE, WITHOUT ENDING THE ROUND.

                Until now a circuit had two exits: sit this station, or end
                the whole round. There was no way to say "not this one" —
                so a candidate with an hour spent it on whatever the draw
                happened to hand them.

                A skipped station is `notSat`, exactly like the ones a
                round ended early never reached: not counted against the
                mean, still counted as fresh, still offered next time. It
                is not `skipped`, which means you were there and said
                nothing — that is a different fact and the circuit page
                already tells them apart.

                Only before the clock starts. Once you have spoken, the
                tape exists and the way out is Next, which hands it over
                to be marked. Skipping then would throw away an answer.

                THE BLIND RULE SURVIVES IT. A blind circuit still names
                nothing here. The one thing it will say is what YOU said
                about this station earlier — your own ↓ is not a hint
                about the topic, and it is exactly what makes the choice
                to skip an informed one rather than a coin toss. */''}
          ${s.circuit && !resuming && s.at + 1 < s.stations.length ? `<div class="os-skipbox">
            ${lowHere ? `<p class="os-skip-say">↓ <strong>You marked this one less important.</strong></p>` : ''}
            <button class="btn btn-ghost btn-sm" id="os-skipst">⏭ Skip this station — go to ${s.at + 2} of ${s.stations.length}</button>
            <span class="muted tiny">It is recorded as not sat: it counts neither for you nor against you, stays
              fresh, and will be offered again.</span>
          </div>` : ''}
          ${typeof AiOsce !== 'undefined' && AiOsce.allowed(user) ? `<div class="os-brief-ai">
            ${AiOsce.buttonHtml()}
            <span class="muted tiny">Sit this one against a chat model instead — the same station, the same fifteen
              minutes, examined and marked on the other half of the screen. The circuit waits where it is.</span>
          </div>` : ''}
        </div>`;
      stage.querySelector('#os-aiosce')?.addEventListener('click', () => AiOsce.openDialog(st, { sid }));
      stage.querySelector('#os-both')?.addEventListener('change', e => setExaminerOnTape(e.target.checked));

      /* THE ONE MOMENT WHEN A LAPSED DRIVE COSTS NOTHING TO FIX.
         Probed here rather than at the upload, because here the fix is
         two taps and the tape does not exist yet. Repainted on change so
         reconnecting in another tab clears the warning without a
         reload. */
      const dvBox = stage.querySelector('#os-brief-drive');
      if (dvBox && typeof Drive !== 'undefined') {
        const paintDv = () => { if (dvBox.isConnected) dvBox.innerHTML = Drive.warnHtml('before'); };
        paintDv();
        Drive.onChange(paintDv);
        Drive.probe();
      }
      stage.querySelector('#os-pre-go').addEventListener('click', e => preflight(stage, e.target));

      /* Say what the dial will actually do, in plain words, before the
         clock starts — a slider labelled 0 to 100 tells nobody anything. */
      const bDial = stage.querySelector('#os-pdial-b');
      const bNum = stage.querySelector('#os-pdial-b-v');
      const bSay = stage.querySelector('#os-pdial-say');
      const describe = n => {
        if (n <= 0) return 'The examiner reads each question and then says nothing at all. Closest to a written paper.';
        const p = promptPlan(n);
        const secs = Math.round(p.silenceMs / 1000);
        const pointed = p.pointedChance <= 0
          ? 'The pushes are general — “anything else?”, “go on”.'
          : p.pointedChance < 0.5
            ? 'Most pushes are general; some point at the area you have left out.'
            : 'Most pushes point at the specific area you have left out — never at the answer itself.';
        return `After ${secs} second${secs === 1 ? '' : 's'} of silence — a real stop, not the gap between two words —
          and only while a marking point is still unsaid, the examiner pushes: at most
          ${p.maxPerQuestion} time${p.maxPerQuestion === 1 ? '' : 's'} per question. ${pointed}`;
      };
      const paintDial = n => {
        bNum.textContent = n; bSay.innerHTML = describe(n);
        const top = view.querySelector('#os-pdial'), topV = view.querySelector('#os-pdial-v');
        if (top) { top.value = n; topV.textContent = n; top.closest('.os-pdial').classList.toggle('is-off', n === 0); }
      };
      bDial.addEventListener('input', () => { setPromptLevel(Number(bDial.value)); paintDial(Number(bDial.value)); });
      paintDial(promptLevel());

      const wait = stage.querySelector('#os-wait');
      const waitV = stage.querySelector('#os-wait-v');
      wait?.addEventListener('input', () => {
        setSilenceWait(Number(wait.value));
        waitV.textContent = (Number(wait.value) / 1000).toFixed(1) + 's';
        paintDial(promptLevel());        // the sentence above quotes this number
      });

      /* The station is about to be recorded, so every option is answerable
         — including the three that need a tape. */
      {
        const ch = stage.querySelector('#os-brief-coach');
        if (ch) { ch.innerHTML = coachPicker(true); wireCoachPicker(ch); }
      }
      /* The three-way choice, and what each one actually costs. The
         trade-off is stated rather than implied: the studio voice is the
         only one that reaches the tape by itself, and somebody who
         switches away from it should know that before they do, not
         afterwards when they play the recording back. */
      {
        const seg = stage.querySelector('#os-vsrc-seg');
        const say = stage.querySelector('#os-vsrc-say');
        const cur = () => !voiceOn() ? 'off' : voiceSrc() === VSRC.STUDIO ? 'studio' : 'device';
        const paintV = () => {
          const v = cur();
          seg.querySelectorAll('button').forEach(b => b.classList.toggle('is-on', b.dataset.v === v));
          say.innerHTML = v === 'off'
            ? 'The questions appear on screen and nothing is read aloud.'
            : v === 'studio'
              ? `A recorded voice, closer to a person — and the only one mixed <strong>straight into the
                 recording</strong>, so the tape carries both sides even through headphones. It needs a signal, and
                 falls back to this device if the quota is spent.`
              : `This device's own voice: instant, free, works with no signal. It reaches the recording only if the
                 microphone hears the speaker — tick "record the examiner's voice too" below, or the tape will have
                 your answers and not the questions.`;
          /* Whatever was already fetched is irrelevant once the choice
             changes; a stale clip would play the old voice for the first
             question and the new one after it. */
          if (v !== 'studio') { voices.clear(); nudges.clear(); voicesReady = false; }
          paintVoiceLine(stage);
        };
        seg.addEventListener('click', e => {
          const b = e.target.closest('[data-v]'); if (!b) return;
          const v = b.dataset.v;
          if (v === 'off') setVoiceOn(false);
          else { setVoiceOn(true); setVoiceSrc(v === 'studio' ? VSRC.STUDIO : VSRC.DEVICE); }
          paintV();
          if (v === 'studio') prefetchVoices().then(() => paintVoiceLine(stage)).catch(() => {});
        });
        paintV();
      }

      // fetched in the background while the scenario is being read, then the
      // brief says plainly which voice the candidate is going to hear
      prefetchVoices().then(() => paintVoiceLine(stage)).catch(() => paintVoiceLine(stage));
      stage.querySelector('#os-go').addEventListener('click', async () => {
        await startCapture();
        startClock();
        show(qi);
      });

      /* Skipping is cheap and reversible in the sense that matters — the
         station stays fresh — so it does not ask twice the way ending the
         whole round does. It does have to be deliberate, though, so it
         says which station is coming next rather than just moving. */
      stage.querySelector('#os-skipst')?.addEventListener('click', async ev => {
        const b = ev.currentTarget;
        b.disabled = true;
        saveMark(sid, st.id, { status: 'notSat', message: 'Skipped before the clock started.', at: Date.now() });
        s.at += 1; s.qi = 0; s.elapsed = 0; s.phase = 'brief';
        await saveSession(s); stopLive();
        renderRun(view, sid, user);
      });
    }

    /** Which voice the candidate is about to hear, and why. */
    function paintVoiceLine(stage) {
      const el = stage.querySelector('#os-voiceline');
      if (!el) return;
      const r = groqReport();
      el.hidden = false;
      if (voices.size) {
        el.className = 'os-voiceline is-groq';
        el.innerHTML = `🎙 <strong>A real examiner voice</strong> is ready${r.model ? ` (${esc(r.model)})` : ''} —
          and it is mixed straight into the recording, so the tape carries both sides even through headphones.`;
        return;
      }
      /* Nothing to report when the studio voice was not asked for: the
         segmented control above has already said which voice will read,
         and a second sentence explaining the absence of a thing nobody
         chose is noise. */
      if (!voiceOn() || voiceSrc() !== VSRC.STUDIO) { el.hidden = true; return; }
      el.hidden = false;
      if (!groqCfg().voice || groqCfg().enabled === false) {
        el.className = 'os-voiceline';
        el.innerHTML = `🔈 The studio voice is not switched on for this deployment, so this device's voice will read
          the questions.`;
        return;
      }
      el.className = 'os-voiceline';
      /* A quota that resets in ninety seconds is a different fact from one
         that is gone for the day, and the candidate can act on the first:
         the station picks the real voice back up the moment it returns. */
      const back = r.backIn > 0
        ? ` The quota resets in ${r.backIn < 90 ? `${r.backIn} seconds` : `${Math.round(r.backIn / 60)} minutes`} —
            questions after that get the real voice again.` : '';
      /* The server's sentence already carries the wait it was told; saying it
         twice, once frozen and once counting down, reads as two answers. The
         live one wins and the frozen tail is trimmed. */
      const why = String(r.why || '').replace(/\s*[—-]\s*back in [^.]*/i, back ? '' : '$&').replace(/\.\s*$/, '');
      el.innerHTML = `🔈 The <strong>browser's own voice</strong> will read the questions${
        why ? ` — the real voice is unavailable: <em>${esc(why)}</em>` : ''}.${back}`;
    }

    /* A declaration, not a `const`: brief() calls prefetchVoices() from above
       this point, and a const would still be in its temporal dead zone —
       the same trap the note beside `voices` describes, and the rejection
       lands in the same silent .catch(). */
    function lineOf(q) { return (q.reveal_before ? q.reveal_before + '. ' : '') + q.prompt; }

    async function prefetchVoices() {
      if (voicesReady || !studioVoice()) return;
      voicesReady = true;
      for (const q of qs) {
        const clip = await groqVoice(lineOf(q));
        if (!clip) break;                       // quota gone; the browser voice takes over
        voices.set(q.id, clip);
      }
      prefetchNudges();
    }

    /* Fetched once for the whole station: six short lines, spoken over and
       over, cost six requests for a whole fifteen minutes — which is what
       makes the middle of the dial free. */
    async function prefetchNudges() {
      if (promptLevel() <= 0 || !studioVoice()) return;
      for (const line of PROMPT_WORDS) {
        if (nudges.has(line)) continue;
        const clip = await groqVoice(line);
        if (!clip) break;
        nudges.set(line, clip);
      }
    }

    /* ---------------- the probe engine ----------------
       Armed when a question is read, disarmed the moment the candidate
       moves on. Watches the microphone rather than the clock, and only
       fires when there is a marking point genuinely still unsaid. */
    const probes = (() => {
      let timer = null, q = null, getText = null;
      let spokenHere = 0, lastAt = 0, quietSince = 0, busy = false, everHeard = false;
      let lastPaint = null;

      /* THE NOISE FLOOR.

         The first version compared the microphone against a fixed 0.06 and
         called anything below it silence. In a quiet test that works; in a
         real room it never fires at all, because a fan, a corridor, or an
         iPad's own gain control keeps the floor above that line for ever.
         Twenty minutes of waiting and not one push.

         So nothing is assumed about the room. The quietest readings seen so
         far ARE the floor, and speech is what rises clearly above it. The
         floor tracks downward quickly and upward slowly, so a door slamming
         does not permanently deafen the examiner. */
      /* AND THE TWO REASONS IT INTERRUPTED PEOPLE MID-SENTENCE.

         First, the floor learned from every sample including speech. Talk
         for forty seconds without a break and the floor climbs towards
         your own voice, until your voice no longer clears it — and the
         examiner, now deaf to you, decides you have stopped and cuts in.
         The longer and better the answer, the more likely it was to be
         interrupted, which is precisely backwards. The floor now learns
         only from samples that are NOT speech.

         Second, a single instantaneous reading was taken as the whole
         truth. Ordinary speech dips to nothing between words and between
         sentences; catch it in one of those gaps and it reads as silence.
         So voice is now judged over a rolling window — if the microphone
         has been over the line at any point in the last three-quarters of
         a second, you are still talking. Real pauses are longer than that;
         the gap between "obstetric" and "cholestasis" is not. */
      let floor = null, peakSeen = 0, lastVoiceAt = 0;
      const SPEAK_OVER = 0.045;         // how far above the floor counts as talking
      const GAP_MS = 750;               // a hole in speech shorter than this is still speech

      function listen(lvl, now) {
        if (lvl < 0) return null;
        now = now || Date.now();
        const over = floor != null && lvl > floor + SPEAK_OVER;
        if (floor == null) floor = lvl;
        else if (lvl < floor) floor = lvl * 0.35 + floor * 0.65;      // drops fast
        else if (!over) floor = floor * 0.995 + lvl * 0.005;          // creeps up ONLY on silence
        peakSeen = Math.max(peakSeen, lvl);
        if (over) lastVoiceAt = now;
        // still counted as talking through the gaps between words
        return lastVoiceAt > 0 && (now - lastVoiceAt) < GAP_MS;
      }
      /** What the strip on screen shows, so this can never fail invisibly. */
      function status() {
        const plan = promptPlan(promptLevel());
        if (plan.off) return { mode: 'off' };
        if (!q) return { mode: 'idle' };
        if (!live?.level || live.level() < 0) return { mode: 'nometer' };
        if (!everHeard) return { mode: 'waiting' };
        if (spokenHere >= plan.maxPerQuestion) return { mode: 'spent' };
        if (!quietSince) return { mode: 'listening' };
        return { mode: 'quiet', left: Math.max(0, plan.silenceMs - (Date.now() - quietSince)) };
      }

      function disarm() { if (timer) clearInterval(timer); timer = null; q = null; lastPaint = null; paintProbeState(); }

      function armFor(question, textFn) {
        disarm();
        q = question; getText = textFn;
        spokenHere = 0; lastAt = Date.now(); quietSince = 0; everHeard = false;
        floor = null; peakSeen = 0; lastVoiceAt = 0;   // a new question is a new room
        /* 150ms, not 500. The window that decides "still talking" is
           three-quarters of a second wide, and sampling it twice a second
           would mean judging a pause on one or two readings. */
        timer = setInterval(tick, 150);       // runs even at level 0, to paint the strip
        paintProbeState();
      }

      async function tick() {
        paintProbeState();
        if (busy || !q || !running) return;
        const plan = promptPlan(promptLevel());
        if (plan.off || spokenHere >= plan.maxPerQuestion) return;
        // never in the last minute — the clock is punishment enough
        if (total - elapsed < 60) return;
        if (Date.now() - lastAt < plan.cooldownMs) return;

        const now = Date.now();
        const lvl = live?.level ? live.level() : -1;
        /* A device that cannot report a level gets no probing at all rather
           than probing blind. Interrupting someone mid-sentence is worse
           than staying quiet, and there is no way to tell without a meter.
           The strip says so rather than leaving it a mystery. */
        if (lvl < 0) return;
        const talking = listen(lvl, now);
        if (talking) { everHeard = true; quietSince = 0; return; }
        /* Nothing has been heard above the floor yet. After forty seconds
           that is itself worth a push — someone who has not started may be
           stuck, and a real examiner would not sit through it in silence. */
        if (!everHeard && now - lastAt < 40000) return;
        /* The countdown starts from when the voice actually stopped, not
           from when this loop noticed — otherwise the window that protects
           the gaps between words would silently be added to every wait. */
        if (!quietSince) { quietSince = lastVoiceAt || now; return; }
        if (now - quietSince < plan.silenceMs) return;

        const said = (getText && getText()) || '';
        const missing = missingPoints(q, said);
        /* With no live transcript there is nothing to check against, so
           "still missing" cannot be judged — and a station is not a reason
           to go quiet. Everything unsaid is treated as missing, which is
           true at the start and harmless later: the push is generic. */
        const pool = said.trim() ? missing : scorable(q.marking_points);
        if (!pool.length) { quietSince = 0; return; }

        busy = true;
        try {
          const pointed = said.trim() && Math.random() < plan.pointedChance;
          let line = null;
          if (pointed) line = await pointedLine(q, pool, said);
          if (!line) line = PROMPT_WORDS[Math.floor(Math.random() * PROMPT_WORDS.length)];
          await sayProbe(line);
          spokenHere++; lastAt = Date.now(); quietSince = 0;
        } catch { /* a probe that fails is a probe that did not happen */ }
        busy = false;
        paintProbeState();
      }

      /* The examiner's state, on screen, always. The whole reason this went
         unnoticed for a version is that a feature that does nothing looks
         exactly like a feature that is switched off. */
      function paintProbeState() {
        const el = document.querySelector('#os-listen');
        if (!el) return;
        const st = status();
        const plan = promptPlan(promptLevel());
        const txt = {
          off: 'Examiner silent — move the dial above zero for pushes',
          idle: '',
          nometer: 'This device gives no microphone level, so the examiner cannot tell when you have stopped — it will not interrupt',
          waiting: 'Examiner listening…',
          spent: `Examiner has pushed ${plan.maxPerQuestion} time${plan.maxPerQuestion === 1 ? '' : 's'} on this question`,
          listening: 'Examiner listening…',
          quiet: `Examiner waiting… ${Math.ceil((st.left || 0) / 1000)}s`
        }[st.mode] || '';
        // the loop runs seven times a second now; only touch the DOM when
        // the words actually change
        if (txt === lastPaint) return;
        lastPaint = txt;
        el.hidden = !txt;
        el.className = 'os-listen is-' + st.mode;
        el.textContent = txt;
      }

      /** One short push about a specific missing point. */
      async function pointedLine(question, missing, said) {
        try {
          if (typeof Wallet !== 'undefined' && !(await Wallet.guard())) return null;
          const token = await Backend.getAccessToken();
          if (!token) return null;
          const choice = chosenModel();
          const res = await fetch(cfg().ai.apiBase, {
            method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
            body: JSON.stringify({ action: 'osceprobe', provider: choice.provider, model: choice.model,
              dailyLimit: cfg().ai.dailyLimit,
              question: String(question.prompt || '').slice(0, 400),
              said: String(said).slice(-1200),
              missing: missing.slice(0, 6).map(p => String(p).slice(0, 200)) })
          });
          if (!res.ok) return null;
          const d = await res.json().catch(() => ({}));
          const t = String(d.text || '').trim().replace(/^["']|["']$/g, '');
          return t && t.length < 160 ? t : null;
        } catch { return null; }
      }

      /** Say it, onto the tape, and show it so the deaf case still works. */
      async function sayProbe(line) {
        showProbe(line);
        const clip = nudges.get(line) || (studioVoice() ? await groqVoice(line) : null);
        if (clip && live?.speakClip) { hush(); if (await live.speakClip(clip)) return; }
        speak(line, { rate: 1.0 });
      }

      function showProbe(line) {
        const host = document.querySelector('#os-probe');
        if (!host) return;
        host.hidden = false;
        host.innerHTML = `<span class="os-probe-who">Examiner</span> ${esc(line)}`;
        host.classList.remove('is-in'); void host.offsetWidth; host.classList.add('is-in');
      }

      return { armFor, disarm, tick, status, paint: paintProbeState };
    })();

    async function startCapture() {
      /* The mix is also wanted when the quota is merely resting: the real
         voice may return part-way through the station, and the recorder
         cannot be re-pointed once it is running. */
      live = makeCapture(stage.querySelector('#os-mic'), voices.size > 0 || groqReport().backIn > 0);
      live.watchState(() => paintRecState(stage));
      await live.start();
    }

    /** Say the examiner's line: the real voice onto the tape, or the browser's. */
    async function examinerSays(q, text) {
      let clip = voices.get(q?.id);
      /* Prefetch stops at the first refusal, so a station that began during a
         one-minute ceiling had the browser voice for all fifteen. If the
         quota has come back by now, this question gets the real voice. */
      if (!clip && q && studioVoice()) {
        clip = await groqVoice(text || lineOf(q));
        // only the full line is worth keeping — "repeat" says less than that
        if (clip && text === lineOf(q)) voices.set(q.id, clip);
      }
      if (clip && live?.speakClip) {
        hush();
        const ok = await live.speakClip(clip);
        if (ok) return;
      }
      speak(text);
    }

    /* Whatever the recorder is ACTUALLY doing, on screen, all the time.
       The old code decided this once when the question was drawn and wrote
       the answer into a panel that the first question then destroyed — so a
       refused microphone looked exactly like a working one for fifteen
       minutes. */
    function paintRecState(host) {
      const chip = host.querySelector('#os-rec');
      const warn = host.querySelector('#os-rec-warn');
      const note = host.querySelector('#os-rec-note');
      if (!chip) return;
      const s = live?.state?.() || { recording: false, failed: 'No recording was started.' };
      chip.classList.toggle('is-off', !s.recording);
      chip.classList.toggle('is-paused', !!s.paused);
      chip.innerHTML = `<i></i> ${s.paused ? 'paused' : s.recording ? (s.bothVoices ? 'recording both' : 'recording') : 'not recording'}`;
      chip.title = s.recording && s.bothVoices
        ? 'Your voice and the examiner\'s are both going onto the tape'
        : s.recording ? 'Your voice is being recorded' : '';
      if (note) {
        note.textContent = s.transcribing
          ? 'Speak your answer. What the browser hears appears below — you can correct it later.'
          : 'Speak your answer. This browser does not transcribe as you go, so the recording is the record — type anything you want the marker to be sure of.';
      }
      if (!warn) return;
      const msg = s.failed || (!s.recording && !s.paused ? 'The recording has stopped. Putting it back…' : '');
      warn.hidden = !msg;
      warn.innerHTML = !msg ? ''
        : msg === 'BLOCKED'
          ? `<p class="os-mic-h">⚠ This browser is blocking the microphone for AUREUM</p>
             ${micHelp().map(p => `<p>${p}</p>`).join('')}
             <button class="btn btn-ghost btn-sm" id="os-mic-retry">🎙 Turn the microphone back on</button>`
          : `⚠ ${esc(msg)}${s.failed ? ` <button class="btn btn-ghost btn-sm" id="os-mic-retry">🎙 Turn the microphone back on</button>` : ''}`;
      warn.querySelector('#os-mic-retry')?.addEventListener('click', async e => {
        // this tap is the user gesture iOS requires; nothing else will do
        e.target.disabled = true; e.target.textContent = 'Asking…';
        await live?.retry();
        paintRecState(host);
      });
    }

    function show(i) {
      qi = i; persist(); paintClock();
      const q = qs[i];
      const prev = ans[q.id]?.transcript || '';
      stage.innerHTML = `
        <div class="os-qwrap" data-animate>
          <div class="os-qhead">
            <span class="os-qn">Question ${i + 1} <i>of ${qs.length}</i></span>
            <span class="os-qmarks">${q.marks} marks</span>
          </div>
          ${q.reveal_before ? `<div class="os-reveal"><span>NEW INFORMATION</span><p>${esc(q.reveal_before)}</p></div>` : ''}
          ${imageStrip(q)}
          <p class="os-prompt">${esc(q.prompt)}</p>
          <div class="os-probe" id="os-probe" hidden></div>
          <p class="os-listen" id="os-listen" hidden></p>
          <div class="os-answer">
            <div class="os-answer-head">
              <span class="os-rec" id="os-rec"><i></i> …</span>
              ${canSpeak() ? `<button class="os-voice ${voiceOn() ? '' : 'is-off'}" id="os-voice"
                title="${voiceOn() ? 'The examiner reads each question aloud' : 'The examiner is silent'}">🔊</button>
                <button class="os-voice" id="os-repeat" title="Read the question again">↻</button>` : ''}
              <span class="muted tiny" id="os-rec-note">Speak your answer.</span>
            </div>
            <div class="os-transcript" id="os-tx" contenteditable="true" spellcheck="false"
              data-ph="Your spoken answer appears here…">${esc(prev)}</div>
          </div>
          <div class="os-rec-warn" id="os-rec-warn" hidden></div>
          <div class="os-qfoot">
            <button class="btn btn-ghost" id="os-back" ${i === 0 ? 'disabled' : ''}>← Previous</button>
            <span class="muted tiny" id="os-hint">Take the marks in order — say the headline first, then the detail.</span>
            <button class="btn btn-gold" id="os-next">${i === qs.length - 1 ? 'Finish the station →' : 'Next question →'}</button>
          </div>
        </div>`;
      wireLightbox(stage);
      paintRecState(stage);
      const tx = stage.querySelector('#os-tx');
      live?.attach(text => { if (text) { tx.textContent = (tx.textContent + ' ' + text).trim(); } });
      const store = () => { ans[q.id] = { id: q.id, transcript: tx.innerText.trim() }; persist(); };
      tx.addEventListener('input', store);

      // the examiner reads the question, exactly as one would in the room
      examinerSays(q, (q.reveal_before ? q.reveal_before + '. ' : '') + q.prompt)
        .then(() => probes.armFor(q, () => tx.innerText));
      stage.querySelector('#os-voice')?.addEventListener('click', e => {
        setVoiceOn(!voiceOn());
        e.currentTarget.classList.toggle('is-off', !voiceOn());
        e.currentTarget.title = voiceOn() ? 'The examiner reads each question aloud' : 'The examiner is silent';
        voiceOn() ? speak(q.prompt) : hush();
      });
      stage.querySelector('#os-repeat')?.addEventListener('click', () => examinerSays(q, q.prompt));

      /* Next means next. The examiner does not press you, does not ask
         whether there is anything further, and does not tell you the answer
         was thin — see the note where the probes used to be. */
      stage.querySelector('#os-next').addEventListener('click', () => {
        store(); probes.disarm();
        i + 1 >= qs.length ? finish(false) : show(i + 1);
      });
      stage.querySelector('#os-back').addEventListener('click', () => { store(); probes.disarm(); show(Math.max(0, i - 1)); });
    }

    async function finish(timedOut) {
      if (tid) clearInterval(tid); tid = null; running = false;
      pauseBtn.hidden = true;
      qi = qs.length; s.phase = 'done'; persist();
      hush();
      const rec = live ? await live.stop() : null;
      // tagged with the station so a circuit cannot hand station 2 the tape
      // from station 1
      lastRec = { station: st.id, rec };
      debrief(timedOut, rec);
    }

    /* Whisper, on the way into the debrief.

       Run when the browser captured little or nothing — which on an iPad is
       ALWAYS, since Safari has no recogniser — and the transcript is the only
       thing standing between the candidate and a marked station.

       The scheme's own words go up as a spelling hint, because the terms that
       decide marks are exactly the ones a generic recogniser mangles:
       "mifepristone" came back as "metro trick" on a real attempt.

       It splits the returned text back across the questions by looking for
       where each answer began. When that is not possible the whole transcript
       is put on the first unanswered question rather than thrown away —
       marked text in the wrong place is still worth more than none. */
    async function transcribeIfWorthIt(stage, rec) {
      if (!rec?.blob) return;
      const already = qs.reduce((n, q) => n + ((ans[q.id]?.transcript || '').trim().length), 0);
      if (already > 400) return;                       // the browser did its job
      const host = stage.querySelector('#os-asr');
      if (!host) return;
      /* Nothing was captured AND transcription is unavailable — say so.
         Silence here would leave a blank debrief with no explanation of why
         it is blank, which is the state this whole feature exists to end. */
      if (!groqOn('whisper')) {
        host.hidden = false;
        host.innerHTML = `<p class="muted tiny">${groqOff
          ? 'The free transcription quota is used up for now, and this browser captured little or nothing.'
          : 'This browser captured little or nothing, and transcription is not enabled for your account.'}
          Type your answers below, or choose <strong>Mark from the recording</strong> — that route transcribes as it marks.</p>`;
        return;
      }
      host.hidden = false;
      host.innerHTML = `<div class="ai-loading sm"><span></span><span></span><span></span></div>
        <p class="muted tiny">Transcribing the recording — this browser did not, so it is being done properly.</p>`;
      const hint = qs.flatMap(q => scorable(q.marking_points)).join(' ').slice(0, 700);
      let out = null;
      try { out = await groqTranscribe(rec.blob, hint); } catch {}
      if (!out?.text) {
        host.innerHTML = `<p class="muted tiny">${groqOff
          ? 'The free transcription quota is used up for now — type your answers below, or mark from the recording, which transcribes as it marks.'
          : 'The recording could not be transcribed. Type your answers below, or mark from the recording.'}</p>`;
        return;
      }
      /* One transcript, several questions. Anything better than a single
         blob needs to know where the candidate moved on, and nothing on the
         tape says that — so it goes in whole, on the first question, and the
         marker (which has every question in front of it) sorts out which part
         answers what. */
      const first = qs.find(q => !(ans[q.id]?.transcript || '').trim()) || qs[0];
      ans[first.id] = { id: first.id, transcript: out.text };
      persist();
      const box = stage.querySelector(`[data-eq="${CSS.escape(String(first.id))}"]`);
      if (box) { box.innerText = out.text; box.closest('.os-said')?.classList.remove('is-empty'); }
      host.innerHTML = `<p class="os-asr-ok">✓ Transcribed from your recording (${esc(out.model || 'Whisper')}), free of charge.
        It is all on Q${qs.indexOf(first) + 1} — split it across the questions if you like, or leave it: the marker has
        every question in front of it.</p>`;
      // the estimate and the mark button were drawn against an empty transcript
      wireMarkControls(stage, st, ans, qs.map(q => ({ q, t: (ans[q.id]?.transcript || '').trim() })), rec, s);
      const btn = stage.querySelector('#os-mark'); if (btn) btn.disabled = false;
    }

    function debrief(timedOut, rec) {
      paintClock();
      const said = qs.map(q => ({ q, t: (ans[q.id]?.transcript || '').trim() }));
      const spoken = said.filter(x => x.t).length;
      stage.innerHTML = `
        <div class="os-sheet" data-animate>
          <p class="kicker">STATION COMPLETE</p>
          <h2>${esc(st.topic || '')}</h2>
          ${timedOut ? `<p class="os-timeout">⏱ The fifteen minutes ran out — that is the station, exactly as it would be.</p>` : ''}
          <p class="muted">You answered <strong>${spoken}</strong> of ${qs.length} questions in ${fmt(elapsed)}.
            Check the transcript below — the recogniser mishears drug names, and you are marked on what it captured, so
            correct anything it got wrong before marking.</p>
          ${rec?.url ? `<div class="os-rec-box">
            <audio controls src="${rec.url}"></audio>
            <a class="btn btn-ghost btn-sm" href="${rec.url}" download="OSCE-${esc((st.topic || 'station').replace(/[^a-z0-9]+/gi, '-'))}-${new Date().toISOString().slice(0, 10)}.${rec.ext}">⬇ Download the recording</a>
            <span class="muted tiny">${rec.mins} — kept with the result for 24 hours once you mark it, then deleted.</span>
          </div>` : `<p class="muted tiny">No audio was captured for this run.</p>`}
        </div>

        <div class="card" data-animate>
          <h3 class="card-title">What you said</h3>
          <div id="os-asr" class="os-asr" hidden></div>
          ${said.map(({ q, t }, i) => `
            <div class="os-said ${t ? '' : 'is-empty'}">
              <p class="os-said-q"><strong>Q${i + 1}</strong> ${esc(q.prompt)} <span class="muted tiny">(${q.marks})</span></p>
              <div class="os-said-t" contenteditable="true" spellcheck="false" data-eq="${esc(q.id)}"
                data-ph="Nothing was captured for this question">${esc(t)}</div>
            </div>`).join('')}
        </div>

        ${s.circuit ? `<div class="card os-markbox os-markbox-auto" data-animate>
          <h3 class="card-title">✨ This station will be marked while you sit the next one</h3>
          <p class="muted">Correct the transcript above if the recogniser mangled a drug name — then move on. The
            recording and your answers are sent for marking as you leave, one station at a time, and every result is
            waiting together at the end of the circuit. Nothing is lost if a marking fails: the recording is kept for
            24 hours and you can send it again from the results page.</p>
        </div>` : `<div class="card os-markbox" data-animate>
          <h3 class="card-title">✨ Mark it against the scheme</h3>
          <p class="muted">Every scheme point is marked covered, partial or missed, and you get an examiner's verdict,
            the marks you missed and what to do about them. This is the only step that uses AI, and what it costs is
            shown before you press the button.</p>
          <div class="os-src" id="os-src"></div>
          <div id="os-coach-box"></div>
          <div class="os-mark-acts">
            <div class="os-prov" id="os-prov"></div>
            <button class="btn btn-gold btn-lg" id="os-mark" ${spoken || rec?.blob ? '' : 'disabled'}>Mark this station</button>
          </div>
          <p class="os-est" id="os-est"></p>
          ${spoken || rec?.blob ? '' : '<p class="muted tiny">Nothing was captured, so there is nothing to mark. Type your answers above if you want it marked anyway.</p>'}
          <div id="os-mark-out"></div>
        </div>`}

        ${typeof AiOsce !== 'undefined' && AiOsce.allowed(user) ? `<div class="os-run-ai">
          <button class="btn btn-ghost btn-sm" id="os-runai">✦ Sit this one against a chat model instead</button>
          <span class="muted tiny">Hands you the prompt for this station and starts its own clock. The circuit waits.</span>
        </div>` : ''}

        <div class="os-run-foot">
          ${s.circuit
            ? (s.at + 1 < s.stations.length
                ? `<button class="btn btn-primary btn-lg" id="os-nextst">Next station (${s.at + 2} of ${s.stations.length}) →</button>
                   <button class="btn btn-ghost" id="os-endst">End the round here</button>
                   <p class="muted tiny os-end-note">Nine planned and you have to leave after two: this marks the
                     ${s.at + 1} station${s.at === 0 ? '' : 's'} you have sat and takes you to the results. The rest are
                     recorded as not sat, so they are not counted against you and are still fresh next time.</p>`
                : `<button class="btn btn-gold btn-lg" id="os-nextst">Finish the circuit and see the results →</button>`)
            : `<a class="btn btn-ghost" href="#/osce">Back to the stations</a>`}
        </div>`;

      stage.querySelectorAll('[data-eq]').forEach(el => {
        el.addEventListener('input', () => {
          ans[el.dataset.eq] = { id: el.dataset.eq, transcript: el.innerText.trim() }; persist();
        });
        // dictate a correction rather than typing it on a tablet keyboard
        const q = qs.find(x => String(x.id) === el.dataset.eq);
        const mic = micButton(el, { hint: scorable(q?.marking_points).join(' ').slice(0, 400), maxSecs: 120 });
        if (mic) el.parentNode.insertBefore(mic, el.nextSibling);
      });
      transcribeIfWorthIt(stage, rec);
      // a circuit has no marking controls to wire: it marks itself as you leave
      if (!s.circuit) wireMarkControls(stage, st, ans, said, rec, s);
      /* In a circuit, leaving a station HANDS IT OVER rather than waiting on
         it: the tape and the transcript join the queue, and the clock for the
         next station starts while the last one is being marked. The results
         are collected at the end, where the candidate has time to read them. */
      /* Handing this station over — queue its tape for marking, or record
         that there was nothing to mark. Shared by "Next station" and by
         "End the round here", because a round ended early must still mark
         the station you were in the middle of. */
      const handOver = () => {
        const already = loadMarks(sid)[st.id];
        if (already) return;
        /* SAT MEANS SAT. The bucket empties here and nowhere else — not
           when the round starts, not when a station is skipped — because
           this is the only moment that means the station is finished
           with. See the header of js/bucket.js. */
        if (s.fromBucket && typeof Bucket !== 'undefined') Bucket.done([st.id]).catch(() => {});
        if (spoken || rec?.blob) {
          saveMark(sid, st.id, { status: 'queued', at: Date.now() });
          queueMark({ sid, st, ans: Object.assign({}, ans), rec, session: { elapsed },
            choice: chosenModel(), attemptId: 'oa-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5) });
        } else {
          saveMark(sid, st.id, { status: 'skipped', message: 'Nothing was captured for this station.', at: Date.now() });
        }
      };

      stage.querySelector('#os-runai')?.addEventListener('click', () => AiOsce.openDialog(st, { sid }));

      stage.querySelector('#os-nextst')?.addEventListener('click', async ev => {
        ev.target.disabled = true;
        const last = s.at + 1 >= s.stations.length;
        handOver();
        if (last) {
          s.phase = 'circuit'; await saveSession(s); stopLive();
          location.hash = '#/osce/circuit/' + sid;
          return;
        }
        s.at += 1; s.qi = 0; s.elapsed = 0; s.phase = 'brief';
        await saveSession(s); stopLive(); renderRun(view, sid, user);
      });

      /* LEAVING EARLY.

         A round is nine stations because that is the exam, not because
         nine is how much time anybody reliably has. Before this the only
         ways out were to sit all nine or to walk away — and walking away
         left the station you were in unmarked, since the tape is only
         handed to the marker when you press Next.

         So this hands the current station over exactly as Next does, then
         writes `notSat` against the ones never reached. notSat is not
         `skipped`: skipped means you were there and there was nothing to
         mark, notSat means you never arrived. The circuit page counts
         neither against the mean, and the fresh-stations tick still
         offers a not-sat station next time, which is the whole point. */
      stage.querySelector('#os-endst')?.addEventListener('click', async ev => {
        const b = ev.currentTarget;
        if (b.dataset.sure !== '1') {
          b.dataset.sure = '1';
          b.textContent = `End here? ${s.stations.length - s.at - 1} station${s.stations.length - s.at - 1 === 1 ? '' : 's'} will not be sat — tap again`;
          setTimeout(() => { if (b.dataset.sure === '1') { b.dataset.sure = ''; b.textContent = 'End the round here'; } }, 5000);
          return;
        }
        b.disabled = true; b.textContent = 'Finishing…';
        handOver();
        const marks = loadMarks(sid);
        s.stations.slice(s.at + 1).forEach(id => {
          if (!marks[id]) saveMark(sid, id, { status: 'notSat', at: Date.now() });
        });
        s.endedEarly = { at: Date.now(), sat: s.at + 1, of: s.stations.length };
        s.phase = 'circuit';
        await saveSession(s); stopLive();
        location.hash = '#/osce/circuit/' + sid;
      });
    }
  }

  /* ---------------- the pre-flight ----------------
     Opens the microphone, watches the level for a moment and lets go. Run
     before the clock starts, so a blocked microphone costs ten seconds rather
     than a station — and so the fix, which on Safari means leaving the page
     for the Settings app, can be done without losing an attempt. */

  async function preflight(stage, btn) {
    const host = stage.querySelector('#os-pre');
    btn.disabled = true; btn.textContent = 'Testing…';
    let media = null;
    try {
      media = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (e) {
      const name = String(e && e.name || e);
      host.innerHTML = /NotAllowed|SecurityError/i.test(name)
        ? `<div class="os-rec-warn"><p class="os-mic-h">⚠ This browser is blocking the microphone for AUREUM</p>
             ${micHelp().map(p => `<p>${p}</p>`).join('')}
             <button class="btn btn-ghost btn-sm" id="os-pre-again">🎙 Test again</button>
             <p class="muted tiny">You can still sit the station — type your answers instead of speaking, and mark
               from the transcript.</p></div>`
        : `<div class="os-rec-warn">⚠ The microphone could not be opened (${esc(name)}).
             <button class="btn btn-ghost btn-sm" id="os-pre-again">🎙 Test again</button></div>`;
      host.querySelector('#os-pre-again').addEventListener('click', ev => preflight(stage, ev.target));
      return;
    }

    /* Show that sound is actually arriving. A microphone that opens but hears
       nothing — muted hardware, the wrong input — looks identical to a
       working one until the debrief. */
    let peak = 0;
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      const ac = new Ctx();
      const src = ac.createMediaStreamSource(media);
      const an = ac.createAnalyser(); an.fftSize = 512;
      src.connect(an);
      const buf = new Uint8Array(an.frequencyBinCount);
      host.innerHTML = `<div class="os-pre-live">
        <span class="os-pre-k">Say something…</span>
        <span class="os-pre-bar"><i id="os-pre-i"></i></span>
      </div>`;
      const bar = host.querySelector('#os-pre-i');
      const t0 = Date.now();
      await new Promise(res => {
        const tick = () => {
          an.getByteTimeDomainData(buf);
          let m = 0;
          for (let i = 0; i < buf.length; i++) m = Math.max(m, Math.abs(buf[i] - 128));
          peak = Math.max(peak, m);
          if (bar) bar.style.width = Math.min(100, (m / 60) * 100) + '%';
          if (Date.now() - t0 > 4000) return res();
          requestAnimationFrame(tick);
        };
        tick();
      });
      try { await ac.close(); } catch {}
    } catch { peak = -1; }
    try { media.getTracks().forEach(t => t.stop()); } catch {}

    host.innerHTML = peak > 6
      ? `<p class="os-pre-ok">✓ The microphone is working — it heard you. Start when you are ready.</p>`
      : peak < 0
        ? `<p class="os-pre-ok">✓ The microphone opened. Start when you are ready.</p>`
        : `<div class="os-rec-warn">⚠ The microphone opened but heard almost nothing. Check it is not muted, and that
             the right input is selected, then test again.
             <button class="btn btn-ghost btn-sm" id="os-pre-again">🎙 Test again</button></div>`;
    host.querySelector('#os-pre-again')?.addEventListener('click', ev => preflight(stage, ev.target));
  }

  /* ---------------- microphone + recogniser ---------------- */

  function makeCapture(host, wantMix) {
    let media = null, rec = null, chunks = [], sr = null, onText = null, mime = '', started = 0;
    let onState = null, watch = null, failed = '';
    const say = (msg, cls) => { if (host) host.innerHTML = `<p class="os-mic-msg ${cls || ''}">${msg}</p>`; };

    /* The truth about whether anything is being recorded, asked of the
       recorder and the microphone track rather than remembered from when the
       station started. A candidate who thinks they are being recorded for
       fifteen minutes and is not has wasted the fifteen minutes. */
    function state() {
      const track = media?.getAudioTracks?.()[0];
      return {
        recording: rec?.state === 'recording' && track?.readyState === 'live' && !track.muted,
        paused: rec?.state === 'paused',
        everStarted: !!started,
        bothVoices: bothVoices(),
        failed,
        secs: started ? Math.round((Date.now() - started) / 1000) : 0,
        transcribing: !!sr
      };
    }
    let last = '';
    function ping() {
      const s = state();
      const key = `${s.recording}|${s.paused}|${s.failed}`;
      if (key !== last) { last = key; onState?.(s); }
    }

    /* ASK FOR THE PLAIN MICROPHONE, ALWAYS.

       v63 asked for { echoCancellation: false, … } up front so the tape would
       also carry the examiner's voice off the speaker. On iPadOS that request
       is rejected outright rather than merely ignored, and — worse — the
       rejection consumes the user gesture, so the fallback to a plain request
       fails too and the whole thing reports "the microphone was refused" on a
       device where the microphone was never actually asked for.

       So: open the microphone the way that has always worked, THEN try to
       relax echo cancellation on the track that is already running. If the
       platform will not do it, the recording is unaffected — only the
       examiner's voice is missing from the tape, which is a preference, not
       the feature. Never let a nicety cost the recording. */
    async function openMic() {
      const media = await navigator.mediaDevices.getUserMedia({ audio: true });
      if (examinerOnTape()) {
        const track = media.getAudioTracks()[0];
        try { await track?.applyConstraints({ echoCancellation: false, noiseSuppression: false }); }
        catch { /* the tape will carry the candidate only; the station still runs */ }
      }
      return media;
    }
    /** Did the relaxed constraint actually take? Reported honestly on screen. */
    function bothVoices() {
      if (!examinerOnTape()) return false;
      try { return media?.getAudioTracks()[0]?.getSettings?.().echoCancellation === false; }
      catch { return false; }
    }

    /* ---- the mixing desk ----
       When the examiner has a real voice, the tape is built rather than
       overheard: the microphone and the examiner's audio are summed in Web
       Audio and the recorder is pointed at the SUM. That puts both voices on
       the recording by construction — through headphones, on any device, with
       echo cancellation left on where it belongs. Without Groq the recorder
       goes straight at the microphone as it always did. */
    let acx = null, mixDest = null, micNode = null;
    function mixer() {
      if (mixDest) return mixDest;
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx || !media) return null;
      try {
        acx = acx || new Ctx();
        mixDest = acx.createMediaStreamDestination();
        micNode = acx.createMediaStreamSource(media);
        micNode.connect(mixDest);
        return mixDest;
      } catch { mixDest = null; return null; }
    }
    /** Play a clip out loud AND onto the tape. Resolves when it has finished. */
    async function speakClip(clip) {
      const dest = mixer();
      if (!dest || !acx) return false;
      try {
        if (acx.state === 'suspended') await acx.resume();
        const buf = await acx.decodeAudioData(b64ToBuf(clip.data));
        const src = acx.createBufferSource();
        src.buffer = buf;
        src.connect(dest);              // onto the recording
        src.connect(acx.destination);   // and out of the speaker
        await new Promise(res => { src.onended = res; src.start(); });
        return true;
      } catch { return false; }
    }
    /** What the recorder should listen to: the mix if there is one, else the mic. */
    const recordFrom = () => (mixDest ? mixDest.stream : media);

    /* A loudness reading, so the examiner can tell talking from a pause.
       Built on its own tiny graph rather than the mixer's, because the
       mixer only exists when the examiner has a real voice, and the pause
       matters either way. Returns 0..1, or -1 when it cannot tell — and a
       caller that cannot tell must never guess that the room is silent. */
    let lvlCtx = null, lvlNode = null, lvlBuf = null;
    function level() {
      if (!media) return -1;
      try {
        if (!lvlNode) {
          const Ctx = window.AudioContext || window.webkitAudioContext;
          if (!Ctx) return -1;
          lvlCtx = lvlCtx || new Ctx();
          const src = lvlCtx.createMediaStreamSource(media);
          lvlNode = lvlCtx.createAnalyser();
          lvlNode.fftSize = 512;
          src.connect(lvlNode);
          lvlBuf = new Uint8Array(lvlNode.frequencyBinCount);
        }
        lvlNode.getByteTimeDomainData(lvlBuf);
        let peak = 0;
        for (let i = 0; i < lvlBuf.length; i++) peak = Math.max(peak, Math.abs(lvlBuf[i] - 128));
        return peak / 128;
      } catch { return -1; }
    }

    async function start() {
      /* Ask Google whether the grant is still alive, NOW, while the tape
         does not yet exist. A lapsed permission found here is a prompt;
         found at upload time it is a lost recording. Never awaited — the
         clock does not wait for Drive — and never throws, so it cannot
         stand between a candidate and their microphone. */
      try { if (typeof Drive !== 'undefined') Drive.probe(); } catch {}
      try {
        media = await openMic();
      } catch (e) {
        /* Say WHICH refusal it was. "The microphone was refused" sent someone
           hunting a permission that was never the problem, so the name of the
           error now decides the wording — and on an iPad the answer is nearly
           always the per-site setting behind the aA menu. */
        const name = String(e && e.name || e);
        failed = /NotAllowed|SecurityError/i.test(name)
          ? 'BLOCKED'                                   // the panel spells out the fix for this browser
          : /NotFound|Devices/i.test(name)
            ? 'No microphone was found on this device. You can still type your answers.'
            : /NotReadable|Aborted/i.test(name)
              ? 'Another app is using the microphone. Close it, then tap “Turn the microphone back on”.'
              : `The microphone could not be started (${name}). Tap “Turn the microphone back on” to try again.`;
        say('⚠ ' + failed, 'is-warn');
        ping();
        return false;
      }
      mime = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/aac']
        .find(t => window.MediaRecorder && MediaRecorder.isTypeSupported(t)) || '';
      try {
        // 24 kbps opus is plainly intelligible speech and keeps a 15-minute
        // station near 2.5 MB — small enough to send for marking
        // with a real examiner voice the mix is built first, so the tape
        // carries both sides; without it this is the bare microphone
        if (wantMix) mixer();
        rec = new MediaRecorder(recordFrom(), Object.assign(mime ? { mimeType: mime } : {}, { audioBitsPerSecond: 24000 }));
        rec.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
        rec.onerror = () => { failed = 'The recording stopped unexpectedly.'; ping(); revive(); };
        rec.start(1000);
        started = started || Date.now();
      } catch { rec = null; failed = 'This browser would not start a recording.'; }

      /* iOS hands the audio session to the speech synthesiser when the
         examiner reads a question, which silently ends the capture. Watch for
         it and put the recording back rather than discovering at the debrief
         that fourteen of the fifteen minutes are missing. */
      media.getAudioTracks().forEach(t => t.addEventListener('ended', () => {
        failed = 'The microphone was switched off — another app may have taken it. Tap “Turn the microphone back on”.';
        ping();
      }));
      clearInterval(watch);
      // only ever restarts the RECORDER, never re-asks for the microphone
      watch = setInterval(() => { const s = state(); ping(); if (!s.recording && !s.paused && trackLive()) revive(); }, 2000);
      // the browser's own recogniser: free, and good enough once you correct it
      const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SR) {
        try {
          sr = new SR();
          sr.continuous = true; sr.interimResults = false; sr.lang = 'en-GB';
          sr.onresult = e => {
            let out = '';
            for (let i = e.resultIndex; i < e.results.length; i++) if (e.results[i].isFinal) out += e.results[i][0].transcript;
            if (out && onText) onText(out.trim());
          };
          // recognisers stop themselves on silence; keep it alive for the station
          sr.onend = () => { if (sr && !sr._stopped) { try { sr.start(); } catch {} } };
          sr.start();
        } catch { sr = null; }
      }
      say(sr ? '🎙 Listening — speak normally.' : '🎙 Recording. This browser has no live transcription, so type your answers as you go (the audio is still saved).', sr ? 'is-on' : 'is-warn');
      /* SAY WHETHER IT WORKED.

         This used to return undefined on success and undefined on failure,
         the failure path merely returning early. Every caller therefore had
         to ask `live.state().failed` instead, and a caller that trusted the
         return value — as the OSCE-in-AI screen did — treated a perfectly
         open microphone as a refusal and never started its clock.

         A function whose success is indistinguishable from its failure is a
         trap for the next caller. It now returns a boolean, and the callers
         that check `.failed` as well are unaffected. */
      return !failed;
    }
    function attach(fn) { onText = fn; }
    function watchState(fn) { onState = fn; last = ''; ping(); }

    /* Putting a stalled recording back WITHOUT asking for the microphone
       again. iOS grants getUserMedia only inside a user gesture, so a
       watchdog that called it every two seconds could never succeed — it
       would just fail repeatedly and, on some versions, sour the permission
       for the rest of the visit. A recorder that stopped while its track is
       still live needs no permission at all: start a new one on the track
       already in hand and keep the chunks, so the tape runs on unbroken.

       If the TRACK itself has died, only the candidate can revive it, so the
       warning offers a button instead of retrying behind their back. */
    let reviving = false;
    function trackLive() {
      const t = media?.getAudioTracks?.()[0];
      return !!t && t.readyState === 'live';
    }
    async function revive() {
      if (reviving || paused_ || !trackLive()) return;
      reviving = true;
      try {
        try { rec?.state !== 'inactive' && rec.stop(); } catch {}
        rec = new MediaRecorder(recordFrom(), Object.assign(mime ? { mimeType: mime } : {}, { audioBitsPerSecond: 24000 }));
        rec.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
        rec.onerror = () => { ping(); };
        rec.start(1000);
        failed = '';
      } catch { failed = 'The recording stopped and could not be restarted. Tap “Turn the microphone back on”.'; }
      reviving = false;
      ping();
    }

    /** The candidate's own tap — the only thing iOS accepts as permission. */
    async function retry() {
      failed = '';
      ping();
      try { media?.getTracks().forEach(t => t.stop()); } catch {}
      media = null; rec = null;
      await start();
      return state();
    }

    let paused_ = false;
    function pause() { paused_ = true; try { rec?.state === 'recording' && rec.pause(); } catch {} try { if (sr) { sr._stopped = true; sr.stop(); } } catch {} ping(); }
    function resume() { paused_ = false; try { rec?.state === 'paused' && rec.resume(); } catch {} try { if (sr) { sr._stopped = false; sr.start(); } } catch {} ping(); }
    async function stop() {
      clearInterval(watch); watch = null;
      try { if (sr) { sr._stopped = true; sr.stop(); } } catch {}
      const done = new Promise(res => { if (!rec) return res(null); rec.onstop = () => res(true); try { rec.stop(); } catch { res(null); } });
      await done;
      try { media?.getTracks().forEach(t => t.stop()); } catch {}
      if (!chunks.length) return null;
      const type = mime || 'audio/webm';
      const blob = new Blob(chunks, { type });
      const secs = Math.round((Date.now() - started) / 1000);
      return { url: URL.createObjectURL(blob), blob, mime: type, ext: /mp4|aac/.test(type) ? 'm4a' : 'webm',
        bytes: blob.size, secs,
        mins: `${fmt(secs)} of audio · ${(blob.size / 1024 / 1024).toFixed(1)} MB` };
    }
    return { ok: () => !!rec, start, attach, pause, resume, stop, state, watchState, retry, bothVoices,
      speakClip, level, mixed: () => !!mixDest,
      kill: () => { clearInterval(watch); watch = null;
        try { lvlCtx?.close(); } catch {} lvlCtx = lvlNode = null;
        try { sr && (sr._stopped = true, sr.stop()); } catch {}
        try { rec?.state !== 'inactive' && rec.stop(); } catch {}
        try { media?.getTracks().forEach(t => t.stop()); } catch {}
        try { acx?.close(); } catch {} } };
  }
  function stopLive() { try { live?.kill(); } catch {} live = null; }

  /* ---------------- AI marking ---------------- */

  let lastRec = null;              // the recording from the station just finished
  /* What the CANDIDATE asked for, which is not always what is possible: a
     text-only model forces the transcript route, but choosing a listening
     model again must put the recording back — the preference was never
     theirs to lose. */
  let srcWanted = 'audio';

  /* ---------------- what a marking will cost, before you press ----------------
     Audio is tokenised at ~32 tokens a second, so the size of the bill is
     knowable in advance and is shown in dollars AND rupees. Nobody should
     spend money on a button whose price they cannot see. */
  /** The route actually available, given what was recorded and what the model can do. */
  const effectiveSource = (rec, choice) =>
    (srcWanted === 'audio' && rec?.blob && choice.audio) ? 'audio' : 'text';

  function estimate(st, said, rec, choice) {
    const schemeWords = qsOf(st).reduce((n, q) =>
      n + (q.prompt + ' ' + (q.marking_points || []).join(' ')).split(/\s+/).length, 0);
    /* `said` is the list of {id,t} the recogniser produced, NOT a string —
       a name that reads like text and is not. Accept either, because the
       next caller will make the same assumption I did. */
    const spokenWords = Array.isArray(said)
      ? said.reduce((n, x) => n + String(x?.t || '').split(/\s+/).filter(Boolean).length, 0)
      : String(said || '').split(/\s+/).filter(Boolean).length;
    const useAudio = effectiveSource(rec, choice) === 'audio';
    const inTok = useAudio
      ? Math.round((rec.secs || 900) * 32) + Math.round(schemeWords * 1.3) + 400
      : Math.round((spokenWords + schemeWords) * 1.3) + 500;
    const outTok = 900 + qsOf(st).length * (useAudio ? 220 : 120);   // transcripts cost output too
    const usd = (inTok / 1e6) * (choice.rate.in || 0) + (outTok / 1e6) * (choice.rate.out || 0);
    const rate = (typeof Wallet !== 'undefined') ? Wallet.rate() : 340;
    return { inTok, outTok, total: inTok + outTok, usd, lkr: usd * rate, rate, useAudio };
  }
  const money = e => `$${e.usd < 0.01 ? e.usd.toFixed(4) : e.usd.toFixed(3)} · LKR ${e.lkr.toFixed(2)}`;

  /* `kept` — a tape ALREADY uploaded, so markCore reuses the stored path
     instead of sending several megabytes a second time. The station runner
     never has one (it records and marks in one go); OSCE in AI always does,
     because it stores the recording the moment the session ends. */
  function wireMarkControls(stage, st, ans, said, rec, session, kept, opts) {
    const coachHost = stage.querySelector('#os-coach-box');
    if (coachHost) { coachHost.innerHTML = coachPicker(!!rec?.blob); wireCoachPicker(coachHost); }
    const srcHost = stage.querySelector('#os-src');
    const provHost = stage.querySelector('#os-prov');
    const estHost = stage.querySelector('#os-est');
    const hasAudio = !!rec?.blob;
    if (!hasAudio) srcWanted = 'text';

    const paint = () => {
      const choice = chosenModel();
      const src = effectiveSource(rec, choice);
      srcHost.innerHTML = `
        <div class="os-src-opts">
          <button class="os-src-b ${src === 'audio' ? 'active' : ''} ${hasAudio && choice.audio ? '' : 'is-off'}"
            data-src="audio" ${hasAudio && choice.audio ? '' : 'disabled'}>
            <span class="os-src-t">🎧 Mark from the recording</span>
            <span class="os-src-d">${hasAudio
              ? (choice.audio
                  ? 'The model listens to you and transcribes it itself — the accurate way. It hears hesitancy and self-correction, which a typed transcript throws away.'
                    + (choice.audioFormat === 'wav'
                        ? ` <em>${esc(choice.label)} only accepts WAV, so the recording is re-encoded here first — a bigger upload, and consonants soften at the lower sample rates a long station needs.</em>` : '')
                  : esc(noAudioReason(choice)))
              : 'No recording was captured for this station.'}</span>
          </button>
          <button class="os-src-b ${src === 'text' ? 'active' : ''}" data-src="text">
            <span class="os-src-t">📝 Mark from the transcript</span>
            <span class="os-src-d">Marks the text above as it stands. Cheaper, but only as good as what the browser heard.</span>
          </button>
        </div>`;
      // the price is on every option, so "which is cheaper" is a fact on
      // screen rather than something to look up
      provHost.innerHTML = `<label class="os-prov-l">Marked by
        <select class="sel" id="os-model-sel">${modelChoices().map(m =>
          `<option value="${esc(m.key)}" ${m.key === choice.key ? 'selected' : ''}>${esc(m.label)} — $${m.rate.in}/$${m.rate.out} per 1M${m.audio ? '' : ' · no audio'}</option>`).join('')}</select></label>`;
      const e = estimate(st, said, rec, choice);
      estHost.innerHTML = `<span class="os-est-k">Before you press:</span>
        about <strong>${e.total.toLocaleString('en-US')}</strong> tokens
        (${e.inTok.toLocaleString('en-US')} in + ${e.outTok.toLocaleString('en-US')} out) on
        <strong>${esc(choice.label)}</strong> — <strong>${money(e)}</strong>
        <span class="muted tiny">at LKR ${e.rate}/USD${e.useAudio ? ` · ${fmt(rec.secs || 0)} of audio` : ''}</span>`;
      srcHost.querySelectorAll('[data-src]').forEach(b => b.addEventListener('click', () => {
        if (b.disabled) return; srcWanted = b.dataset.src; paint();
      }));
      provHost.querySelector('#os-model-sel').addEventListener('change', ev => { setModel(ev.target.value); paint(); });
    };
    paint();
    stage.querySelector('#os-mark')?.addEventListener('click', e => mark(e.target, st, ans, rec, session, kept, opts));
  }

  /**
   * `opts` lets a caller that is NOT a station page use this same marking
   * path without being thrown off its own screen when it finishes:
   *
   *   meta   — merged onto the finished attempt and saved. The mark-by-hand
   *            sheet uses it to record whose sitting this was, and that the
   *            hand marking and this one are of the SAME performance.
   *   onDone — called with the attempt instead of navigating to its report.
   *
   * Everything else is unchanged, deliberately: one marking path means one
   * upload, one pending queue, one retry, one attempt shape.
   */
  async function mark(btn, st, ans, rec, session, kept, opts) {
    const out = document.querySelector('#os-mark-out');
    const choice = chosenModel();
    const useAudio = effectiveSource(rec, choice) === 'audio';
    btn.disabled = true;
    out.innerHTML = `<div class="ai-loading"><span></span><span></span><span></span></div>
      <p class="muted tiny">${useAudio ? 'Listening to the recording and marking' : 'Marking'} ${qsOf(st).length} answers against
        ${qsOf(st).reduce((n, q) => n + scorable(q.marking_points).length, 0)} marking points…</p>`;
    try {
      const attempt = await markCore({ st, ans, rec, session, choice, kept,
        stamp: opts?.meta || null,
        /* Reusing the id the recording was queued under is what makes the
           queue row BE this attempt: markCore rewrites it on the way in
           and drops it on success, so a tape cannot end up both marked
           and still sitting in "not yet marked". */
        attemptId: opts?.attemptId || null,
        say: t => { const n = out.querySelector('.os-mark-step'); if (n) n.textContent = t;
          else out.insertAdjacentHTML('beforeend', `<p class="muted tiny os-mark-step">${esc(t)}</p>`); } });
      out.innerHTML = '';
      if (opts?.onDone) { opts.onDone(attempt); return; }
      location.hash = '#/osce/result/' + attempt.id;
    } catch (e) {
      out.innerHTML = `<p class="ai-error">${esc(e.message || e)}</p>`;
      btn.disabled = false;
    }
  }

  /* ================= marking a circuit in the background =================

     WHY THIS SHAPE, and not "keep every tape and send them all at the end":

     • Nine fifteen-minute tapes is roughly 25 MB of Blob held in one tab for
       two hours. On an iPad that is exactly the sort of tab iOS reclaims —
       and it would take the whole circuit with it. Sending each station as
       it finishes means the recording stops being the browser's problem
       within a minute of the clock stopping.
     • The wait lands where there is time to spare. Marking takes as long as
       it takes; doing it while the candidate reads the next scenario spends
       time that was going to be spent anyway. Batching nine at the end puts
       every second of it at the one moment they are waiting to see results.
     • A failure surfaces at station three, not after station nine, and the
       tape is still to hand.
     • Nine audio uploads fired together is the shape most likely to trip a
       per-minute limit. One at a time never does.

     So: one worker, one job at a time, started the moment a station is left.
     The queue survives navigation within the app because it lives here, in
     the module — not in the view. It does not survive a reload, which is why
     each job's outcome is written into the session as it lands. */

  const markQ = [];
  let markBusy = false;
  const markWatchers = new Set();
  function onMarkChange(fn) { markWatchers.add(fn); return () => markWatchers.delete(fn); }
  function markPing() { markWatchers.forEach(fn => { try { fn(); } catch {} }); }
  /** What the circuit results page needs to draw itself, without the tapes. */
  function markState(sid) {
    const jobs = markQ.filter(j => j.sid === sid);
    return { queued: jobs.length, busy: markBusy && jobs.some(j => j.running) };
  }

  async function queueMark(job) {
    markQ.push(job);
    markPing();
    if (!markBusy) drainMarks();
  }

  async function drainMarks() {
    if (markBusy) return;
    markBusy = true;
    while (markQ.length) {
      const job = markQ[0];
      job.running = true; markPing();
      const meta = {};
      try {
        const attempt = await markCore({ st: job.st, ans: job.ans, rec: job.rec, session: job.session,
          choice: job.choice, attemptId: job.attemptId, meta });
        saveMark(job.sid, job.st.id, { status: 'done', attemptId: attempt.id,
          percent: attempt.result?.percent ?? null, pass: !!attempt.result?.pass,
          partial: attempt.result?.partial || null, at: Date.now() });
      } catch (e) {
        /* A failure is recorded, never swallowed. The tape went up before
           the model was called, so `retryMark` has something to send. */
        saveMark(job.sid, job.st.id, { status: 'error', message: String(e.message || e),
          attemptId: meta.attemptId || job.attemptId, audioPath: meta.audioPath || null,
          secs: job.rec?.secs || 0, at: Date.now() });
      }
      markQ.shift();
      try { if (job.rec?.url) URL.revokeObjectURL(job.rec.url); } catch {}
      markPing();
    }
    markBusy = false;
    markPing();
  }

  /* Re-send a station whose marking failed. The recording is on the server
     for 24 hours precisely so this is possible after the tab that recorded
     it has gone. */
  async function retryMark(sid, stationId, onStep = () => {}) {
    const s = await loadSession(sid);
    if (!s) throw new Error('That circuit is no longer stored.');
    const st = await station(stationId);
    if (!st) throw new Error('That station is no longer published.');
    const entry = loadMarks(sid)[stationId] || {};
    const ans = (s.answers || {})[stationId] || {};
    let rec = null;
    /* The local backend keys the tape by attempt id, the cloud one by the
       storage path it handed back. Whichever this build is, the value the
       upload returned is the one that works. */
    const handle = entry.audioPath || entry.attemptId;
    if (handle) {
      onStep('Fetching the recording that was kept…');
      try {
        const url = await Backend.getOsceAudioUrl(handle);
        if (url) {
          const blob = await (await fetch(url)).blob();
          if (blob && blob.size > 1000) rec = { blob, mime: blob.type || 'audio/webm', secs: entry.secs || 0 };
        }
      } catch { /* fall through: the transcript alone can still be marked */ }
    }
    if (!rec) onStep('The recording is no longer on the server — marking from the transcript instead.');
    const attempt = await markCore({ st, ans, rec, session: s, choice: chosenModel(), say: onStep,
      attemptId: entry.attemptId,
      // already stored: do not upload the same tape a second time
      kept: rec && entry.audioPath ? { path: entry.audioPath, expires: entry.audioExpires } : null });
    saveMark(sid, stationId, { status: 'done', attemptId: attempt.id,
      percent: attempt.result?.percent ?? null, pass: !!attempt.result?.pass,
      partial: attempt.result?.partial || null, at: Date.now() });
    markPing();
    return attempt;
  }

  /* ---------------- the marking core ----------------
     One path, used by the button on a single station and by the background
     queue in a circuit. Two things are deliberate here:

     • The TAPE GOES UP FIRST, before the model is called. It used to be
       uploaded only after a successful marking, which meant a failed
       marking took the recording with it — the one case where you most
       want it back. Now the audio survives the failure and the same
       station can be re-sent from the server for the 24 hours it is kept.

     • The attempt id is minted BEFORE either step, because it is the name
       the tape is stored under and the two must agree. */
  /**
   * `stamp` is merged onto the finished attempt before it is first saved.
   * It exists so a caller that knows something markCore cannot — which
   * live sitting this recording belongs to, who examined it — can put it
   * on the attempt without a second write, and so every route to the
   * marking (the button, the queue, a wrap-up screen) stamps it the same
   * way. `meta` is unrelated: that is the OUT-parameter the caller reads
   * the storage path back from.
   */
  async function markCore({ st, ans, rec, session, choice, say = () => {}, kept = null, attemptId = null, meta = {}, stamp = null }) {
    if (typeof Wallet !== 'undefined' && !(await Wallet.guard())) throw new Error(Wallet.blockedMessage());
    const token = await Backend.getAccessToken();
    if (!token) throw new Error('Sign in to have a station marked.');
    const id = attemptId || ('oa-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5));
    const useAudio = effectiveSource(rec, choice) === 'audio';

    /* `meta` is filled in as the upload succeeds, so the CALLER holds the
       storage path even when the marking that follows throws. Without it a
       failed station had nowhere to retry from. */
    let audioPath = kept?.path || null, audioExpires = kept?.expires || null;
    if (rec?.blob && !audioPath) {
      try {
        say('Keeping the recording…');
        const up = await Backend.uploadOsceAudio(id, rec.blob);
        if (up) { audioPath = up.path; audioExpires = up.expires; }
      } catch { /* the marking is the point; the tape is a bonus */ }
    }
    meta.attemptId = id; meta.audioPath = audioPath; meta.audioExpires = audioExpires;

    /* THE DRIVE COPY GOES NOW, NOT AFTER THE MARKING.
       It used to sit at the end of markSend, which meant it only ever
       happened when the model came back — so a station marked by hand,
       a marking that failed, and a station queued for later all reached
       the sweep without ever being offered to Drive. The tape exists at
       THIS line and its journey should not depend on what happens to it
       afterwards. `deposit` also writes an outbox row when it cannot go,
       which is what turns "the folder stopped filling" into a number.
       Not awaited: a slow Drive must not delay the marking. */
    let driveJob = null;
    if (rec?.blob && typeof Drive !== 'undefined' && Drive.configured()) {
      driveJob = Drive.deposit(rec.blob, Drive.nameFor(st.topic, Date.now(), rec.ext || 'webm'),
        { description: `AUREUM OSCE — ${st.topic || ''}`, properties: { attempt: id, station: st.id } },
        { kind: 'osce', id, topic: st.topic || '', path: audioPath, when: Date.now() }
      ).catch(() => null);
      meta.driveJob = driveJob;
    }

    /* THE TAPE GOES INTO THE LOCAL QUEUE BEFORE THE MODEL IS CALLED.

       The upload above is the cloud copy and it needs the network — which
       is exactly what is missing in the ward where this fails. IndexedDB
       needs nothing, survives the tab closing, and holds a Blob without
       encoding it. So a station whose marking cannot go through is written
       down here first and listed as awaiting marking, rather than existing
       only in a variable that the next reload throws away. */
    if (rec?.blob && typeof Pending !== 'undefined') {
      try {
        await Pending.put({ kind: 'osce', id, title: st.topic || st.id,
          blob: rec.blob, mime: rec.mime, secs: rec.secs,
          payload: { station_id: st.id, answers: ans, audioPath, audioExpires,
            choiceKey: choice.key || '', sessionId: session?.id || null },
          reason: 'Not sent yet.' });
      } catch { /* no local store is not a reason to refuse the marking */ }
    }

    try {
      const out = await markSend({ id, st, ans, rec, session, choice, useAudio, say, audioPath, audioExpires, token, driveJob, stamp });
      try { if (typeof Pending !== 'undefined') await Pending.drop(id); } catch {}
      return out;
    } catch (e) {
      // it stays in the queue, and the row records why
      try { if (typeof Pending !== 'undefined') await Pending.bumpTry(id, e.message || String(e)); } catch {}
      throw e;
    }
  }

  /* ---------------- posting a several-megabyte body ----------------

     "Load failed" is Safari's words for a fetch that never completed, and
     a five-megabyte upload from a ward with one bar is exactly how you get
     one. It is not a server error and it is not a bad request — it is a
     connection that went away mid-send, and the only sensible response to
     that is to try it again.

     Three attempts, backing off, and ONLY for the failure that a retry can
     actually fix: a network drop or a 5xx. An HTTP 400 means the request
     was wrong and sending it again would be wrong again, more expensively.

     Nothing is charged for an attempt that never arrived — the token count
     comes back with the response, so a request that produced no response
     produced no bill. */
  async function postWithRetry(url, init, say, label) {
    const WAITS = [1500, 4000];
    let last;
    for (let attempt = 0; attempt <= WAITS.length; attempt++) {
      try {
        const res = await fetch(url, init);
        // a 5xx is worth one more go; a 4xx never is
        if (res.status >= 500 && attempt < WAITS.length) {
          last = new Error(`The server was busy (HTTP ${res.status}).`);
        } else {
          return res;
        }
      } catch (e) {
        last = e;
        const msg = String(e?.message || e);
        // an abort is a decision, not a fault — never retry one
        if (/abort/i.test(msg)) throw e;
      }
      if (attempt < WAITS.length) {
        const secs = Math.round(WAITS[attempt] / 1000);
        say?.(`${label} did not go through — trying again in ${secs}s (attempt ${attempt + 2} of ${WAITS.length + 1})…`);
        await new Promise(r => setTimeout(r, WAITS[attempt]));
      }
    }
    /* Say what actually happened. "Load failed" on its own has sent people
       looking for a bug in the marking when the wifi had dropped. */
    throw new Error(/load failed|failed to fetch|networkerror/i.test(String(last?.message || last))
      ? 'The connection dropped while the recording was uploading, three times over. It is saved on this device — send it again when the signal is better.'
      : (last?.message || String(last)));
  }

  async function markSend({ id, st, ans, rec, session, choice, useAudio, say, audioPath, audioExpires, token, driveJob, stamp }) {
    {
      const body = {
        action: 'osce', provider: choice.provider, model: choice.model, dailyLimit: cfg().ai.dailyLimit,
        station: { topic: st.topic, scenario: st.scenario, total_marks: marksOf(st), pass_mark: passOf(st),
          // the CAPTION goes, never the image: the marking points are text and
          // the model does not need to read the trace to know whether the
          // candidate described it — but it does need to know one was on screen
          questions: qsOf(st).map(q => ({ id: q.id, prompt: q.prompt, marks: q.marks,
            marking_points: scorable(q.marking_points),   // a heading is context, not a point to mark
            shown: (q.images || []).length
              ? (q.images.map(im => im.caption).filter(Boolean).join('; ') || 'an image')
              : '' })) },
        answers: qsOf(st).map(q => ({ id: q.id, transcript: (ans[q.id]?.transcript || '') })),
        // only what can honestly be answered for THIS attempt
        coach: coachFor(coachWanted(), !!rec?.blob)
      };
      if (useAudio) {
        // a model that needs WAV gets the tape re-encoded; everything else
        // gets it exactly as it was recorded
        let send = rec.blob, mime = rec.mime || 'audio/webm';
        if (choice.audioFormat === 'wav') {
          say(`Re-encoding the recording for ${choice.label}…`);
          const w = await toWav(rec.blob, rec.secs);
          send = w.blob; mime = 'audio/wav';
          say(`Re-encoded to ${(w.rate / 1000)} kHz mono — ${(w.bytes / 1048576).toFixed(1)} MB to upload.`);
        }
        body.audio = { mime, data: await toBase64(send) };
      }
      say('Marking against the scheme…');
      const res = await postWithRetry(cfg().ai.apiBase, {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
        body: JSON.stringify(body)
      }, say, 'The marking');
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || `Marking failed (HTTP ${res.status}).`);
      const result = parseResult(data.text, st, data.finish);
      // when the model listened, IT produced the transcripts — keep them
      const answers = qsOf(st).map(q => {
        const fromModel = (result.questions || []).find(x => String(x.id) === String(q.id))?.transcript;
        return { id: q.id, transcript: (data.heard && fromModel != null) ? fromModel : (ans[q.id]?.transcript || '') };
      });
      const rate = (typeof Wallet !== 'undefined') ? Wallet.rate() : 340;
      const usd = ((data.usage?.in || 0) / 1e6) * (choice.rate.in || 0) + ((data.usage?.out || 0) / 1e6) * (choice.rate.out || 0);
      const attempt = {
        id,
        station_id: st.id,
        /* The actor brief travels with the attempt. A station can be
           re-written afterwards, and the report has to show the character
           who was actually played, not whoever the station has now. */
        station: { topic: st.topic, scenario: st.scenario, total_marks: marksOf(st), pass_mark: passOf(st),
          role_player: roleOf(st) || undefined },
        // the blueprint tag is copied onto the attempt: a station may be
        // re-tagged later, and a past result must keep the module it was
        // actually sat under or the coverage map rewrites its own history
        bp: OsceBlueprint.tagOf(st) || null,
        questions: qsOf(st), answers, result, created: Date.now(),
        model: data.model || choice.model, modelLabel: choice.label, provider: choice.provider,
        heard: !!data.heard, elapsed: session?.elapsed || null,
        cost: { inTok: data.usage?.in || 0, outTok: data.usage?.out || 0, usd, lkr: usd * rate, rate }
      };
      /* The tape is already up — it went before the model was called, so a
         failed marking leaves something to retry with. Record where. */
      if (audioPath) { attempt.audioPath = audioPath; attempt.audioExpires = audioExpires; attempt.audioSecs = rec?.secs || null; }
      // whatever the caller knew and markCore could not — before the first save
      if (stamp) Object.assign(attempt, stamp);
      try { await Backend.saveOsceAttempt(attempt); bustAttempts(); } catch {}
      try { if (typeof Wallet !== 'undefined') Wallet.bust(); } catch {}

      /* The Drive copy was started at tape time, before the model was
         called — see markCore. All that is left is to write down where
         it went, once it has, without ever making the result wait for
         it. A miss is already recorded in the outbox by `deposit`. */
      if (driveJob) {
        driveJob.then(up => {
          if (!up) return;
          attempt.drive = { id: up.id, link: up.link, name: up.name };
          Backend.saveOsceAttempt(attempt).catch(() => {}); bustAttempts();
        }).catch(() => {});
      }
      return attempt;
    }
  }

  function b64ToBuf(b64) {
    const bin = atob(String(b64));
    const buf = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
    return buf.buffer;
  }

  const toBase64 = blob => new Promise((res, rej) => {
    const fr = new FileReader();
    fr.onload = () => res(String(fr.result).split(',')[1]);
    fr.onerror = () => rej(new Error('Could not read the recording.'));
    fr.readAsDataURL(blob);
  });

  /* ---------------- re-encoding the tape for models that need WAV ----------------

     The recorder produces webm/opus, which is the right thing to store: a
     15-minute station is about 2.5 MB. Gemini reads it as it is.

     OpenAI does not — its input_audio part accepts wav or mp3 only. So for a
     GPT model the tape is decoded with WebAudio and written out as mono
     16-bit PCM. WAV is uncompressed, which is the whole problem: 15 minutes
     at 16 kHz is 28 MB before base64, and base64 adds a third again. The
     sample rate is therefore chosen to fit the ceiling rather than fixed —
     16 kHz where the station is short enough, down to 8 kHz for a full
     15-minute one. Speech stays intelligible throughout; consonants get less
     crisp as it drops, which is worth saying out loud in the UI rather than
     hiding, because drug names are exactly what suffers.

     If even the lowest rate will not fit, this refuses rather than uploading
     something that is going to be rejected at the far end. */
  const WAV_RATES = [16000, 12000, 8000];
  const WAV_CEILING = 24 * 1024 * 1024;        // bytes of base64, under the server's 34 MB cap

  function wavRateFor(secs) {
    const fits = r => Math.ceil((44 + secs * r * 2) * 4 / 3) <= WAV_CEILING;
    return WAV_RATES.find(fits) || 0;
  }

  async function toWav(blob, secs) {
    const rate = wavRateFor(secs || 900);
    if (!rate) throw new Error('That recording is too long to send to a model that needs WAV. Mark it on Gemini, which takes the recording as it is, or mark from the transcript.');
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) throw new Error('This browser cannot re-encode audio. Mark it on Gemini or from the transcript.');
    const ac = new Ctx();
    let buf;
    try { buf = await ac.decodeAudioData(await blob.arrayBuffer()); }
    finally { try { ac.close(); } catch {} }

    // average the channels down to mono, then resample by linear interpolation
    const src = buf.getChannelData(0);
    const chans = buf.numberOfChannels;
    const mono = chans > 1
      ? (() => { const m = new Float32Array(src.length);
          for (let c = 0; c < chans; c++) { const d = buf.getChannelData(c); for (let i = 0; i < m.length; i++) m[i] += d[i] / chans; }
          return m; })()
      : src;
    const ratio = buf.sampleRate / rate;
    const n = Math.floor(mono.length / ratio);
    const out = new Int16Array(n);
    for (let i = 0; i < n; i++) {
      const x = i * ratio, i0 = x | 0, f = x - i0;
      const s = (mono[i0] || 0) * (1 - f) + (mono[i0 + 1] || 0) * f;
      out[i] = Math.max(-32768, Math.min(32767, Math.round(s * 32767)));
    }

    const bytes = new DataView(new ArrayBuffer(44 + out.length * 2));
    const str = (o, s) => { for (let i = 0; i < s.length; i++) bytes.setUint8(o + i, s.charCodeAt(i)); };
    str(0, 'RIFF'); bytes.setUint32(4, 36 + out.length * 2, true); str(8, 'WAVEfmt ');
    bytes.setUint32(16, 16, true); bytes.setUint16(20, 1, true); bytes.setUint16(22, 1, true);
    bytes.setUint32(24, rate, true); bytes.setUint32(28, rate * 2, true);
    bytes.setUint16(32, 2, true); bytes.setUint16(34, 16, true);
    str(36, 'data'); bytes.setUint32(40, out.length * 2, true);
    for (let i = 0; i < out.length; i++) bytes.setInt16(44 + i * 2, out[i], true);
    return { blob: new Blob([bytes.buffer], { type: 'audio/wav' }), rate, bytes: bytes.byteLength };
  }

  /* A marking answer that stops in the middle of an array is still worth
     most of what it cost. This closes whatever the model left open — the
     partial string, then the unbalanced brackets — and returns the object
     if it parses. Anything genuinely unfinished at the end (a half-written
     point) is dropped by the closing rather than guessed at. */
  function salvageJson(raw) {
    const a = raw.indexOf('{');
    if (a < 0) return null;
    const s = raw.slice(a);
    let inStr = false, esc = false;
    const stack = [];
    let cut = 0, cutStack = null;       // the last point at which this was closable
    for (let i = 0; i < s.length; i++) {
      const c = s[i];
      if (inStr) {
        if (esc) esc = false;
        else if (c === '\\') esc = true;
        else if (c === '"') inStr = false;
        continue;
      }
      if (c === '"') { inStr = true; continue; }
      if (c === '{' || c === '[') stack.push(c === '{' ? '}' : ']');
      else if (c === '}' || c === ']') stack.pop();
      /* A comma or a closing bracket ends a complete element. Remember
         BOTH the position and the nesting there — closing with the stack
         as it stands at the very end would close the wrong brackets. */
      if (c === ',' || c === '}' || c === ']') { cut = i + 1; cutStack = stack.slice(); }
    }
    if (!stack.length) { try { return JSON.parse(s); } catch { return null; } }
    if (!cut || !cutStack) return null;
    let body = s.slice(0, cut).replace(/,\s*$/, '');
    for (let i = cutStack.length - 1; i >= 0; i--) body += cutStack[i];
    try { return JSON.parse(body); } catch { return null; }
  }

  /* ================= THE TICKS ARE THE MARKING =================

     A real report came back reading "Q3 — 20/20" above five marking
     points of which three said "did not mention". Both numbers came from
     the same model in the same answer, and they cannot both be true.

     The marking prompt already spells the arithmetic out: share = the
     question's marks divided by its points, credit = the share if
     covered, half if partial, none if missed, awarded = the sum. A model
     that ticks the points correctly and then writes a number that
     contradicts them has done the hard half and fluffed the easy one —
     and it is the easy half that a candidate reads as their score.

     So the number is no longer taken on trust. It is COMPUTED, from the
     ticks, by the same rule the hand-marking sheet has always used — and
     where the model's own figure differs it is kept as `claimed`, so the
     report can say what happened instead of quietly disagreeing.

     Why the ticks win, and not the number: the ticks are the evidence.
     Each one is a specific claim about a specific sentence, with a note
     saying what was said or missing, and the candidate can check every
     one against their own transcript. "20/20" is a claim about nothing
     that can be checked. When a marker contradicts itself, believe the
     half that shows its working.

     A question is left exactly as it came when there is nothing to
     recompute from — no points, or no marks on the question. Guessing
     would be the same fault in the other direction. */

  const PT_CREDIT = { covered: 1, partial: 0.5, missed: 0 };
  function creditOf(status) {
    const s = String(status || '').toLowerCase();
    if (/cover/.test(s)) return PT_CREDIT.covered;
    if (/part/.test(s)) return PT_CREDIT.partial;
    return PT_CREDIT.missed;                       // missed, blank, or a word we do not know
  }

  /**
   * Recompute every question's marks from its ticks, and the totals from
   * those. Mutates and returns `d`. `st` is the station when we have it —
   * an imported marking may be against a station we do not hold, and the
   * question's own `max` is then the only scale there is.
   */
  function reconcile(d, st) {
    if (!d || !Array.isArray(d.questions)) return d;
    const src = {};
    (st ? qsOf(st) : []).forEach((q, i) => { src[String(q.id)] = q; src['#' + i] = q; });

    let changed = 0, before = 0, after = 0;
    d.questions.forEach((qr, i) => {
      const pts = Array.isArray(qr.points) ? qr.points : [];
      const q = src[String(qr.id)] || src['#' + i] || {};
      const max = Number(qr.max) || Number(q.marks) || 0;
      const was = Number(qr.awarded) || 0;
      before += was;
      if (!pts.length || !max) { after += was; return; }   // nothing to recompute from
      const share = max / pts.length;
      const got = pts.reduce((n, p) => n + share * creditOf(p.status), 0);
      const now = Math.min(max, Math.round(got * 2) / 2);
      /* Rounding to the half mark means a model can legitimately land a
         quarter of a mark away. Only a real disagreement is a correction. */
      if (Math.abs(now - was) > 0.5) {
        qr.claimed = was;
        qr.awarded = now;
        changed++;
      }
      qr.max = max;
      qr.share = Math.round(share * 100) / 100;
      after += Number(qr.awarded) || 0;
    });

    if (!changed) return d;
    d.total = Math.round(after * 2) / 2;
    const max = Number(d.max) || d.questions.reduce((n, q) => n + (Number(q.max) || 0), 0);
    if (max) { d.max = max; d.percent = Math.round((d.total / max) * 100); }
    d.regraded = { questions: changed, from: Math.round(before * 2) / 2, to: d.total };
    return d;
  }

  function parseResult(text, st, finish) {
    let raw = String(text || '').trim().replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
    let d = null;
    try { d = JSON.parse(raw); } catch {
      const a = raw.indexOf('{'), b = raw.lastIndexOf('}');
      if (a >= 0 && b > a) { try { d = JSON.parse(raw.slice(a, b + 1)); } catch {} }
      if (!d) d = salvageJson(raw);         // truncated mid-array — keep what arrived
    }
    if (!d) {
      /* Say WHICH failure this is. "Try again" was true but useless: the
         one cause worth acting on differently is a cut-off answer, and the
         server now names it. */
      throw new Error(finish === 'MAX_TOKENS'
        ? 'The marker ran out of room before it finished. This has been given more headroom — press Mark again, and tell the developer if it repeats.'
        : finish
          ? `The marker stopped early (${finish}) and returned nothing usable. Try again, or a different model.`
          : 'The marker did not return readable marks. Try again, or a different model.');
    }

    /* THE POINT TEXT COMES FROM THE STATION, NOT FROM THE MODEL.

       Asked to echo each marking point back, a model abbreviates: a point
       reading "Measured between 11+0 and 13+6 weeks, CRL 45–84 mm, in the
       mid-sagittal plane with the neck neutral" came back as "Method of
       measurement". That is fine for saying WHICH point was missed and
       useless for revising from — and this report is what the candidate
       revises from.

       So the model is trusted for the STATUS and the NOTE, and the wording
       is taken from the station's own scheme, matched by position within
       the question. Where the counts disagree the model's text is kept, so
       nothing is ever silently mismatched. */
    const bySrcId = {};
    qsOf(st).forEach(q => bySrcId[String(q.id)] = scorable(q.marking_points));
    (d.questions || []).forEach(qr => {
      const src = bySrcId[String(qr.id)];
      if (!src || !Array.isArray(qr.points)) return;
      if (src.length !== qr.points.length) return;         // a mismatch is not a mapping
      qr.points = qr.points.map((p, i) => Object.assign({}, p, {
        point: src[i],                                     // the scheme's own words
        heading: p.point && String(p.point) !== String(src[i]) ? p.point : ''
      }));
    });

    /* A TRUNCATED MARKING IS NOT A LOW SCORE.

       This is the fault behind "8 questions, only 4 marked, 44/100".
       salvageJson keeps whatever questions arrived before the model ran
       out of room — but total, max and percent are written at the END of
       the JSON, so a salvaged object has the questions and none of the
       totals. The old code then summed four questions against the
       station's full 100 and printed 44%: a number that looks like a
       result, reads like a fail, and is neither. Nothing about it said
       four questions had never been looked at.

       Quitting a circuit had nothing to do with it — the marking of one
       station does not know the round exists.

       So: count what actually came back. If questions are missing, the
       attempt is PARTIAL — scored over the marks that were really
       marked, flagged, and offered to be marked again. A partial is never
       given a pass/fail, because passing 44 of 52 marks that happen to be
       the easy half is not a pass and not a fail either. */
    /* Before a single total is worked out, make the numbers agree with
       the ticks — see the note above `reconcile`. It runs here rather
       than in the renderer so that everything downstream (the circuit
       mean, the progress page, the drift ledger, the recall queue, a
       report printed a month later) is looking at the same corrected
       figure, and so a correction is recorded once with the attempt
       instead of recomputed differently in five places. */
    reconcile(d, st);

    const want = qsOf(st);
    const got = (d.questions || []).length;
    const short = want.length && got < want.length;

    const markedMax = (d.questions || []).reduce((n, q) => n + (Number(q.max) || 0), 0);
    const max = short ? (markedMax || marksOf(st)) : (d.max || marksOf(st));
    const total = (!short && d.total != null)
      ? d.total
      : (d.questions || []).reduce((n, q) => n + (q.awarded || 0), 0);
    const percent = (!short && d.percent != null)
      ? d.percent
      : Math.round((total / Math.max(1, max)) * 100);

    const out = Object.assign(d, { max, total, percent });
    if (short) {
      const seen = new Set((d.questions || []).map(q => String(q.id)));
      out.partial = {
        marked: got, of: want.length,
        missing: want.filter(q => !seen.has(String(q.id))).map(q => q.prompt || String(q.id)),
        why: finish === 'MAX_TOKENS'
          ? 'The marker ran out of room part-way through.'
          : finish ? `The marker stopped early (${finish}).`
          : 'The marker\u2019s answer was cut off part-way through.'
      };
      out.pass = null;                    // no verdict on half a station
    } else {
      /* A regraded station cannot keep the model's own verdict: "pass"
         was written against the total it thought it had given, and that
         total has just been corrected. The pass mark decides. */
      out.pass = (d.regraded || d.pass == null) ? total >= passOf(st) : d.pass;
    }
    return out;
  }

  /* ================= the result (#/osce/result/:id) ================= */

  async function renderResult(view, id, user) {
    let a = null;
    try { a = await Backend.getOsceAttempt(id); } catch {}
    if (!a) { view.innerHTML = shell('bank', `<p class="muted">That result is no longer stored. <a class="link" href="#/osce">Back to OSCE</a></p>`); FX.viewIn(view); return; }
    /* Every point this marking recorded as missed goes into the Recall
       deck now. Waiting for the next visit to that tab would mean the
       card you most want tomorrow is the one card that is not there —
       and opening the report is the moment the marking exists. Cheap
       (localStorage), idempotent (keyed on station + point), and never
       allowed to stand between a candidate and their result. */
    try { if (typeof Recall !== 'undefined') Recall.noteAttempt(user, a); } catch {}
    const r = a.result || {};
    const part = r.partial || null;
    const tone = part ? 'border'
      : r.percent >= 70 ? 'dist' : r.percent >= 60 ? 'pass' : r.percent >= 50 ? 'border' : 'fail';
    const stCls = s => /cover/i.test(s) ? 'cov' : /partial/i.test(s) ? 'par' : 'mis';
    const stIco = s => /cover/i.test(s) ? '✓' : /partial/i.test(s) ? '~' : '✗';
    const qById = {}; (a.questions || []).forEach(q => qById[String(q.id)] = q);
    const ansById = {}; (a.answers || []).forEach(x => ansById[String(x.id)] = x.transcript);

    view.innerHTML = `
      <section class="page os-result">
        <a class="link muted dev-back" href="#/osce">← OSCE stations</a>
        <header class="os-res-head es-band-head-${tone}" data-animate>
          <div>
            <p class="kicker">OSCE STATION RESULT · ${esc(new Date(a.created || Date.now()).toLocaleDateString('en-GB', { dateStyle: 'medium' }))}${
              a.source === 'manual' ? ' · MARKED IN PERSON' : a.heard ? ' · MARKED FROM THE RECORDING' : ''}</p>
            <h1 class="page-title">${esc(a.station?.topic || '')}</h1>
            <p class="muted">${esc(a.station?.scenario || '')}</p>
          </div>
          <div class="os-res-score">
            <div class="es-dial" id="os-dial" data-pct="${r.percent || 0}"><span>${r.percent != null ? r.percent + '%' : '—'}</span></div>
            <span class="es-fb-band es-band-${tone} big">${part ? 'Part-marked' : r.pass ? 'Pass' : 'Below the pass mark'}</span>
            <span class="muted tiny">${part
              ? `${r.total}/${r.max} of the ${part.marked} question${part.marked === 1 ? '' : 's'} that were marked`
              : `${r.total}/${r.max} · pass mark ${a.station?.pass_mark ?? '—'}`}</span>
          </div>
        </header>

        <div id="os-res-circ"></div>
        <div id="os-res-cmp"></div>

        ${part ? `<div class="card os-part-note" data-animate>
          <p><strong>⚠️ Only ${part.marked} of the ${part.of} questions were marked.</strong>
            ${esc(part.why)} The percentage above is out of the ${r.max} marks that were actually looked at,
            not out of the station's ${a.station?.total_marks ?? '—'} — and there is deliberately no pass or fail
            here, because half a station is neither.</p>
          ${part.missing?.length ? `<p class="muted tiny">Never reached:
            ${part.missing.map(m => esc(String(m).slice(0, 90))).join(' · ')}</p>` : ''}
          <p class="muted tiny">The recording is untouched, so marking it again costs only the marking.</p>
          <div class="os-part-acts">
            <a class="btn btn-gold btn-sm" href="#/osce/station/${encodeURIComponent(a.station_id || '')}">Mark it again</a>
          </div>
        </div>` : ''}

        ${/* THE MARKER'S ARITHMETIC, CORRECTED IN THE OPEN.

              Never a silent fix. The candidate is entitled to know that
              the score they are looking at is not the one the model
              typed, and to check the working themselves — every tick is
              on this page, a few inches below. */''}
        ${r.regraded ? `<div class="card os-regrade" data-animate>
          <p><strong>⚖️ The marks were recalculated from the ticks.</strong>
            The marker ticked the scheme point by point and then wrote a total that did not match its own ticks —
            ${r.regraded.from} where the points it marked come to <strong>${r.regraded.to}</strong>. AUREUM scores from
            the points, so this report shows ${r.regraded.to}/${r.max}.</p>
          <p class="muted tiny">${r.regraded.questions} question${r.regraded.questions === 1 ? ' was' : 's were'}
            affected; each shows the marker's own figure struck through. Every point below says what was said or
            missing, so you can check the marking that produced this against your own transcript — which is exactly
            why the ticks are believed and the total is not.</p>
        </div>` : ''}

        ${a.source === 'claude' ? `<div class="card os-claude-note" data-animate>
          <p><strong>✦ This one was examined and marked by a chat model.</strong>
            You sat it out loud against ${esc(a.examiner?.name || 'Claude')} on the other half of the screen; AUREUM
            held the clock and the recording, and this is the marking it gave back against the same scheme.</p>
          <p class="muted tiny">It is kept apart from the AI-marked attempts because a different examiner asked the
            questions — mixing the two would make the average mean nothing.</p>
        </div>` : ''}

        ${a.source === 'manual' ? `<div class="card os-hand-note" data-animate>
          <p><strong>✍️ This one was marked by a person, not by AI.</strong>
            ${a.examiner?.name ? `${esc(a.examiner.name)} sat opposite you with the scheme and ticked it point by point.`
              : 'Somebody sat opposite you with the scheme and ticked it point by point.'}
            ${a.imported ? 'It was sent to you in the chat and imported here.' : ''}</p>
          <p class="muted tiny">There is no recording and no transcript — the marks are their judgement. Everything
            else on this page works exactly as it does for an AI-marked station, including the printout.</p>
        </div>` : ''}

        ${(() => {
          /* WHAT THE EXAMINER ADMITS ABOUT ITSELF.
             A chat model that asked an invented question and was pulled
             back mid-station still produces a clean-looking marking, and
             the mark is then partly against questions the scheme never
             asked. That has to be on the report — not so the attempt is
             thrown away, but so a percentage is read for what it is, and
             so a repeated drift is visible across sessions instead of
             being re-discovered every time. */
          const pi = r.processIntegrity;
          if (!pi || (pi.preflightConfirmed !== false && !pi.driftDetected)) return '';
          return `<div class="card os-drift" data-animate>
            <p><strong>⚠️ The examiner reported a problem with its own process.</strong></p>
            <ul class="os-drift-list">
              ${pi.preflightConfirmed === false
                ? '<li>The question list was <strong>never confirmed</strong> before the station began, so nothing checked that the model had the real questions.</li>' : ''}
              ${pi.driftDetected
                ? '<li>A question was <strong>asked that is not in the scheme</strong>, and had to be corrected during the station.</li>' : ''}
            </ul>
            ${pi.driftNotes ? `<p class="muted tiny">${esc(pi.driftNotes)}</p>` : ''}
            <p class="muted tiny">Read the marks with that in mind. Re-paste the station block as a single whole
              message next time — a block pasted in pieces, or a second station in the same conversation, is what
              causes this.</p>
          </div>`;
        })()}

        ${r.examinerComment ? `<div class="card es-examiner" data-animate>
          <div class="es-inbox-head">
            <h3 class="card-title">👨‍⚖️ Examiner's verdict</h3>
            <button class="btn btn-ghost btn-sm" id="os-hear">▶ Hear it</button>
          </div>
          <p>${esc(r.examinerComment)}</p>
          <p class="dev-row-msg" id="os-hear-msg"></p></div>` : ''}

        ${r.structure ? `<div class="card" data-animate>
          <h3 class="card-title">How you performed</h3>
          <div class="os-perf">
            ${['coverage', 'fluency', 'safety'].filter(k => r.structure[k]).map(k => `
              <div class="os-perf-c"><span class="os-perf-k">${k === 'coverage' ? '🎯 Coverage' : k === 'fluency' ? '🗣 Delivery' : '⚠ Safety'}</span>
                <p>${esc(r.structure[k])}</p></div>`).join('')}
          </div></div>` : ''}

        ${r.coaching && Object.keys(r.coaching).length ? `<div class="card os-coach-out" data-animate>
          <h3 class="card-title">🎧 The mock examiner's coaching</h3>
          <p class="muted">Not about the marks — about how you came across, and what to do differently in the room.
            You asked for these before the station was marked.</p>
          ${COACH.filter(c => r.coaching[c.id]).map(c => `
            <div class="os-coach-sec">
              <h4>${esc(c.label)}</h4>
              <p>${esc(r.coaching[c.id])}</p>
            </div>`).join('')}
        </div>` : ''}

        <div class="card" data-animate>
          <h3 class="card-title">Marked against the scheme</h3>
          <p class="muted tiny"><span class="es-dot cov"></span> covered · <span class="es-dot par"></span> partial ·
            <span class="es-dot mis"></span> missed. Every point the scheme carries, and whether you said it.</p>
          ${(r.questions || []).map((qr, i) => {
            const q = questionFor(a.questions, qr.id, i);
            const pct = qr.max ? Math.round((qr.awarded / qr.max) * 100) : 0;
            return `
            <details class="os-qres" ${i === 0 ? 'open' : ''}>
              <summary>
                <span class="os-qres-n">Q${i + 1}</span>
                <span class="os-qres-p">${esc(q.prompt || '')}</span>
                <span class="os-qres-m ${pct < 50 ? 'bad' : pct < 70 ? '' : 'good'}">${
                  qr.claimed != null ? `<s class="os-qres-was" title="what the marker itself wrote">${qr.claimed}</s> ` : ''
                }${qr.awarded}/${qr.max}</span>
                <span class="dc-caret">▸</span>
              </summary>
              <div class="os-qres-body">
                <div class="es-points">${(qr.points || []).map((p, pi) => `
                  <div class="es-point es-st-${stCls(p.status)}">
                    <span class="es-point-icon">${stIco(p.status)}</span>
                    <div class="es-point-body">
                      ${p.heading ? `<p class="es-point-head">${esc(p.heading)}</p>` : ''}
                      <p class="es-point-text" data-qe-line><span class="qe-text">${esc(p.point)}</span>${
                        schemePencil(qr.id, pi)}</p>
                      ${p.note ? `<p class="es-point-note">${esc(p.note)}</p>` : ''}
                    </div>
                  </div>`).join('')}</div>
                ${qr.comment ? `<p class="os-qres-c">${esc(qr.comment)}</p>` : ''}
                <details class="os-said-fold"><summary>What you said</summary>
                  <p class="os-said-t">${esc(ansById[String(qr.id)] || '(nothing was captured)')}</p></details>
              </div>
            </details>`;
          }).join('')}
        </div>

        ${(r.improvements || []).length ? `<div class="card es-prio" data-animate>
          <h3 class="card-title">🚀 Do these first</h3>
          <ol class="es-prio-list">${r.improvements.map((x, i) => `
            <li class="es-prio-item"><span class="es-prio-rank">${i + 1}</span>
              <div class="es-prio-body"><p>${esc(typeof x === 'string' ? x : x.action)}</p>
                ${x.marks ? `<span class="es-prio-meta"><span class="es-prio-gain">+${x.marks} marks</span></span>` : ''}</div>
            </li>`).join('')}</ol></div>` : ''}

        ${(r.strengths || []).length ? `<div class="card" data-animate>
          <h3 class="card-title">✅ What was good</h3>
          <ul class="es-flag-list">${r.strengths.map(x => `<li>${esc(x)}</li>`).join('')}</ul></div>` : ''}

        ${(r.keyLearning || []).length ? `<div class="card es-klp" data-animate>
          <h3 class="card-title">🔑 Key learning points</h3>
          <ol class="es-klp-list">${r.keyLearning.map((k, i) => `<li class="${i === 0 ? 'top' : ''}">${esc(k)}</li>`).join('')}</ol></div>` : ''}

        ${(() => {
          /* THE CONVERSATION, FROM INSIDE THE CHARACTER.
             The most useful thing a role-player station produces is not
             the marks — it is being told which of her cues you walked
             past. A candidate who never learns that the pause after "my
             husband doesn't know yet" was an invitation makes the same
             omission in the real room, where it decides the station. */
          const c = r.conversation;
          if (!c || typeof c !== 'object') return '';
          const missed = (c.missed || []).filter(x => x && (x.cue || x.wanted));
          const phr = (c.phrasing || []).filter(x => x && (x.said || x.better));
          const got = (c.elicited || []).filter(Boolean);
          if (!c.rapport && !missed.length && !phr.length && !got.length) return '';
          return `<div class="card es-conv" data-animate>
            <h3 class="card-title">🎭 How the conversation went${c.character ? ` — ${esc(c.character)}` : ''}</h3>
            <p class="muted tiny">Written from inside the character, not by the examiner. None of it is marked
              unless the scheme has a communication section — it is the half of the station a viva cannot teach.</p>
            ${c.rapport ? `<p class="es-conv-r">${esc(c.rapport)}</p>` : ''}
            ${got.length ? `<div class="es-conv-sec"><h4>What you got out of them</h4>
              <ul class="es-flag-list">${got.map(x => `<li>${esc(x)}</li>`).join('')}</ul></div>` : ''}
            ${missed.length ? `<div class="es-conv-sec"><h4>Cues you walked past</h4>
              <div class="es-cue-list">${missed.map(m => `<div class="es-cue">
                <p class="es-cue-c">“${esc(m.cue || '')}”</p>
                ${m.wanted ? `<p class="es-cue-w"><span>→</span> ${esc(m.wanted)}</p>` : ''}
                ${m.cost ? `<p class="es-cue-x">${esc(m.cost)}</p>` : ''}
              </div>`).join('')}</div></div>` : ''}
            ${phr.length ? `<div class="es-conv-sec"><h4>How to put it</h4>
              <div class="es-cue-list">${phr.map(p => `<div class="es-cue is-phr">
                <p class="es-cue-c">${esc(p.said || '')}</p>
                <p class="es-cue-w"><span>→</span> ${esc(p.better || '')}</p>
                ${p.why ? `<p class="es-cue-x">${esc(p.why)}</p>` : ''}
              </div>`).join('')}</div></div>` : ''}
          </div>`;
        })()}

        ${/* The actor brief, now that the station is over and it is
              teaching rather than an answer sheet. Read afterwards it
              shows exactly what was there to be found. */
          hasRole(a.station) ? `<details class="card es-rp-fold" data-animate>
          <summary><span class="card-title">🎭 What the character was actually briefed with</span><span class="dc-caret">▸</span></summary>
          <p class="muted tiny">Hidden until now for the obvious reason. Read it against your own answers: every
            "only if asked" line below is a mark that was sitting there waiting for the right question.</p>
          ${roleHtml(a.station, 'after')}
        </details>` : ''}

        ${/* THE TEACHING THAT USED TO DIE WITH THE CHAT.
              A chat model gives away far more after the clock stops than
              the marks: the topic summarised properly, the mnemonic it
              invented, the trap everyone falls into, the guideline that
              settles it. All of that lived in a conversation window that
              was closed by the evening. These four sections are the same
              content, kept — and because they are ordinary fields on an
              ordinary attempt, the printout, the study document and the
              search all get them for free. */ ''}
        ${String(r.summary || '').trim() ? `<div class="card es-summary" data-animate>
          <h3 class="card-title">📖 The topic, properly</h3>
          <p class="muted tiny">Not a recap of your answer — what you should be able to say about this cold.</p>
          ${String(r.summary).split(/\n{2,}/).filter(p => p.trim()).map(p => `<p>${esc(p.trim())}</p>`).join('')}
        </div>` : ''}

        ${(r.mnemonics || []).length ? `<div class="card es-mnem" data-animate>
          <h3 class="card-title">🧠 Ways to remember it</h3>
          <div class="es-mnem-list">${r.mnemonics.map(m => {
            const aid = typeof m === 'string' ? m : (m.aid || '');
            const exp = typeof m === 'string' ? '' : (m.expands || '');
            const use = typeof m === 'string' ? '' : (m.use || '');
            return `<div class="es-mnem-i">
              <p class="es-mnem-aid">${esc(aid)}</p>
              ${exp ? `<p class="es-mnem-x">${esc(exp)}</p>` : ''}
              ${use ? `<p class="muted tiny">${esc(use)}</p>` : ''}
            </div>`;
          }).join('')}</div></div>` : ''}

        ${(r.pitfalls || []).length ? `<div class="card es-pit" data-animate>
          <h3 class="card-title">🪤 What loses marks here</h3>
          <div class="es-pit-list">${r.pitfalls.map(p => {
            const trap = typeof p === 'string' ? p : (p.trap || '');
            const instead = typeof p === 'string' ? '' : (p.instead || '');
            return `<div class="es-pit-i">
              <p class="es-pit-t"><span>✗</span> ${esc(trap)}</p>
              ${instead ? `<p class="es-pit-s"><span>✓</span> ${esc(instead)}</p>` : ''}
            </div>`;
          }).join('')}</div></div>` : ''}

        ${(r.reading || []).length ? `<div class="card es-read" data-animate>
          <h3 class="card-title">📚 Where to settle it</h3>
          <ul class="es-read-list">${r.reading.map(x => {
            const src = typeof x === 'string' ? x : (x.source || '');
            const why = typeof x === 'string' ? '' : (x.why || '');
            return `<li><strong>${esc(src)}</strong>${why ? `<span class="muted tiny">${esc(why)}</span>` : ''}</li>`;
          }).join('')}</ul></div>` : ''}

        ${a.audioPath ? `<div class="card os-audio" data-animate>
          <h3 class="card-title">🎧 Your recording</h3>
          <p class="muted" id="os-au-note">Loading the recording…</p>
          <div id="os-au"></div>
          ${a.drive ? `<p class="muted tiny">☁ A copy is in your Drive folder —
            <a href="${esc(a.drive.link)}" target="_blank" rel="noopener">open it</a>.</p>`
            : (typeof Drive !== 'undefined' ? Drive.warnHtml('after') : '')}
        </div>` : ''}

        ${a.cost ? `<div class="card os-cost" data-animate>
          <h3 class="card-title">🧾 What this marking cost</h3>
          <div class="os-cost-grid">
            <div><strong>${(a.cost.inTok || 0).toLocaleString('en-US')}</strong><span>tokens in</span></div>
            <div><strong>${(a.cost.outTok || 0).toLocaleString('en-US')}</strong><span>tokens out</span></div>
            <div><strong>$${(a.cost.usd || 0).toFixed(4)}</strong><span>US dollars</span></div>
            <div class="is-lkr"><strong>LKR ${(a.cost.lkr || 0).toFixed(2)}</strong><span>rupees</span></div>
          </div>
          <p class="muted tiny">${esc(a.modelLabel || a.model || '')}${a.heard ? ' · marked from your recording' : ' · marked from the transcript'}
            · converted at LKR ${a.cost.rate || 340}/USD. This is on your Billing &amp; balance page under
            <strong>OSCE marking</strong>.</p>
        </div>` : ''}

        <div class="card os-explore" data-animate>
          <h3 class="card-title">✨ Explore this station with AI</h3>
          <p class="muted">Ask about anything in the marking above — why a point was scored the way it was, the
            guideline behind it, how you should have structured the answer. The model has the scheme and your marks in
            front of it, so the answers are about <em>this</em> station, not the topic in general.</p>
          <div class="os-ex-head">
            <label class="os-prov-l">Ask
              <select class="sel" id="os-ex-model">${modelChoices().map(m =>
                `<option value="${esc(m.key)}">${esc(m.label)} — $${m.rate.in}/$${m.rate.out} per 1M</option>`).join('')}</select></label>
            <button class="btn btn-ghost btn-sm" id="os-ex-web" title="Find the guidelines and trials behind this station">🌐 Search the web</button>
          </div>
          <div id="os-ex-web-out"></div>
          <div class="ai-messages" id="os-ex-msgs"></div>
          <form class="ai-ask" id="os-ex-ask">
            <input type="text" id="os-ex-input" autocomplete="off"
              placeholder="Ask a follow-up… e.g. why is McRoberts first? / what did a full-mark answer to Q3 look like?">
            <button class="btn btn-primary btn-sm" type="submit">Ask</button>
          </form>
          <p class="ai-disclaimer">AI-generated — verify against NICE / RCOG / SLCOG guidance.</p>
        </div>

        <div class="card os-deckmake" data-animate>
          <h3 class="card-title">📘 Write the study document for this case</h3>
          <p class="muted">Not a pile of cards — one page about this station: how to recognise it, the management in
            the order it happens with the doses and thresholds that carry the marks, what an examiner asks next, and
            every point of the scheme marked <strong>✓ you said</strong>, <strong>~ half-said</strong> or
            <strong>✗ you did not</strong>. It lands under <strong>Study documents</strong> in this tab, and
            downloads as a PDF.</p>
          <div class="os-mark-acts">
            <button class="btn btn-gold" id="os-makedeck">Write the study document</button>
            <span class="dev-status" id="os-deck-msg"></span>
          </div>
        </div>

        <div class="es-report-foot">
          <button class="btn btn-gold" id="os-print">🖨 Print / Save as PDF</button>
          <button class="btn btn-ghost" id="os-copy"
            title="Copy the scenario and questions as plain text — without the marking scheme and without your transcript — to paste into NotebookLM, Gemini or ChatGPT">📄 Copy the station</button>
          <a class="btn btn-ghost" href="#/osce/station/${encodeURIComponent(a.station_id)}">↺ Sit it again</a>
          <button class="btn btn-ghost btn-sm qr-danger" id="os-del">🗑 Delete this result</button>
        </div>
      </section>`;
    FX.viewIn(view);
    /* The report is where a wrong marking point is most often noticed —
       you are reading the scheme line by line against what you said. So
       the pencils are here too, writing back to the station itself. */
    wireSchemeEdit(view, a.station_id);
    /* A station sat against a chat model out of a circuit leaves the
       circuit stopped where it was; this is the way back on, offered on
       whichever page the reader actually lands on. */
    try { AiOsce?.resumeStrip?.(view.querySelector('#os-res-circ'), a); } catch {}

    /* IF SOMEBODY ELSE HAS MARKED THIS TOO, SAY SO HERE.
       The comparison is the most informative page in the app and it is
       useless if nobody knows it exists. It is offered from the report
       of an attempt whose station has been marked another way — which is
       the exact moment the comparison becomes possible. Drawn after the
       page, from the cached list, so it costs nothing. */
    (async () => {
      const box = view.querySelector('#os-res-cmp');
      if (!box) return;
      let list = [];
      try { list = (await myAttempts()) || []; } catch { return; }
      const others = list.filter(x => String(x.station_id) === String(a.station_id)
        && srcOf(x) !== srcOf(a));
      if (!others.length || !box.isConnected) return;
      const kinds = [...new Set(others.map(srcOf))].map(k => SRC[k].label);
      box.innerHTML = `<div class="card os-cmp-offer" data-animate>
        <h3 class="card-title">⚡ ${kinds.join(' and ')} marked this one too</h3>
        <p class="muted">Put the markings side by side, point by point. Where they agree you can trust the score;
          where they disagree is the part worth listening back to.</p>
        <a class="btn btn-gold" href="#/osce/compare/${encodeURIComponent(a.station_id || '')}">Compare them →</a>
      </div>`;
      FX.viewIn(view);
    })();
    if (typeof FX !== 'undefined' && FX.scoreReveal) {
      const d = view.querySelector('#os-dial');
      if (d) { const pct = r.percent || 0;
        const col = pct >= 70 ? '#34d399' : pct >= 60 ? '#5eead4' : pct >= 50 ? '#e8a33d' : '#e05263';
        d.style.background = `conic-gradient(${col} ${pct * 3.6}deg, rgba(255,255,255,.08) 0)`; }
    }
    /* The tape is fetched as a signed link only when the report is opened —
       never as part of a list — and the page says plainly how long it has. */
    if (a.audioPath) (async () => {
      const note = view.querySelector('#os-au-note'), host = view.querySelector('#os-au');
      const left = (a.audioExpires || 0) - Date.now();
      try {
        const url = await Backend.getOsceAudioUrl(a.audioPath);
        if (!url) throw new Error('gone');
        note.innerHTML = left > 0
          ? `Kept for <strong>${Math.max(1, Math.round(left / 3600e3))} more hour${Math.round(left / 3600e3) === 1 ? '' : 's'}</strong>, then deleted automatically.
             Download it if you want to keep it — listening back is the fastest way to hear your own waffle.`
          : 'This recording is past its 24 hours and will be removed on the next visit.';
        host.innerHTML = `<div class="os-rec-box">
          <audio controls src="${esc(url)}"></audio>
          <a class="btn btn-ghost btn-sm" href="${esc(url)}" download="OSCE-${esc((a.station?.topic || 'station').replace(/[^a-z0-9]+/gi, '-'))}.webm">⬇ Download</a>
          ${a.audioSecs ? `<span class="muted tiny">${fmt(a.audioSecs)} of audio</span>` : ''}
        </div>`;
      } catch {
        note.textContent = 'The recording has passed its 24 hours and been deleted.';
        host.innerHTML = '';
      }
    })();

    wireHearVerdict(view, a);
    wireExplore(view, a);
    wireDeckMaker(view, a);
    view.querySelector('#os-print').addEventListener('click', () => printPicker(a));
    /* Rebuilt from the attempt, not from the live station — the station may
       have been edited since. What is copied is what was actually sat, and
       the `answers` on the attempt are deliberately not consulted. */
    view.querySelector('#os-copy').addEventListener('click', e => copyOut(stationAsText({
      topic: a.station?.topic, scenario: a.station?.scenario,
      station_time_min: a.station?.station_time_min, total_marks: a.station?.total_marks,
      questions: (a.questions || []).map(q => ({ id: q.id, prompt: q.prompt, marks: q.marks,
        reveal_before: q.reveal_before, images: q.images || [] }))
    }), e.currentTarget, '📄 Copy the station'));
    view.querySelector('#os-del').addEventListener('click', async () => {
      if (!confirm('Delete this OSCE result?')) return;
      try { await Backend.deleteOsceAttempt(a.id); bustAttempts(); } catch {}
      location.hash = '#/osce';
    });
  }

  /* ---------------- talking to a model about the report ----------------
     The station's own scheme and marks go with every message, so the answers
     are about this attempt rather than the topic. Only the questions that
     lost marks are sent, which keeps a whole conversation cheaper than the
     marking that produced it. */

  /* ---------------- the debrief, read aloud ----------------
     A real debrief is spoken, not handed over on paper. This reads the
     verdict and the first things to fix in the examiner's own voice, so it
     can be listened to on the way somewhere rather than read on a screen.
     Groq where it is available, the browser where it is not. */
  function wireHearVerdict(view, a) {
    const btn = view.querySelector('#os-hear');
    if (!btn) return;
    const msg = view.querySelector('#os-hear-msg');
    let playing = null;
    btn.addEventListener('click', async () => {
      if (playing) { try { playing.pause(); } catch {} playing = null; hush(); btn.textContent = '▶ Hear it'; return; }
      const r = a.result || {};
      const lines = [r.examinerComment];
      (r.improvements || []).slice(0, 3).forEach((x, i) =>
        lines.push(`${i === 0 ? 'To improve. ' : ''}${typeof x === 'string' ? x : x.action}`));
      const text = lines.filter(Boolean).join(' ');
      btn.disabled = true; btn.textContent = 'Fetching…';
      const clip = await groqVoice(text);
      btn.disabled = false;
      if (clip) {
        const au = new Audio(`data:${clip.mime};base64,${clip.data}`);
        playing = au;
        btn.textContent = '⏹ Stop';
        au.onended = () => { playing = null; btn.textContent = '▶ Hear it'; };
        au.play().catch(() => { playing = null; btn.textContent = '▶ Hear it'; });
        if (msg) msg.textContent = '';
        return;
      }
      // no Groq: the browser reads it, and says so rather than pretending
      const rep = groqReport();
      if (msg) msg.innerHTML = `<span class="muted tiny">Read by the browser's voice${
        rep.why ? ` — the real voice is unavailable: ${esc(rep.why)}` : ''}.</span>`;
      speak(text, { rate: 1 });
      btn.textContent = '⏹ Stop';
      playing = { pause() {} };
      setTimeout(() => { if (playing) { playing = null; btn.textContent = '▶ Hear it'; } }, Math.min(90000, text.length * 70));
    });
  }

  function wireExplore(view, a) {
    const msgs = view.querySelector('#os-ex-msgs');
    const form = view.querySelector('#os-ex-ask');
    const input = view.querySelector('#os-ex-input');
    const sel = view.querySelector('#os-ex-model');
    if (!form) return;
    // reuse whatever model marked the station, when it is still on the list
    const prior = modelChoices().find(m => m.model === a.model) || chosenModel();
    if (prior) sel.value = prior.key;

    const history = [];
    const md = t => (typeof AI !== 'undefined' && AI.renderMarkdown) ? AI.renderMarkdown(t) : `<p>${esc(t)}</p>`;

    form.addEventListener('submit', async e => {
      e.preventDefault();
      const q = input.value.trim(); if (!q) return;
      input.value = '';
      const choice = modelChoices().find(m => m.key === sel.value) || chosenModel();
      history.push({ role: 'user', content: q });
      msgs.insertAdjacentHTML('beforeend', `<div class="ai-msg ai-msg-user">${esc(q)}</div>`);
      const holder = document.createElement('div');
      holder.className = 'ai-msg ai-msg-ai';
      holder.innerHTML = `<div class="ai-loading sm"><span></span><span></span><span></span></div>`;
      msgs.appendChild(holder);
      msgs.scrollTop = msgs.scrollHeight;
      try {
        if (typeof Wallet !== 'undefined' && !(await Wallet.guard())) throw new Error(Wallet.blockedMessage());
        const token = await Backend.getAccessToken();
        if (!token) throw new Error('Sign in to ask about this station.');
        const res = await fetch(cfg().ai.apiBase, {
          method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
          body: JSON.stringify({
            action: 'oscechat', provider: choice.provider, model: choice.model, dailyLimit: cfg().ai.dailyLimit,
            station: a.station, messages: history,
            result: {
              total: a.result?.total, max: a.result?.max, percent: a.result?.percent, pass: a.result?.pass,
              examinerComment: a.result?.examinerComment,
              // only what lost marks — a full-mark question has nothing to discuss
              questions: (a.result?.questions || []).filter(q => (q.awarded || 0) < (q.max || 0)).map(q => ({
                awarded: q.awarded, max: q.max,
                prompt: (a.questions || []).find(x => String(x.id) === String(q.id))?.prompt || '',
                points: q.points || []
              }))
            }
          })
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.error || `Could not ask (HTTP ${res.status}).`);
        history.push({ role: 'assistant', content: data.text });
        holder.innerHTML = md(data.text);
        try { if (typeof Wallet !== 'undefined') Wallet.bust(); } catch {}
      } catch (err) {
        holder.innerHTML = `<p class="ai-error">${esc(err.message || err)}</p>`;
        history.pop();
      }
      msgs.scrollTop = msgs.scrollHeight;
    });

    /* The same web search the SBA/EMQ review has: the model names the exact
       guidelines and trials worth reading, and clicking one opens it wherever
       the user has said searches should open. */
    view.querySelector('#os-ex-web').addEventListener('click', async () => {
      const box = view.querySelector('#os-ex-web-out');
      if (box.dataset.open === '1') { box.dataset.open = '0'; box.innerHTML = ''; return; }
      box.dataset.open = '1';
      box.innerHTML = `<div class="ai-loading sm"><span></span><span></span><span></span></div>`;
      const choice = modelChoices().find(m => m.key === sel.value) || chosenModel();
      const missed = (a.result?.questions || []).flatMap(q => (q.points || [])
        .filter(p => !/cover/i.test(p.status || '')).map(p => p.point)).slice(0, 12);
      try {
        const token = await Backend.getAccessToken();
        if (!token) throw new Error('Sign in first.');
        const res = await fetch(cfg().ai.apiBase, {
          method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
          body: JSON.stringify({ action: 'searchterms', provider: choice.provider, model: choice.model,
            dailyLimit: cfg().ai.dailyLimit,
            question: { theme: a.station?.topic || '', stem: a.station?.scenario || '', options: [], answer: 0 },
            rationale: missed.join('; ') })
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
        const m = String(data.text || '').match(/\{[\s\S]*\}/);
        const terms = (JSON.parse(m ? m[0] : data.text) || {}).terms || [];
        if (!terms.length) { box.innerHTML = `<p class="muted">No specific sources suggested for this one.</p>`; return; }
        const ico = k => ({ guideline: '📘', trial: '🧪', drug: '💊' }[k] || '🔎');
        box.innerHTML = `<div class="ai-web-out" data-open="1">
          <div class="ai-web-head"><span>🌐 Worth reading — pick one to search</span></div>
          <div class="ai-web-terms">${terms.map(t => `
            <button class="ai-web-term" data-q="${esc(t.q)}">
              <span class="ai-web-ico">${ico(t.kind)}</span>
              <span class="ai-web-q">${esc(t.q)}</span>
              <span class="ai-web-why">${esc(t.why || '')}</span>
            </button>`).join('')}</div></div>`;
      } catch (e) {
        const fallback = `${a.station?.topic || ''} RCOG guideline`;
        box.innerHTML = `<p class="ai-error">${esc(e.message || e)}</p>
          <button class="btn btn-ghost btn-sm ai-web-term" data-q="${esc(fallback)}">Search Google for this topic anyway</button>`;
      }
    });
    // one delegated listener: the box is redrawn, the handler is not
    view.querySelector('#os-ex-web-out').addEventListener('click', e => {
      const b = e.target.closest('[data-q]'); if (!b) return;
      if (typeof AI !== 'undefined' && AI.openSearch) AI.openSearch(view.querySelector('#os-ex-web-out'), b.dataset.q);
      else window.open('https://www.google.com/search?q=' + encodeURIComponent(b.dataset.q), '_blank', 'noopener');
    });
  }

  /* ---------------- the printable report ---------------- */

  /* ---------------- what goes into the PDF ----------------
     The same report is wanted for different things: a blank scheme to
     practise against, the marking alone to file, or the whole debrief with
     the transcript. So the sections are chosen rather than fixed, and the
     three usual answers are one click each. */

  const PRINT_SECTIONS = [
    { id: 'cover',    label: 'Cover — the score, the pass mark, when you sat it' },
    { id: 'verdict',  label: "The examiner's verdict" },
    { id: 'perf',     label: 'Coverage, delivery and safety' },
    { id: 'scheme',   label: 'The marking scheme — every question and every point' },
    { id: 'marks',    label: 'How each point was marked (✓ ~ ✗) and the marks awarded' },
    { id: 'said',     label: 'What you said — the transcript, under each question' },
    { id: 'improve',  label: 'What to do first' },
    { id: 'good',     label: 'What was good' },
    { id: 'learning', label: 'Key learning points' },
    { id: 'teach',    label: 'The teaching — the topic, mnemonics, pitfalls and what to read' },
    /* Off unless asked for, and the label says why: this is the one
       section that must never be handed to somebody about to sit it. */
    { id: 'role',     label: "The role-player brief — examiner's copy, never give it to a candidate" }
  ];
  const PRINT_PRESETS = {
    /* "The whole report" deliberately does NOT include the role brief.
       The commonest use of the printout is handing it to the person you
       just examined, and a preset that quietly includes the answer sheet
       for the conversation would be a trap. It is one tick away. */
    full:   { label: '📋 The whole report', pick: PRINT_SECTIONS.map(s => s.id).filter(id => id !== 'role') },
    marked: { label: '✍️ Marking only', pick: ['cover', 'verdict', 'scheme', 'marks', 'improve'] },
    blank:  { label: '📄 Blank scheme to practise against', pick: ['scheme'] },
    examiner: { label: "🎭 Examiner's pack — scheme and role brief", pick: ['cover', 'scheme', 'role'] },
    spoken: { label: '🎙 Scheme with what I said', pick: ['cover', 'scheme', 'marks', 'said'] },
    /* A revision sheet with no marks on it at all — this is the one that
       goes in the folder and is read on the bus a fortnight later. */
    revise: { label: '📚 Revision sheet — the teaching, no marks', pick: ['cover', 'learning', 'teach'] }
  };
  const PRINT_KEY = 'aureum.osce.print';

  function printPicker(a) {
    document.querySelector('.os-modal')?.remove();
    let pick = null;
    try { pick = JSON.parse(localStorage.getItem(PRINT_KEY) || 'null'); } catch {}
    if (!Array.isArray(pick)) pick = PRINT_PRESETS.full.pick.slice();
    const on = id => pick.includes(id);

    const wrap = document.createElement('div');
    wrap.className = 'os-modal os-print-modal';
    wrap.innerHTML = `
      <div class="os-modal-back" data-close></div>
      <div class="os-modal-box" role="dialog" aria-modal="true" aria-label="What to print">
        <div class="os-modal-head">
          <div><p class="kicker">PRINT / SAVE AS PDF</p><h3>What should be in it?</h3></div>
          <button class="os-modal-x" data-close aria-label="Close">✕</button>
        </div>
        <div class="os-modal-body">
          <div class="os-print-presets">
            ${Object.entries(PRINT_PRESETS).map(([k, p]) =>
              `<button class="btn btn-ghost btn-sm" data-preset="${k}">${p.label}</button>`).join('')}
          </div>
          <div class="os-print-list">
            ${PRINT_SECTIONS.map(s => `
              <label class="os-print-row">
                <input type="checkbox" data-sec="${s.id}" ${on(s.id) ? 'checked' : ''}>
                <span>${esc(s.label)}</span>
              </label>`).join('')}
          </div>
          <p class="muted tiny">A blank scheme leaves out the marks and the ticks, so the same station can be sat again
            on paper. Whatever you choose is remembered for next time.</p>
        </div>
        <div class="os-modal-foot">
          <button class="btn btn-ghost btn-sm" data-close>Cancel</button>
          <button class="btn btn-gold" id="os-print-go">🖨 Print it</button>
        </div>
      </div>`;
    document.body.appendChild(wrap);
    const shut = () => { wrap.remove(); document.removeEventListener('keydown', onKey); };
    const onKey = e => { if (e.key === 'Escape') shut(); };
    document.addEventListener('keydown', onKey);
    wrap.querySelectorAll('[data-close]').forEach(b => b.addEventListener('click', shut));

    const boxes = () => [...wrap.querySelectorAll('[data-sec]')];
    wrap.querySelectorAll('[data-preset]').forEach(b => b.addEventListener('click', () => {
      const p = PRINT_PRESETS[b.dataset.preset].pick;
      boxes().forEach(x => x.checked = p.includes(x.dataset.sec));
    }));
    wrap.querySelector('#os-print-go').addEventListener('click', () => {
      const chosen = boxes().filter(x => x.checked).map(x => x.dataset.sec);
      if (!chosen.length) return;
      try { localStorage.setItem(PRINT_KEY, JSON.stringify(chosen)); } catch {}
      shut();
      printResult(a, chosen);
    });
  }

  function printResult(a, sections) {
    const want = new Set(sections && sections.length ? sections : PRINT_SECTIONS.map(s => s.id));
    const has = id => want.has(id);
    const r = a.result || {};
    const qById = {}; (a.questions || []).forEach(q => qById[String(q.id)] = q);
    const ansById = {}; (a.answers || []).forEach(x => ansById[String(x.id)] = x.transcript);
    const mark = s => /cover/i.test(s) ? '✓' : /partial/i.test(s) ? '~' : '✗';
    /* Printed from the PAGE, not from a hidden iframe. iPadOS Safari ignores
       print() called on an off-screen frame — the button appeared to do
       nothing at all, which is exactly what was reported. Every rule is
       scoped under #os-printdoc so the app's own styling is untouched, and
       @media print hides everything except the sheet. */
    const P = '#os-printdoc';
    const styles = `
@page { size: A4 portrait; margin: 16mm 15mm 14mm; }
${P}, ${P} *{box-sizing:border-box}
${P}{position:fixed;inset:0;z-index:9000;overflow:auto;background:#f1f2f6;color:#111;
  font-family:"Helvetica Neue",Arial,sans-serif;font-size:10pt;line-height:1.5;
  -webkit-print-color-adjust:exact;print-color-adjust:exact}
${P} .sheet{background:#fff;width:210mm;min-height:297mm;margin:0 auto 28px;padding:16mm 15mm;box-shadow:0 2px 18px rgba(0,0,0,.16)}
${P} h1{font-family:Georgia,serif;font-size:21pt;margin:0 0 4px;color:#111}
${P} h2{font-size:13pt;margin:0 0 8px;border-left:4px solid #0d8f7d;padding-left:9px;color:#111}
${P} h3{font-size:10.5pt;margin:12px 0 4px;color:#111}
${P} p{margin:0 0 .6em} ${P} ul,${P} ol{margin:0 0 .6em;padding-left:1.3em}
${P} .brand{font-size:7.5pt;letter-spacing:.22em;text-transform:uppercase;color:#7a5a10;margin:0 0 2px}
${P} .eyebrow{font-size:8pt;letter-spacing:.12em;text-transform:uppercase;color:#666;margin:0 0 4px}
${P} .cover{border-bottom:3px solid #0d8f7d;padding-bottom:12px;margin-bottom:16px}
${P} .scorebox{display:flex;gap:16px;margin-top:10px}
${P} .pct{flex:0 0 120px;border:2px solid ${r.pass ? '#047857' : '#c62828'};color:${r.pass ? '#047857' : '#c62828'};
  border-radius:8px;padding:10px 8px;text-align:center}
${P} .pct b{display:block;font-size:26pt;line-height:1}
${P} .pct span{display:block;font-size:8pt;text-transform:uppercase;margin-top:5px}
${P} .kv{flex:1;border-collapse:collapse;font-size:9pt}
${P} .kv th{text-align:left;padding:3px 8px 3px 0;color:#444;white-space:nowrap;width:1%}
${P} .kv td{padding:3px 12px 3px 0}
${P} .blk{margin:0 0 16px;break-inside:auto}
${P} .callout{border:1px solid #d5d5d5;border-left:3px solid #0d8f7d;padding:8px 11px;margin:0 0 .8em;background:#fafafa;break-inside:avoid}
${P} .q{border:1px solid #e0e0e0;border-radius:5px;padding:9px 11px;margin-bottom:9px;break-inside:avoid}
${P} .qh{display:flex;gap:9px;align-items:baseline;margin-bottom:5px}
${P} .qh b{flex:1}${P} .qh i{font-style:normal;font-weight:700;white-space:nowrap}
${P} .pts{list-style:none;padding:0;margin:0}
${P} .pts li{display:flex;gap:6px;margin-bottom:.18em}
${P} .pip{width:13px;text-align:center;font-weight:800;flex:0 0 13px}
${P} .cov{color:#0d8f7d}${P} .par{color:#a5750f}${P} .mis{color:#c62828}
${P} .note{display:block;font-style:italic;color:#666;font-size:.9em}
${P} .said{border-left:2px solid #ddd;padding-left:9px;margin-top:6px;font-size:.9em;color:#555}
${P} .foot{margin-top:18px;padding-top:6px;border-top:1px solid #ddd;display:flex;justify-content:space-between;font-size:7.5pt;color:#888}
${P} .blank li{color:#333}
${P} .qimgs{display:flex;flex-wrap:wrap;gap:8px;margin:6px 0 8px}
${P} .qimgs figure{margin:0;flex:1 1 240px;max-width:100%;break-inside:avoid}
${P} .qimgs img{width:100%;height:auto;border:1px solid #ddd;border-radius:3px}
${P} .qimgs figcaption{font-size:8pt;color:#666;margin-top:2px}
${P} .os-pd-bar{position:sticky;top:0;z-index:2;display:flex;gap:10px;justify-content:center;align-items:center;
  padding:10px;background:#1b1b22;color:#fff;font-size:11pt}
${P} .os-pd-bar button{font:inherit;font-size:10pt;padding:7px 16px;border-radius:8px;border:0;cursor:pointer}
${P} .os-pd-print{background:#e8b53f;color:#241d05;font-weight:700}
${P} .os-pd-close{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
${P} .os-pd-hint{color:#b9b9c4;font-size:9pt}
@media print {
  html,body{background:#fff !important;margin:0 !important;padding:0 !important;height:auto !important;overflow:visible !important}
  body > *:not(${P}){display:none !important}
  ${P}{position:static !important;overflow:visible !important;background:#fff !important}
  ${P} .os-pd-bar{display:none !important}
  ${P} .sheet{width:auto !important;min-height:0 !important;margin:0 !important;padding:0 !important;box-shadow:none !important}
}`;
    const doc = `<div class="os-pd-bar">
  <button class="os-pd-print" type="button" data-pd-print>🖨 Print / Save as PDF</button>
  <button class="os-pd-close" type="button" data-pd-close>Close</button>
  <span class="os-pd-hint">Choose “Save as PDF” as the printer to keep a copy.</span>
</div><div class="sheet">
<header class="cover">
  <p class="brand">AUREUM · Pathway to MD</p>
  <p class="eyebrow">${has('cover') ? 'OSCE station report' : 'OSCE marking scheme'}</p>
  <h1>${esc(a.station?.topic || '')}</h1>
  <p style="font-size:9pt;color:#555">${esc(a.station?.scenario || '')}</p>
  ${has('cover') ? `<div class="scorebox">
    <div class="pct"><b>${r.percent != null ? r.percent + '%' : '—'}</b><span>${r.pass ? 'Pass' : 'Below pass'}</span></div>
    <table class="kv">
      <tr><th>Marks</th><td>${r.total} / ${r.max}</td><th>Pass mark</th><td>${a.station?.pass_mark ?? '—'}</td></tr>
      <tr><th>Sat</th><td>${esc(new Date(a.created || Date.now()).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' }))}</td>
          <th>Marked by</th><td>${esc(a.model || a.provider || '')}</td></tr>
    </table>
  </div>` : `<table class="kv" style="margin-top:8px">
    <tr><th>Total marks</th><td>${r.max ?? a.station?.total_marks ?? '—'}</td>
        <th>Pass mark</th><td>${a.station?.pass_mark ?? '—'}</td></tr></table>`}
</header>
${has('verdict') && r.examinerComment ? `<section class="blk"><h2>Examiner's verdict</h2><div class="callout"><p>${esc(r.examinerComment)}</p></div></section>` : ''}
${has('perf') && r.structure ? `<section class="blk"><h2>How you performed</h2>
  ${['coverage', 'fluency', 'safety'].filter(k => r.structure[k]).map(k =>
    `<p><strong>${k === 'coverage' ? 'Coverage' : k === 'fluency' ? 'Delivery' : 'Safety'}.</strong> ${esc(r.structure[k])}</p>`).join('')}</section>` : ''}
${has('scheme') || has('marks') || has('said') ? `<section class="blk">
  <h2>${has('marks') ? 'Marked against the scheme' : 'The marking scheme'}</h2>
  ${(r.questions || []).map((qr, i) => {
    const q = questionFor(a.questions, qr.id, i);
    /* Without the marking chosen this is a blank scheme: the points are
       listed with an empty box instead of a tick, so the same station can be
       sat again on paper and marked by hand. */
    const pts = has('scheme')
      ? `<ul class="pts${has('marks') ? '' : ' blank'}">${(qr.points || []).map(p => `<li><span class="pip ${
          has('marks') ? (/cover/i.test(p.status) ? 'cov' : /partial/i.test(p.status) ? 'par' : 'mis') : ''}">${
          has('marks') ? mark(p.status) : '☐'}</span>
        <span>${p.heading ? `<b>${esc(p.heading)}.</b> ` : ''}${esc(p.point)}${
          has('marks') && p.note ? `<span class="note">${esc(p.note)}</span>` : ''}</span></li>`).join('')}</ul>`
      : '';
    // the picture is part of the question — a CTG station without its trace
    // is not the station
    const ims = has('scheme') ? imagesOf(q) : [];
    return `<div class="q">
      <div class="qh"><b>Q${i + 1}. ${esc(q.prompt || '')}</b><i>${has('marks') ? `${qr.awarded}/${qr.max}` : `${qr.max ?? q.marks ?? ''}`}</i></div>
      ${ims.length ? `<div class="qimgs">${ims.map(im =>
        `<figure><img src="${esc(im.url)}" alt="">${im.caption ? `<figcaption>${esc(im.caption)}</figcaption>` : ''}</figure>`).join('')}</div>` : ''}
      ${pts}
      ${has('marks') && qr.comment ? `<p style="margin-top:6px">${esc(qr.comment)}</p>` : ''}
      ${has('said') ? `<div class="said"><strong>You said:</strong> ${esc(ansById[String(qr.id)] || '(nothing captured)')}</div>` : ''}
    </div>`;
  }).join('')}</section>` : ''}
${has('improve') && (r.improvements || []).length ? `<section class="blk"><h2>What to do first</h2><ol>${r.improvements.map(x =>
  `<li>${esc(typeof x === 'string' ? x : x.action)}${x.marks ? ` <strong>(+${x.marks} marks)</strong>` : ''}</li>`).join('')}</ol></section>` : ''}
${has('good') && (r.strengths || []).length ? `<section class="blk"><h2>What was good</h2><ul>${r.strengths.map(x => `<li>${esc(x)}</li>`).join('')}</ul></section>` : ''}
${has('learning') && (r.keyLearning || []).length ? `<section class="blk"><h2>Key learning points</h2><ol>${r.keyLearning.map(x => `<li>${esc(x)}</li>`).join('')}</ol></section>` : ''}
${has('role') && hasRole(a.station) ? `<section class="blk"><h2>Role player — examiner's copy</h2>
  <p class="callout"><strong>Do not give this page to a candidate.</strong> It is the answer sheet for the
    conversation: read out, there is nothing left to elicit.</p>
  <pre style="white-space:pre-wrap;font-family:inherit;font-size:9.5pt;margin:0">${esc(roleText(a.station))}</pre></section>` : ''}
${has('teach') && String(r.summary || '').trim() ? `<section class="blk"><h2>The topic, properly</h2>${
  String(r.summary).split(/\n{2,}/).filter(p => p.trim()).map(p => `<p>${esc(p.trim())}</p>`).join('')}</section>` : ''}
${has('teach') && (r.mnemonics || []).length ? `<section class="blk"><h2>Ways to remember it</h2><ul>${
  r.mnemonics.map(m => typeof m === 'string' ? `<li>${esc(m)}</li>`
    : `<li><strong>${esc(m.aid || '')}</strong>${m.expands ? ` — ${esc(m.expands)}` : ''}${
        m.use ? `<span class="note">${esc(m.use)}</span>` : ''}</li>`).join('')}</ul></section>` : ''}
${has('teach') && (r.pitfalls || []).length ? `<section class="blk"><h2>What loses marks here</h2><ul>${
  r.pitfalls.map(p => typeof p === 'string' ? `<li>${esc(p)}</li>`
    : `<li><span class="mis">✗</span> ${esc(p.trap || '')}${
        p.instead ? `<span class="note"><span class="cov">✓</span> ${esc(p.instead)}</span>` : ''}</li>`).join('')}</ul></section>` : ''}
${has('teach') && (r.reading || []).length ? `<section class="blk"><h2>Where to settle it</h2><ul>${
  r.reading.map(x => typeof x === 'string' ? `<li>${esc(x)}</li>`
    : `<li><strong>${esc(x.source || '')}</strong>${x.why ? `<span class="note">${esc(x.why)}</span>` : ''}</li>`).join('')}</ul></section>` : ''}
<footer class="foot"><span>${esc(a.station?.topic || '')} — OSCE</span><span>AUREUM · printed ${esc(new Date().toLocaleDateString('en-GB', { dateStyle: 'medium' }))}</span></footer>
</div>`;

    openPrintSheet(styles, doc);
  }



  /* ---------------- mounting a printable sheet ----------------
     Shared by the station report and the study document, because both hit
     the same wall: iPadOS Safari ignores print() on a hidden iframe, so
     the sheet has to be part of the page and the page itself printed. */
  /* Clearing the print lock. Exported and called by the router, so a lock
     left behind by any path at all is gone by the next navigation. It also
     wipes the old inline style, for a browser that still has one set from
     a version before this. */
  function releaseScroll() {
    try {
      document.documentElement.classList.remove('is-printlock');
      if (document.documentElement.style.overflow === 'hidden') document.documentElement.style.overflow = '';
      if (document.body.style.overflow === 'hidden') document.body.style.overflow = '';
    } catch {}
  }

  /* THE RULES THAT MAKE THE PRINTER SEE ONLY THE SHEET.

     These used to live inside ONE caller's style string — the OSCE report —
     and every print written afterwards quietly lacked them. The result was
     a PDF of the whole running application: the nav bar, the live marking
     UI, "Tap a point to cycle it", the placeholder text in empty inputs,
     and Safari's own URL footer. Which is what a print without a print
     stylesheet looks like, and there was no print stylesheet.

     So they belong HERE, prepended to whatever the caller asked for. A
     caller can add to them; it cannot forget them. */
  const PRINT_FRAME = `
@media print {
  html, body { background:#fff !important; color:#111 !important;
    margin:0 !important; padding:0 !important; height:auto !important; overflow:visible !important; }
  /* the sheet IS the document; nothing else on the page is */
  body > *:not(#os-printdoc) { display:none !important; }
  #os-printdoc { position:static !important; overflow:visible !important;
    background:#fff !important; inset:auto !important; }
  #os-printdoc .os-pd-bar { display:none !important; }
  #os-printdoc .sheet, #os-printdoc [class$="-print"] { width:auto !important; min-height:0 !important;
    margin:0 !important; padding:0 !important; box-shadow:none !important; }
  /* ink on paper: never a dark theme, never a shadow, never a screen-only flourish */
  #os-printdoc * { box-shadow:none !important; text-shadow:none !important; }
  a[href]::after { content:"" !important; }
}`;

  /* ================= the scheme, on paper =================

     WHY A SCHEME NEEDS ITS OWN PRINT.

     Everything printable in AUREUM until now was an ATTEMPT — the report
     after you sat something. But most revision is done before that: two
     people at a table with a station between them, one asking and one
     answering, neither of whom wants to hold a phone. And a station that
     exists only on a screen cannot be taken into a study group, marked up
     with a pen, or read on a ward round.

     So this prints the station as an examiner's paper: the scenario, the
     reveals, every question with its marks, every marking point with a
     box to tick, and the role-player brief on a page of its own at the
     back — because that page must not be face-up while somebody is being
     examined from the front one.

     No score, no verdict, no candidate. It is a blank instrument. */
  /**
   * The marking scheme, printable. Takes one station or a list of them —
   * a list prints as one document with a page break between stations,
   * which is what the ★ revision pack asks for and what a printer does
   * best. One station is the same code path with a list of one, so there
   * is no second layout to keep in step with this one.
   */
  function printScheme(input) {
    const many = Array.isArray(input) ? input.filter(Boolean) : [input].filter(Boolean);
    if (!many.length) return;
    const st = many[0];
    const P = '#os-printdoc';
    const styles = `
@page { size: A4 portrait; margin: 15mm 14mm 13mm; }
${P}, ${P} *{box-sizing:border-box}
${P}{position:fixed;inset:0;z-index:9000;overflow:auto;background:#f1f2f6;color:#111;
  font-family:"Helvetica Neue",Arial,sans-serif;font-size:10pt;line-height:1.5;
  -webkit-print-color-adjust:exact;print-color-adjust:exact}
${P} .sheet{background:#fff;width:210mm;min-height:297mm;margin:0 auto 28px;padding:15mm 14mm;box-shadow:0 2px 18px rgba(0,0,0,.16)}
${P} .brand{font-size:7.5pt;letter-spacing:.22em;text-transform:uppercase;color:#7a5a10;margin:0 0 2px}
${P} h1{font-family:Georgia,serif;font-size:20pt;margin:0 0 6px;color:#111}
${P} .facts{font-size:8.5pt;color:#555;margin:0 0 14px;padding-bottom:12px;border-bottom:3px solid #0d8f7d}
${P} .scen{background:#f6f7f9;border-left:4px solid #0d8f7d;padding:10px 12px;margin:0 0 16px}
${P} .scen b{display:block;font-size:7.5pt;letter-spacing:.14em;text-transform:uppercase;color:#666;margin-bottom:4px}
${P} .q{margin:0 0 14px;page-break-inside:avoid;break-inside:avoid}
${P} .qh{display:flex;gap:9px;align-items:baseline;border-bottom:1px solid #ddd;padding-bottom:5px;margin-bottom:7px}
${P} .qn{flex:0 0 auto;font-weight:700;color:#0d8f7d;font-size:9pt}
${P} .qt{flex:1 1 auto;font-weight:600;font-size:10.5pt}
${P} .qm{flex:0 0 auto;font-size:8.5pt;color:#555;white-space:nowrap}
${P} .rev{font-size:9pt;background:#fff8e6;border:1px solid #e8d9a8;padding:6px 9px;margin:0 0 7px}
${P} .rev b{color:#7a5a10}
${P} ul{list-style:none;margin:0;padding:0}
${P} li{position:relative;padding:2px 0 2px 22px;font-size:9.5pt;page-break-inside:avoid}
${P} li::before{content:'';position:absolute;left:2px;top:4px;width:11px;height:11px;border:1.2px solid #999;border-radius:2px}
${P} li.head{padding-left:0;margin:9px 0 3px;font-size:8pt;letter-spacing:.1em;text-transform:uppercase;color:#0d8f7d;font-weight:700}
${P} li.head::before{display:none}
${P} .role{page-break-before:always;break-before:page}
${P} .sheet.brk{page-break-before:always;break-before:page}
${P} .role h2{font-size:13pt;margin:0 0 4px;border-left:4px solid #c96442;padding-left:9px}
${P} .role .warn{font-size:8.5pt;color:#a33;border:1px dashed #d9a9a9;padding:7px 9px;margin:0 0 12px}
${P} .role h3{font-size:9.5pt;margin:11px 0 3px}
${P} .foot{margin-top:16px;padding-top:8px;border-top:1px solid #ddd;font-size:7.5pt;color:#777;display:flex;justify-content:space-between}
@media print { ${P} .sheet{box-shadow:none;margin:0;width:auto;min-height:0;padding:0} }`;

    const pts = q => (q.marking_points || []).map(p => isHeading(p)
      ? `<li class="head">${esc(headText(p) || 'Section')}</li>`
      : `<li>${esc(p)}</li>`).join('');

    /* One station's pages. `nth` is only used to break the page before
       every station after the first — a booklet whose second station
       starts halfway down the first one's last page is not a booklet. */
    const sheetFor = (s, nth) => {
      const qs = qsOf(s);
      const role = hasRole(s) ? `
        <section class="role">
          <h2>Role player — ${esc(roleLabel(s))}</h2>
          <p class="warn">Keep this page turned over while the station is being sat. It carries what the character
            is holding back, and a candidate who sees it has been given the station.</p>
          ${roleHtml(s, 'brief')}
        </section>` : '';
      return `<div class="sheet${nth ? ' brk' : ''}">
        <p class="brand">AUREUM · Pathway to MD${many.length > 1
          ? ` · station ${nth + 1} of ${many.length}` : ''}</p>
        <h1>${esc(s.topic || s.id)}</h1>
        <p class="facts">${minsOf(s)} minutes · ${qs.length} question${qs.length === 1 ? '' : 's'} ·
          ${marksOf(s)} marks · ${ptCount(s)} marking points · ${passOf(s)} to pass (${s.pass_mark_percent || 70}%)${
          s.created_by_name ? ' · written by ' + esc(s.created_by_name) : ''}</p>
        ${s.scenario ? `<div class="scen"><b>The scenario — read this to the candidate</b>${esc(s.scenario)}</div>` : ''}
        ${qs.map((q, i) => `
          <div class="q">
            <div class="qh"><span class="qn">Q${i + 1}</span><span class="qt">${esc(q.prompt || '')}</span>
              <span class="qm">${q.marks} marks</span></div>
            ${q.reveal_before ? `<p class="rev"><b>Reveal first:</b> ${esc(q.reveal_before)}</p>` : ''}
            <ul>${pts(q)}</ul>
          </div>`).join('')}
        <div class="foot"><span>${esc(s.topic || s.id)}</span><span>Marking scheme · not a completed marking</span></div>
        ${role}
      </div>`;
    };

    const cover = many.length > 1 ? `<div class="sheet">
      <p class="brand">AUREUM · Pathway to MD</p>
      <h1>Revision pack — ${many.length} starred stations</h1>
      <p class="facts">${many.reduce((n, s) => n + qsOf(s).length, 0)} questions ·
        ${many.reduce((n, s) => n + ptCount(s), 0)} marking points ·
        ${many.reduce((n, s) => n + marksOf(s), 0)} marks · about ${hours(many.length * 15)} of examining</p>
      <div class="scen"><b>The stations, in the order you starred them</b>${
        many.map((s, i) => `${i + 1}. ${esc(s.topic || s.id)}`).join('\n')}</div>
      <div class="foot"><span>Marking schemes</span><span>not a completed marking</span></div>
    </div>` : '';

    const body = cover + many.map((s, i) => sheetFor(s, cover ? i + 1 : i)).join('');
    openPrintSheet(styles, body);
  }

  function openPrintSheet(styles, bodyHtml) {
    releaseScroll();                     // never stack two locks
    document.getElementById('os-printdoc')?.remove();
    document.getElementById('os-printdoc-css')?.remove();
    const css = document.createElement('style');
    css.id = 'os-printdoc-css';
    css.textContent = styles + '\n' + PRINT_FRAME;
    document.head.appendChild(css);

    const host = document.createElement('div');
    host.id = 'os-printdoc';
    host.innerHTML = bodyHtml;

    /* THE SECOND HALF OF THE FREEZE, AND THE ONE v82 MISSED.

       v82 made the scroll lock releasable. It did not ask what the sheet
       ITSELF looks like on screen, and that turned out to be the actual
       fault: the two callers inside this file style `#os-printdoc` as a
       fixed, scrollable overlay, but marksheet.js, cases.js and
       discussions.js scope their CSS under their own class and never
       position the host at all. For those three the sheet was a plain
       block in the document flow, taller than the screen, while <html>
       and <body> were overflow:hidden — so the page could not scroll, the
       sheet could not scroll, and on iOS, where the sheet deliberately
       stays up after print() returns, there was no Close button either
       because none of the three emits one.

       That is a frozen page, exactly as reported, and it was reachable
       from the mark-by-hand PDF — which is the print most likely to be
       used right after a round.

       The layout now lives in styles.css under #os-printdoc, and the
       close bar is added here when the caller did not provide one. Same
       rule as PRINT_FRAME: a caller may add to the frame, it cannot
       forget it. */
    if (!host.querySelector('[data-pd-close]')) {
      const bar = document.createElement('div');
      bar.className = 'os-pd-bar';
      bar.innerHTML = `<button type="button" data-pd-print>🖨 Print / Save as PDF</button>
        <button type="button" data-pd-close>✕ Close</button>`;
      host.prepend(bar);
    }
    document.body.appendChild(host);

    /* THE FREEZE.

       This used to lock scrolling with an inline `documentElement.style
       .overflow = 'hidden'` and restore it in shut(). Three ways that left
       the whole site unscrollable, permanently:

         1. On iOS shut() is reachable only through the Close button — there
            is no Escape key — so navigating away instead of closing left
            the lock on for ever. Changing tab does not clear it, because
            routing replaces #view and never touches <html>.
         2. Printing twice captured 'hidden' as the value to restore, so
            even pressing Close put it back to hidden.
         3. Anything that threw between setting and restoring kept it.

       So the lock is now a CLASS, released by three independent things:
       shut(), leaving the page, and the router on every single navigation.
       A lock that can only be released by the code that set it is a lock
       that will one day not be released. */
    const shut = () => {
      host.remove(); css.remove();
      document.removeEventListener('keydown', onKey);
      window.removeEventListener('hashchange', shut);
      releaseScroll();
    };
    const onKey = e => { if (e.key === 'Escape') shut(); };
    document.documentElement.classList.add('is-printlock');
    document.addEventListener('keydown', onKey);
    window.addEventListener('hashchange', shut);
    host.querySelector('[data-pd-close]')?.addEventListener('click', shut);
    host.querySelector('[data-pd-print]')?.addEventListener('click', () => { try { window.print(); } catch {} });

    /* On a desktop browser print() blocks until the dialog is dismissed, so
       the sheet clears the moment it returns and the app is back as it was.
       On iOS it does NOT: "Save as PDF" happens in a share sheet raised
       after print() has returned, and a page that tore itself down
       underneath would take the document with it. There it stays, with a
       Close button, until the reader is finished. */
    const iOS = /iPad|iPhone|iPod/.test(navigator.userAgent)
      || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    const go = () => { try { window.print(); } catch {} if (!iOS) setTimeout(shut, 250); };
    const imgs = [...host.querySelectorAll('img')];
    if (!imgs.length) { setTimeout(go, 60); return; }
    // a CTG station without its trace is not the station — wait for the pictures
    let left = imgs.length;
    const tick = () => { if (--left <= 0) setTimeout(go, 60); };
    imgs.forEach(im => im.complete ? tick() : (im.onload = im.onerror = tick));
    setTimeout(() => { if (left > 0) { left = 0; go(); } }, 4000);
  }

  /* ---------------- handing a circuit station over from elsewhere ----------------

     A station sat through OSCE in AI is sat OUTSIDE the runner: the clock,
     the tape and the marking all happen on another screen. The circuit
     still has to be told, or it sits on that station for ever with no way
     to reach station two — which is exactly what happened.

     So this is the same hand-over the Next button does, reduced to its
     two facts: record what became of this station, and move the session
     on. It returns where to go next so the caller does not have to know
     how a circuit is addressed. */
  async function circuitNext(sid, stationId, attempt) {
    const s = await loadSession(sid);
    if (!s || !s.circuit) return null;
    const i = s.stations.indexOf(stationId);
    if (i >= 0 && !loadMarks(sid)[stationId]) {
      saveMark(sid, stationId, attempt
        ? { status: 'done', attemptId: attempt.id, percent: attempt.result?.percent ?? null,
            pass: !!attempt.result?.pass, partial: attempt.result?.partial || null,
            elsewhere: true, at: Date.now() }
        /* Sat, but nothing came back to score. Not `skipped` — that means
           there was nothing to mark; this one was marked somewhere else
           and the verdict has not been brought home yet. */
        : { status: 'elsewhere', message: 'Sat against a chat model — import its marking to score it.', at: Date.now() });
    }
    /* WHERE WE ARE IS THE STATION, NOT THE SESSION'S POINTER.

       Taking `s.at` as the position let the two disagree — a station handed
       over from further along the circuit than the runner had reached
       advanced `at` past the last index, and the runner then had no station
       to draw and bounced to the bank. The station being handed over is the
       position; the pointer only stands in when the station is not in this
       circuit at all. */
    const here = i >= 0 ? i : s.at;
    if (here + 1 >= s.stations.length) {
      s.at = here; s.phase = 'circuit';
      await saveSession(s);
      return { last: true, hash: '#/osce/circuit/' + sid };
    }
    s.at = here + 1; s.qi = 0; s.elapsed = 0; s.phase = 'brief';
    await saveSession(s);
    return { last: false, hash: '#/osce/run/' + sid, at: s.at, of: s.stations.length };
  }

  /* ---------------- shell ---------------- */

  function shell(active, inner) {
    const tab = (id, href, label) =>
      `<a class="lib-tab ${active === id ? 'active' : ''}" href="${href}">${label}</a>`;
    return `<section class="page">
      <div class="lib-subnav" data-animate>
        ${tab('bank', '#/osce', 'Station bank')}
        ${tab('sim', '#/osce/sim', 'Exam simulator')}
        ${/* A switched-off feature does not advertise itself. The route
              still works and still explains itself to anybody holding a
              link — see features.js — but a tab nobody can use is a tab
              in the way. The developer reaches it from the switch itself,
              in Developer → Settings. */
          (typeof Features === 'undefined' || Features.on('realStation'))
            ? tab('real', '#/osce/real', 'Real station') : ''}
        ${tab('mine', '#/osce/mine', 'My attempts')}
        ${/* The count is on the tab because a deck you have to remember to
              open is a deck nobody opens. It reads from localStorage, so it
              costs nothing and cannot delay the page. */
          (() => {
            const n = (typeof Recall !== 'undefined') ? Recall.dueNow() : 0;
            return tab('recall', '#/osce/recall', 'Recall' + (n ? ` <span class="lib-tab-n">${n}</span>` : ''));
          })()}
        ${tab('progress', '#/osce/progress', 'Progress')}
        ${tab('cards', '#/osce/cards', 'Study documents')}
        ${tab('edit', '#/osce/edit', 'Station editor')}
      </div>${inner}</section>`;
  }

  /* ================= the circuit results (#/osce/circuit/:sid) =================
     Nine stations' worth of marking lands here as it finishes. The page
     redraws itself whenever the queue moves, so the candidate watches the
     results arrive instead of staring at a spinner — and a station that
     failed offers to go again rather than simply being absent. */

  async function renderCircuit(view, sid, user) {
    const s = await loadSession(sid);
    if (!s) {
      view.innerHTML = shell('sim', `<p class="muted">That circuit is no longer stored. <a class="link" href="#/osce/mine">Your attempts</a></p>`);
      FX.viewIn(view); return;
    }
    const cards = await stations().catch(() => []);
    const byId = {}; cards.forEach(c => byId[c.id] = c);
    const modules = await OsceBlueprint.get().catch(() => []);

    let off = null;
    const draw = async () => {
      const cur = await loadSession(sid) || s;
      const marks = loadMarks(sid);
      const rows = cur.stations.map((id, i) => ({ i, id, st: byId[id] || { id }, m: marks[id] || { status: 'none' } }));
      const done = rows.filter(r => r.m.status === 'done');
      const failed = rows.filter(r => r.m.status === 'error');
      const waiting = rows.filter(r => r.m.status === 'queued');
      /* A part-marked station must not drag the round's mean down — its
         percentage is out of a different denominator entirely. */
      const scored = done.filter(r => r.m.percent != null && !r.m.partial);
      const parts = done.filter(r => r.m.partial);
      const mean = scored.length ? Math.round(scored.reduce((n, r) => n + r.m.percent, 0) / scored.length) : null;
      const passed = done.filter(r => r.m.pass).length;

      const early = cur.endedEarly || null;
      const notSat = rows.filter(r => r.m.status === 'notSat');

      view.innerHTML = shell('sim', `
        <header data-animate>
          <p class="kicker">${early ? 'ROUND ENDED EARLY' : 'CIRCUIT COMPLETE'}</p>
          <h1 class="page-title">${early
            ? `${early.sat} of ${early.of} stations`
            : `${cur.stations.length} stations`}</h1>
          <p class="muted">${waiting.length
            ? `Marking is still running — <strong>${waiting.length}</strong> to go. You can leave this page; it carries on.`
            : early
              ? `You ended the round after ${early.sat}. Those ${early.sat} are marked in full below; the other ${
                  notSat.length} were never sat and are not counted against you.`
              : 'Every station has been through the marker.'}</p>
        </header>

        ${scored.length ? `<div class="card os-circ-sum" data-animate>
          <div class="os-circ-figs">
            <div class="os-circ-fig"><b>${mean}%</b><span>mean across the ${scored.length} station${scored.length === 1 ? '' : 's'} that were marked in full</span></div>
            <div class="os-circ-fig"><b>${passed}/${scored.length}</b><span>at or above the pass mark</span></div>
          </div>
          ${Charts && scored.length > 1 ? `<div class="os-circ-bars">${scored.map(r => `
            <div class="os-circ-bar" title="${esc(r.st.topic || '')}">
              <i style="height:${Math.max(4, r.m.percent)}%;background:${r.m.pass ? 'var(--good,#34d399)' : 'var(--bad,#f87171)'}"></i>
              <span>${r.i + 1}</span>
            </div>`).join('')}</div>` : ''}
        </div>` : ''}

        <div class="card" data-animate>
          <h3 class="card-title">Station by station</h3>
          <p class="muted tiny">The topic and the module are shown now the circuit is over — that is the point at which
            knowing them helps rather than hinders.</p>
          <div class="os-circ-list">
            ${rows.map(r => {
              const tag = OsceBlueprint.tagOf(r.st);
              const where = tag ? `${OsceBlueprint.moduleName(modules, tag.module)} · ${OsceBlueprint.topicName(modules, tag.module, tag.topic)}` : 'not on the blueprint';
              const badge = r.m.status === 'done'
                ? (r.m.partial
                  ? `<span class="os-circ-pct is-part" title="Only ${r.m.partial.marked} of ${r.m.partial.of} questions were marked">part-marked</span>`
                  : `<span class="os-circ-pct ${r.m.pass ? 'is-pass' : 'is-fail'}">${r.m.percent != null ? r.m.percent + '%' : 'marked'}</span>`)
                : r.m.status === 'queued' ? `<span class="os-circ-wait"><i></i> marking…</span>`
                : r.m.status === 'error' ? `<span class="os-circ-err">could not be marked</span>`
                : r.m.status === 'elsewhere' ? `<span class="os-circ-else">sat against a chat model — not scored</span>`
                : r.m.status === 'notSat' ? `<span class="muted tiny">not sat — still fresh</span>`
                : `<span class="muted tiny">not marked</span>`;
              return `<div class="os-circ-row" data-st="${esc(r.id)}">
                <span class="os-circ-n">${r.i + 1}</span>
                <div class="os-circ-mid">
                  <strong>${esc(r.st.topic || r.id)}</strong>
                  <span class="tiny muted">${esc(where)}</span>
                  ${r.m.status === 'error' ? `<span class="tiny bad">${esc(r.m.message || '')}</span>` : ''}
                  ${r.m.status === 'skipped' ? `<span class="tiny muted">${esc(r.m.message || '')}</span>` : ''}
                  <span class="tiny muted os-circ-step" hidden></span>
                </div>
                ${badge}
                <div class="os-circ-acts">
                  ${r.m.status === 'done' ? `<a class="btn btn-ghost btn-sm" href="#/osce/result/${esc(r.m.attemptId)}">Open the report</a>` : ''}
                  ${r.m.status === 'error' ? `<button class="btn btn-gold btn-sm" data-retry="${esc(r.id)}">↻ Send it again</button>` : ''}
                </div>
              </div>`;
            }).join('')}
          </div>
          ${failed.length ? `<p class="muted tiny" style="margin-top:12px">A recording is kept on the server for 24 hours,
            so a station that failed can be sent again from here for the rest of the day. After that it is marked from
            the transcript instead.</p>` : ''}
        </div>

        <div class="os-run-foot" data-animate>
          <a class="btn btn-ghost" href="#/osce/progress">See it on the blueprint →</a>
          <a class="btn btn-ghost" href="#/osce/sim">Sit another circuit</a>
        </div>`);
      FX.viewIn(view);

      view.querySelectorAll('[data-retry]').forEach(b => b.addEventListener('click', async () => {
        const id = b.dataset.retry;
        b.disabled = true; b.textContent = 'Sending…';
        const step = b.closest('.os-circ-row').querySelector('.os-circ-step');
        step.hidden = false;
        try {
          await retryMark(sid, id, t => { step.textContent = t; });
        } catch (e) {
          step.textContent = String(e.message || e);
          b.disabled = false; b.textContent = '↻ Send it again';
        }
      }));
    };
    off = onMarkChange(() => { if (location.hash.includes('/osce/circuit/')) draw(); });
    await draw();
  }

  /** The button on a report that turns its misses into a deck. */
  function wireDeckMaker(view, a) {
    const btn = view.querySelector('#os-makedeck');
    const msg = view.querySelector('#os-deck-msg');
    if (!btn) return;
    const qs = allPoints(a);
    const n = qs.reduce((t, q) => t + q.points.length, 0);
    const missed = qs.reduce((t, q) => t + q.points.filter(p => p.status !== 'covered').length, 0);
    if (!n) {
      btn.disabled = true;
      msg.innerHTML = '<span class="muted">This attempt has no marked scheme to build from.</span>';
      return;
    }
    msg.innerHTML = `<span class="muted">${n} marking points, ${missed} of them new to you.</span>`;
    // a document already written for this attempt is offered rather than remade
    (async () => {
      try {
        const have = (await decks() || []).find(d => d.attemptId === a.id && d.doc);
        if (have) msg.innerHTML = `<a class="link" href="#/osce/cards/${esc(have.id)}">A study document already exists for this attempt →</a> Writing another replaces it.`;
      } catch {}
    })();
    btn.addEventListener('click', async () => {
      btn.disabled = true;
      msg.innerHTML = '<span class="muted">Working…</span>';
      try {
        const d = await makeDoc(a, t => { msg.innerHTML = `<span class="muted">${esc(t)}</span>`; });
        msg.innerHTML = `<span class="good">✓ ${(d.doc.sections || []).length} sections written.</span>
          <a class="link" href="#/osce/cards/${esc(d.id)}">Open the document →</a>`;
      } catch (e) {
        msg.innerHTML = `<span class="bad">${esc(e.message || e)}</span>`;
      }
      btn.disabled = false;
    });
  }

  /* Every marking point of the attempt, with what the marking said about
     it. This is the spine of the document: the model is told the verdict
     and writes around it, and the page marks each point in place. */
  function allPoints(a) {
    return (a.result?.questions || []).map(qr => {
      const q = (a.questions || []).find(x => String(x.id) === String(qr.id)) || {};
      return { id: qr.id, prompt: q.prompt || '', marks: q.marks || qr.max || 0,
        points: (qr.points || []).map(p => ({ point: p.point, status: /cover/i.test(p.status) ? 'covered'
          : /partial/i.test(p.status) ? 'partly said' : 'missed' })) };
    }).filter(x => x.points.length);
  }

  async function makeDoc(a, onStep = () => {}) {
    const qs = allPoints(a);
    if (!qs.length) throw new Error('This attempt has no marked scheme, so there is nothing to build from.');
    if (typeof Wallet !== 'undefined' && !(await Wallet.guard())) throw new Error(Wallet.blockedMessage());
    const token = await Backend.getAccessToken();
    if (!token) throw new Error('Sign in to make a study document.');
    const choice = chosenModel();
    const n = qs.reduce((t, q) => t + q.points.length, 0);
    onStep(`Writing the page from ${n} marking points across ${qs.length} questions…`);
    const res = await fetch(cfg().ai.apiBase, {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
      body: JSON.stringify({ action: 'oscedoc', provider: choice.provider, model: choice.model,
        dailyLimit: cfg().ai.dailyLimit,
        station: { topic: a.station?.topic, scenario: a.station?.scenario }, questions: qs })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `The document could not be written (HTTP ${res.status}).`);

    /* The said/not-said marking is decided HERE, from the attempt, never by
       the model — it is a fact about what happened and must not be open to
       a paraphrase. The model only says which section a point belongs to. */
    const verdict = new Map();
    qs.forEach(q => q.points.forEach(p => verdict.set(norm(p.point), p.status)));
    const seen = new Set();
    const doc = data.doc;
    doc.sections = (doc.sections || []).map(sec => ({
      ...sec,
      points: (sec.points || []).map(txt => {
        const k = norm(txt);
        seen.add(k);
        return { point: txt, status: verdict.get(k) || matchStatus(txt, verdict) };
      })
    }));
    // anything the model failed to place still belongs in the document
    const orphans = [];
    qs.forEach(q => q.points.forEach(p => { if (!seen.has(norm(p.point))) orphans.push(p); }));
    if (orphans.length) doc.sections.push({ heading: 'Also on the scheme', body: '', sayThis: '', points: orphans });

    const stats = { total: 0, covered: 0, partial: 0, missed: 0 };
    doc.sections.forEach(sec => sec.points.forEach(p => {
      stats.total++;
      if (p.status === 'covered') stats.covered++;
      else if (p.status === 'partly said') stats.partial++;
      else stats.missed++;
    }));

    const rec = {
      id: 'od-' + a.id,                       // one document per attempt, by construction
      attemptId: a.id, stationId: a.station_id,
      title: doc.title || a.station?.topic || 'OSCE station',
      station: a.station?.topic || '', scenario: a.station?.scenario || '',
      bp: a.bp || null, percent: a.result?.percent ?? null,
      doc, stats, created: Date.now(), model: data.model || choice.model
    };
    await Backend.saveOsceDeck(rec); bustDecks();
    try { if (typeof Wallet !== 'undefined') Wallet.bust(); } catch {}
    return rec;
  }

  const norm = t => String(t || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
  /* A model that reworded a point slightly should not lose its verdict.
     Best token overlap, and only when it is convincing. */
  function matchStatus(txt, verdict) {
    const want = new Set(norm(txt).split(' ').filter(w => w.length > 3));
    if (!want.size) return 'missed';
    let best = null, bestScore = 0;
    for (const [k, v] of verdict) {
      const have = k.split(' ').filter(w => w.length > 3);
      if (!have.length) continue;
      const hit = have.filter(w => want.has(w)).length / have.length;
      if (hit > bestScore) { bestScore = hit; best = v; }
    }
    return bestScore >= 0.6 ? best : 'missed';
  }

  /* ================= the study documents (#/osce/cards) =================

     One page per attempt. It reads as a case — recognise it, work through
     it in the order it happens, know the traps — with the candidate's own
     performance marked inside it rather than listed separately. That is
     the difference from a deck of cards: the gaps are shown IN PLACE, so
     you see what you missed in the context you will need it.  */

  const DOC_MARK = {
    'covered':    { ico: '✓', cls: 'cov', label: 'you said this' },
    'partly said':{ ico: '~', cls: 'par', label: 'you half-said this' },
    'missed':     { ico: '✗', cls: 'mis', label: 'you did not say this' }
  };

  async function renderDecks(view, deckId, user) {
    view.innerHTML = shell('cards', `<div id="os-body"><p class="muted">Reading your documents…</p></div>`);
    FX.viewIn(view);
    const host = view.querySelector('#os-body');
    let docs = [];
    try { docs = (await decks()) || []; } catch {}
    docs = docs.filter(d => d.doc);              // decks from the old card format are ignored

    if (deckId) {
      const d = docs.find(x => x.id === deckId);
      if (!d) { location.hash = '#/osce/cards'; return; }
      return paintDoc(view, host, d);
    }

    if (!docs.length) {
      host.innerHTML = `<div class="card"><h3 class="card-title">No study documents yet</h3>
        <p class="muted">At the bottom of any marked station there is a button that writes one: the whole case on a
          single page, in the order it happens, with the marking scheme woven through it and your own answer marked
          against every point. It is the page to read the night before.</p>
        <a class="btn btn-ghost" href="#/osce/mine">Your marked stations</a></div>`;
      return;
    }
    const modules = await OsceBlueprint.get().catch(() => []);
    host.innerHTML = `
      <header data-animate>
        <p class="kicker">OSCE STUDY DOCUMENTS</p>
        <h1 class="page-title">${docs.length} document${docs.length === 1 ? '' : 's'}</h1>
        <p class="muted">One per station you have sat. Each is the whole case, with what you said and what you did
          not marked in place.</p>
      </header>
      <div class="os-doc-grid" data-animate>
        ${docs.map(d => {
          const st = d.stats || {};
          const pct = st.total ? Math.round((st.covered + st.partial * 0.5) / st.total * 100) : null;
          return `<a class="os-doccard" href="#/osce/cards/${esc(d.id)}">
            <strong>${esc(d.title)}</strong>
            <em>${d.bp ? esc(OsceBlueprint.moduleName(modules, d.bp.module)) : 'unplaced'}</em>
            ${st.total ? `<div class="os-doc-bar" title="${st.covered} said, ${st.partial} half-said, ${st.missed} missed">
              <i class="cov" style="flex:${st.covered}"></i><i class="par" style="flex:${st.partial}"></i><i class="mis" style="flex:${st.missed}"></i>
            </div>
            <span class="tiny muted">${st.missed} of ${st.total} points were new to you${pct != null ? ` · ${pct}% covered` : ''}</span>` : ''}
            <span class="tiny muted">${esc(new Date(d.created).toLocaleDateString('en-GB', { dateStyle: 'medium' }))}</span>
          </a>`;
        }).join('')}
      </div>`;
    FX.viewIn(view);
  }

  /** The document itself. */
  function paintDoc(view, host, d) {
    const doc = d.doc || {};
    const st = d.stats || {};
    let filter = 'all';

    const pointRow = p => {
      const m = DOC_MARK[p.status] || DOC_MARK.missed;
      return `<li class="os-dp is-${m.cls}" data-st="${m.cls}">
        <span class="os-dp-i" title="${m.label}">${m.ico}</span>
        <span>${esc(p.point)}</span>
      </li>`;
    };

    const draw = () => {
      host.innerHTML = `
        <header data-animate>
          <p class="kicker"><a class="link" href="#/osce/cards">← All documents</a></p>
          <h1 class="page-title">${esc(doc.title || d.title)}</h1>
          ${doc.oneLine ? `<p class="os-doc-one">${esc(doc.oneLine)}</p>` : ''}
        </header>

        <div class="card os-doc-key" data-animate>
          <div class="os-doc-figs">
            <span class="os-dp-i cov">✓</span><span><strong>${st.covered || 0}</strong> you said</span>
            <span class="os-dp-i par">~</span><span><strong>${st.partial || 0}</strong> half-said</span>
            <span class="os-dp-i mis">✗</span><span><strong>${st.missed || 0}</strong> you did not</span>
          </div>
          <div class="os-doc-filters">
            ${[['all', 'Everything'], ['mis', 'Only what I missed'], ['cov', 'Only what I said']].map(([k, l]) =>
              `<button class="os-pick-b ${filter === k ? 'active' : ''}" data-filt="${k}">${l}</button>`).join('')}
          </div>
        </div>

        ${doc.recognise ? `<div class="card" data-animate>
          <h3 class="card-title">How you know you are in this case</h3>
          <p>${esc(doc.recognise)}</p></div>` : ''}

        <div class="os-doc-body" data-animate>
          ${(doc.sections || []).map((sec, i) => {
            const pts = sec.points || [];
            const missed = pts.filter(p => p.status === 'missed').length;
            return `<section class="card os-doc-sec" data-sec="${i}">
              <h3 class="card-title">
                <span class="os-doc-n">${i + 1}</span> ${esc(sec.heading || '')}
                ${missed ? `<span class="os-doc-flag">${missed} missed</span>` : ''}
              </h3>
              ${sec.body ? `<p class="os-doc-teach">${esc(sec.body)}</p>` : ''}
              ${sec.sayThis ? `<p class="os-doc-say"><span>Say it like this</span>“${esc(sec.sayThis)}”</p>` : ''}
              ${pts.length ? `<ul class="os-dp-list">${pts.map(pointRow).join('')}</ul>` : ''}
            </section>`;
          }).join('')}
        </div>

        ${(doc.traps || []).length ? `<div class="card" data-animate>
          <h3 class="card-title">⚠ What loses marks here</h3>
          <ul class="os-doc-list">${doc.traps.map(t => `<li>${esc(t)}</li>`).join('')}</ul></div>` : ''}

        ${(doc.vivaQuestions || []).length ? `<div class="card" data-animate>
          <h3 class="card-title">Where the examiner goes next</h3>
          <p class="muted tiny">Answer this station well and these are what follow.</p>
          <ul class="os-doc-list">${doc.vivaQuestions.map(t => `<li>${esc(t)}</li>`).join('')}</ul></div>` : ''}

        ${(doc.guidelines || []).length ? `<div class="card" data-animate>
          <h3 class="card-title">The guidance behind it</h3>
          <ul class="os-doc-list">${doc.guidelines.map(t => `<li>${esc(t)}</li>`).join('')}</ul></div>` : ''}

        <div class="os-run-foot" data-animate>
          <button class="btn btn-gold" id="os-doc-print">🖨 Download as PDF</button>
          <button class="btn btn-ghost" id="os-doc-copy">📄 Copy as text</button>
          <a class="btn btn-ghost btn-sm" href="#/osce/result/${esc(d.attemptId)}">The station this came from</a>
          <button class="btn btn-ghost btn-sm qr-danger" id="os-doc-del">Delete</button>
        </div>`;
      FX.viewIn(view);
      applyFilter();

      host.querySelectorAll('[data-filt]').forEach(b => b.addEventListener('click', () => {
        filter = b.dataset.filt;
        host.querySelectorAll('[data-filt]').forEach(x => x.classList.toggle('active', x === b));
        applyFilter();
      }));
      host.querySelector('#os-doc-print').addEventListener('click', () => printDoc(d));
      host.querySelector('#os-doc-copy').addEventListener('click', e => copyOut(docAsText(d), e.currentTarget, '📄 Copy as text'));
      host.querySelector('#os-doc-del').addEventListener('click', async () => {
        if (!confirm('Delete this study document? The station and its report are not affected.')) return;
        try { await Backend.deleteOsceDeck(d.id); bustDecks(); } catch {}
        location.hash = '#/osce/cards';
      });
    };

    /* Filtering hides POINTS, never the teaching: "only what I missed" is
       for revising the gaps, and a gap with its explanation removed is not
       revision. A section whose points all disappear goes with them. */
    function applyFilter() {
      host.querySelectorAll('.os-doc-sec').forEach(sec => {
        let shown = 0;
        sec.querySelectorAll('.os-dp').forEach(li => {
          const keep = filter === 'all' || li.dataset.st === filter
            || (filter === 'mis' && li.dataset.st === 'par');
          li.hidden = !keep;
          if (keep) shown++;
        });
        const had = sec.querySelectorAll('.os-dp').length;
        sec.hidden = filter !== 'all' && had > 0 && shown === 0;
      });
    }
    draw();
  }

  /** The document as plain text, for pasting anywhere. */
  function docAsText(d) {
    const doc = d.doc || {};
    const L = [];
    L.push(String(doc.title || d.title || '').toUpperCase());
    if (doc.oneLine) L.push(doc.oneLine);
    L.push('');
    if (doc.recognise) { L.push('HOW YOU KNOW YOU ARE IN THIS CASE'); L.push(doc.recognise); L.push(''); }
    (doc.sections || []).forEach((sec, i) => {
      L.push(`${i + 1}. ${sec.heading || ''}`);
      if (sec.body) L.push(sec.body);
      if (sec.sayThis) L.push(`   Say it like this: "${sec.sayThis}"`);
      (sec.points || []).forEach(p => {
        const m = DOC_MARK[p.status] || DOC_MARK.missed;
        L.push(`   [${m.ico}] ${p.point}`);
      });
      L.push('');
    });
    const list = (h, arr) => { if ((arr || []).length) { L.push(h); arr.forEach(x => L.push(' - ' + x)); L.push(''); } };
    list('WHAT LOSES MARKS HERE', doc.traps);
    list('WHERE THE EXAMINER GOES NEXT', doc.vivaQuestions);
    list('THE GUIDANCE BEHIND IT', doc.guidelines);
    L.push('✓ said · ~ half-said · ✗ not said — from your attempt on '
      + new Date(d.created).toLocaleDateString('en-GB', { dateStyle: 'medium' }));
    return L.join('\n').replace(/\n{3,}/g, '\n\n').trim();
  }

  /* Printed the same way the station report is: into the page, then the
     page itself. A hidden iframe is ignored by iPadOS Safari. */
  function printDoc(d) {
    const doc = d.doc || {};
    const st = d.stats || {};
    const P = '#os-printdoc';
    const styles = `
@page { size: A4 portrait; margin: 15mm 14mm; }
${P}, ${P} *{box-sizing:border-box}
${P}{position:fixed;inset:0;z-index:9000;overflow:auto;background:#f1f2f6;color:#111;
  font-family:"Helvetica Neue",Arial,sans-serif;font-size:10.5pt;line-height:1.55;
  -webkit-print-color-adjust:exact;print-color-adjust:exact}
${P} .sheet{background:#fff;width:210mm;min-height:297mm;margin:0 auto 28px;padding:15mm 14mm;box-shadow:0 2px 18px rgba(0,0,0,.16)}
${P} h1{font-family:Georgia,serif;font-size:20pt;margin:0 0 4px;color:#111}
${P} h2{font-size:12.5pt;margin:16px 0 6px;color:#111;border-left:4px solid #0d8f7d;padding-left:9px}
${P} .one{font-size:11pt;font-style:italic;color:#444;margin:0 0 10px}
${P} .brand{font-size:7.5pt;letter-spacing:.22em;text-transform:uppercase;color:#7a5a10;margin:0 0 2px}
${P} .key{display:flex;gap:16px;font-size:9pt;color:#444;border-top:1px solid #ddd;border-bottom:1px solid #ddd;
  padding:7px 0;margin:10px 0 14px}
${P} .sec{margin:0 0 14px;break-inside:avoid}
${P} .teach{margin:0 0 6px}
${P} .say{background:#f5f7f6;border-left:3px solid #0d8f7d;padding:7px 10px;margin:0 0 7px;font-style:italic}
${P} ul.pts{list-style:none;padding:0;margin:0}
${P} ul.pts li{display:flex;gap:7px;margin-bottom:.2em;break-inside:avoid}
${P} .pip{width:13px;flex:0 0 13px;text-align:center;font-weight:800}
${P} .cov{color:#0d8f7d}${P} .par{color:#a5750f}${P} .mis{color:#c62828}
${P} .mis-row{background:#fdf4f4}
${P} ul.plain{margin:0 0 8px;padding-left:1.2em}
${P} .foot{margin-top:16px;padding-top:6px;border-top:1px solid #ddd;font-size:7.5pt;color:#888;display:flex;justify-content:space-between}
${P} .os-pd-bar{position:sticky;top:0;z-index:2;display:flex;gap:10px;justify-content:center;align-items:center;
  padding:10px;background:#1b1b22;color:#fff;font-size:11pt}
${P} .os-pd-bar button{font:inherit;font-size:10pt;padding:7px 16px;border-radius:8px;border:0;cursor:pointer}
${P} .os-pd-print{background:#e8b53f;color:#241d05;font-weight:700}
${P} .os-pd-close{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.4)}
@media print {
  html,body{background:#fff !important;margin:0 !important;padding:0 !important;height:auto !important;overflow:visible !important}
  body > *:not(${P}){display:none !important}
  ${P}{position:static !important;overflow:visible !important;background:#fff !important}
  ${P} .os-pd-bar{display:none !important}
  ${P} .sheet{width:auto !important;min-height:0 !important;margin:0 !important;padding:0 !important;box-shadow:none !important}
}`;
    const pip = p => {
      const m = DOC_MARK[p.status] || DOC_MARK.missed;
      return `<li class="${m.cls === 'mis' ? 'mis-row' : ''}"><span class="pip ${m.cls}">${m.ico}</span><span>${esc(p.point)}</span></li>`;
    };
    const list = (h, arr) => (arr || []).length
      ? `<h2>${h}</h2><ul class="plain">${arr.map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : '';
    const body = `<div class="os-pd-bar">
        <button class="os-pd-print" type="button" data-pd-print>🖨 Print / Save as PDF</button>
        <button class="os-pd-close" type="button" data-pd-close>Close</button>
      </div><div class="sheet">
      <p class="brand">AUREUM · Pathway to MD</p>
      <h1>${esc(doc.title || d.title || '')}</h1>
      ${doc.oneLine ? `<p class="one">${esc(doc.oneLine)}</p>` : ''}
      <div class="key"><span><b class="cov">✓</b> ${st.covered || 0} said</span>
        <span><b class="par">~</b> ${st.partial || 0} half-said</span>
        <span><b class="mis">✗</b> ${st.missed || 0} not said</span>
        <span>sat ${esc(new Date(d.created).toLocaleDateString('en-GB', { dateStyle: 'medium' }))}</span></div>
      ${doc.recognise ? `<h2>How you know you are in this case</h2><p>${esc(doc.recognise)}</p>` : ''}
      ${(doc.sections || []).map((sec, i) => `<div class="sec">
        <h2>${i + 1}. ${esc(sec.heading || '')}</h2>
        ${sec.body ? `<p class="teach">${esc(sec.body)}</p>` : ''}
        ${sec.sayThis ? `<p class="say">“${esc(sec.sayThis)}”</p>` : ''}
        ${(sec.points || []).length ? `<ul class="pts">${sec.points.map(pip).join('')}</ul>` : ''}
      </div>`).join('')}
      ${list('What loses marks here', doc.traps)}
      ${list('Where the examiner goes next', doc.vivaQuestions)}
      ${list('The guidance behind it', doc.guidelines)}
      <div class="foot"><span>${esc(d.station || '')}</span><span>AUREUM · ${esc(new Date().toLocaleDateString('en-GB', { dateStyle: 'medium' }))}</span></div>
    </div>`;
    openPrintSheet(styles, body);
  }

  /* ================= progress (#/osce/progress) =================

     The blueprint coverage map, the mistakes that keep repeating, and the
     shape of the scores. Deliberately the same arithmetic as the SBA and
     EMQ maps: a MODULE's percentage is the mean of its topics, never the
     pooled station count, so one heavily-stationed topic cannot paint a
     module green while its neighbours have never been touched.

     A topic with no station is not a gap in anybody's revision — it is a
     topic that cannot be examined this way — and it is labelled as such
     rather than sitting there as a permanent reproach. */

  async function renderProgress(view, user) {
    view.innerHTML = shell('progress', `<div id="os-body"><p class="muted">Reading your attempts…</p></div>`);
    FX.viewIn(view);
    const host = view.querySelector('#os-body');

    const [modules, cards] = await Promise.all([
      OsceBlueprint.get().catch(() => []),
      stations().catch(() => [])
    ]);
    let list = [];
    try { list = (await myAttempts()) || []; } catch {}
    const scored = list.filter(a => a.result && a.result.percent != null);

    if (!scored.length) {
      host.innerHTML = `<div class="card"><h3 class="card-title">Nothing to map yet</h3>
        <p class="muted">Sit a station and this fills in: which modules of the blueprint you have covered, which
          mistakes keep coming back, and how the scores are moving.</p>
        <a class="btn btn-gold" href="#/osce/sim">Build a circuit</a></div>`;
      return;
    }

    const cov = OsceBlueprint.coverage(modules, cards, scored);
    const mean = Math.round(scored.reduce((n, a) => n + a.result.percent, 0) / scored.length);
    const passed = scored.filter(a => a.result.pass).length;
    const recent = scored.slice(0, 8).reverse();

    /* The mistakes need the FULL attempts — the list projection carries the
       score and nothing else. Only the last dozen are opened: that is where
       a pattern that still matters will be, and it keeps the page cheap. */
    host.innerHTML = gapHtml(cov, scored)
      + coverageHtml(cov, modules, mean, passed, scored, recent)
      + `<div class="card" data-animate id="os-mistakes"><h3 class="card-title">🔁 What keeps costing you marks</h3>
           <p class="muted">Reading your last stations…</p></div>`
      + `<div id="os-drift"></div>`;
    FX.viewIn(view);
    paintTrend(view, recent);

    const deep = [];
    for (const a of scored.slice(0, 12)) {
      try { const full = await Backend.getOsceAttempt(a.id); if (full) deep.push(full); } catch {}
    }
    paintMistakes(view.querySelector('#os-mistakes'), deep, modules, cards);
    paintDrift(view.querySelector('#os-drift'), deep);
  }

  /* ---------------- the gap, said out loud ----------------

     The coverage map below is a picture, and a picture is something you
     look at. This is the same data as a sentence with a button on it,
     because the useful form of "gynae-oncology is 15% of the paper and
     you have not touched it in six weeks" is not a bar that is shorter
     than the others — it is being told to go and sit one.

     One module. Naming three would be a list, and a list is a picture
     again. */
  function gapHtml(cov, scored) {
    const mods = (cov.modules || []).filter(m => m.examinable > 0);
    if (!mods.length || !scored.length) return '';

    /* When each module was last sat, from the attempts' own blueprint
       tags — an attempt keeps the module it was actually sat under. */
    const lastAt = {};
    scored.forEach(a => {
      const id = a.bp && (a.bp.module || a.bp);
      if (!id) return;
      lastAt[id] = Math.max(lastAt[id] || 0, a.created || 0);
    });

    const now = Date.now();
    const scoreOf = m => {
      const covered = m.percent == null ? 0 : m.percent;      // 0–100 of the module walked
      const weight = Math.max(1, m.examinable);                // topics that can be examined
      const days = lastAt[m.id] ? (now - lastAt[m.id]) / 86400e3 : 999;
      /* Untouched beats stale, stale beats merely weak, and a big module
         beats a small one. Multiplied rather than added so a module that
         is fully covered cannot be dragged to the top by age alone. */
      return (100 - covered) * weight * (1 + Math.min(days, 60) / 30);
    };
    const worst = mods.slice().sort((a, b) => scoreOf(b) - scoreOf(a))[0];
    if (!worst || (worst.percent != null && worst.percent >= 85)) return '';

    const days = lastAt[worst.id] ? Math.floor((now - lastAt[worst.id]) / 86400e3) : null;
    const untouched = (worst.topics || []).filter(t => t.examinable && !t.attempts);
    const when = days == null ? 'You have never sat a station in it.'
      : days < 1 ? 'You sat one today.'
      : `The last one was ${days} day${days === 1 ? '' : 's'} ago.`;

    return `<div class="card os-gap" data-animate>
      <p class="kicker">THE GAP</p>
      <h3 class="os-gap-h">${esc(worst.name)}</h3>
      <p class="os-gap-p">${when} ${untouched.length
        ? `<strong>${untouched.length}</strong> of its ${worst.examinable} examinable topics have never been sat:
           ${untouched.slice(0, 4).map(t => esc(t.name)).join(', ')}${untouched.length > 4 ? ', and more' : ''}.`
        : `You have touched every topic in it, but only ${worst.percent || 0}% of the way through.`}</p>
      <div class="os-gap-acts">
        <a class="btn btn-gold" href="#/osce?bp=${encodeURIComponent(worst.id)}">Find a station in it →</a>
        <a class="btn btn-ghost btn-sm" href="#/osce/sim">Build a circuit</a>
      </div>
      <p class="muted tiny">Chosen by what the paper weights, how much of the module is untouched, and how long it
        has been — not by your worst score. A module you are bad at but sat yesterday is not the gap.</p>
    </div>`;
  }

  /* ---------------- the drift ledger ----------------

     Every AI-examined attempt carries processIntegrity: whether the
     question list was confirmed before the station started, and whether
     an invented question had to be corrected during it. Read one at a
     time that is an annoyance. Read together it is evidence — and the
     thing it is evidence about is a process you can change. */
  function paintDrift(host, deep) {
    if (!host) return;
    const withPi = deep.filter(a => a.result?.processIntegrity);
    if (withPi.length < 2) { host.innerHTML = ''; return; }
    const drifted = withPi.filter(a => a.result.processIntegrity.driftDetected);
    const unconfirmed = withPi.filter(a => a.result.processIntegrity.preflightConfirmed === false);
    if (!drifted.length && !unconfirmed.length) {
      host.innerHTML = `<div class="card os-drift-ok" data-animate>
        <h3 class="card-title">✓ The examiner stayed on the scheme</h3>
        <p class="muted">${withPi.length} AI-examined station${withPi.length === 1 ? '' : 's'}, every one
          pre-flight confirmed and none drifting off the pasted questions. Keep pasting the block as one whole
          message and it stays that way.</p>
      </div>`;
      return;
    }
    const pct = Math.round((drifted.length / withPi.length) * 100);
    /* The correlation worth naming: drift concentrates on long stations,
       because more questions is more chances to reach for a plausible
       one. If it does not hold in this data, nothing is claimed. */
    const qOf = a => (a.questions || []).length;
    const dq = drifted.length ? drifted.reduce((n, a) => n + qOf(a), 0) / drifted.length : 0;
    const cq = (withPi.length - drifted.length)
      ? withPi.filter(a => !a.result.processIntegrity.driftDetected).reduce((n, a) => n + qOf(a), 0) / (withPi.length - drifted.length) : 0;
    const longer = dq && cq && dq > cq + 0.75;

    host.innerHTML = `<div class="card os-drift-ledger" data-animate>
      <h3 class="card-title">🎯 How often the examiner drifted</h3>
      <div class="os-dl-figs">
        <div><strong>${drifted.length}/${withPi.length}</strong><span>stations with an invented question</span></div>
        <div><strong>${pct}%</strong><span>of AI-examined stations</span></div>
        <div><strong>${unconfirmed.length}</strong><span>started without confirming the list</span></div>
      </div>
      ${drifted.length ? `<ul class="os-dl-list">${drifted.slice(0, 5).map(a => `<li>
        <a class="link" href="#/osce/result/${encodeURIComponent(a.id)}">${esc(a.station?.topic || a.station_id || 'A station')}</a>
        <span class="muted tiny">${esc(new Date(a.created || Date.now()).toLocaleDateString('en-GB', { dateStyle: 'medium' }))}${
          a.result.processIntegrity.driftNotes ? ' — ' + esc(String(a.result.processIntegrity.driftNotes).slice(0, 110)) : ''}</span>
      </li>`).join('')}</ul>` : ''}
      <p class="muted">${unconfirmed.length
        ? `<strong>${unconfirmed.length}</strong> of these began without the examiner reading the question list back to
           you. That step costs under a minute and is the one that catches a block that did not land — do not skip it.`
        : 'Every one was pre-flight confirmed, so these drifted mid-session rather than starting wrong.'}
        ${longer ? ` The ones that drifted had more questions on average (${dq.toFixed(1)} against ${cq.toFixed(1)}) —
          longer stations give it more chances to reach for a plausible-sounding question.` : ''}</p>
      <p class="muted tiny">Paste the station block as one whole message with nothing before or after it, and never
        two stations in one conversation. Both are what this measures.</p>
    </div>`;
  }

  /* ================= three examiners, one station =================

     AUREUM keeps AI-marked, Claude-marked and hand-marked attempts
     deliberately apart, because averaging different examiners together
     makes the average mean nothing. That is right, and it left the most
     interesting thing in the whole system with nowhere to be seen: the
     points where two examiners looked at the same answer and disagreed.

     Agreement is reassuring and tells you little. Disagreement is where
     the information is. A point the machine called covered and the human
     called missed is either an answer that reads better than it sounded,
     or a marker being generous — and which of those it is, is exactly
     what a candidate needs to know before the real exam.

     So this page shows the scheme once, down the left, and every
     examiner's verdict beside it, with the rows they disagree on lifted
     to the top. Nothing is averaged. Nothing is reconciled. The
     disagreement IS the output. */

  const SRC = {
    ai:     { label: 'AUREUM AI', cls: 'is-ai' },
    claude: { label: 'Marked by Claude', cls: 'is-claude' },
    manual: { label: 'In person', cls: 'is-manual' }
  };
  const srcOf = a => (a.source === 'claude' || a.source === 'manual') ? a.source : 'ai';
  const ptKey = s => String(s == null ? '' : s).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();

  /** The verdicts one attempt recorded, keyed by marking point. */
  function verdictMap(a) {
    const out = {};
    (a.result?.questions || []).forEach(mq => {
      (mq.points || []).forEach(p => {
        const k = ptKey(p?.point);
        if (k) out[k] = { status: String(p?.status || '').toLowerCase(), note: p?.note || '' };
      });
    });
    return out;
  }

  async function renderCompare(view, stationId, user) {
    view.innerHTML = shell('mine', `<div id="os-body"><p class="muted">Reading the markings…</p></div>`);
    FX.viewIn(view);
    const host = view.querySelector('#os-body');

    let st = null;
    try { st = await Backend.getOsceStation(stationId); } catch {}
    let list = [];
    try { list = (await myAttempts()) || []; } catch {}
    const mine = list.filter(a => String(a.station_id) === String(stationId))
      .sort((a, b) => (b.created || 0) - (a.created || 0));

    /* The most recent of each kind. Two AI markings of the same station
       are the same examiner twice and tell you nothing new; an AI and a
       human marking are the comparison. */
    const picked = [];
    ['manual', 'claude', 'ai'].forEach(kind => {
      const row = mine.find(a => srcOf(a) === kind);
      if (row) picked.push(row);
    });

    if (picked.length < 2) {
      host.innerHTML = `<div class="card" data-animate>
        <h3 class="card-title">Only one examiner has marked this</h3>
        <p class="muted">This page compares the same station marked by more than one examiner — AUREUM's own marker,
          a chat model, and a person in the room. ${picked.length
            ? `So far only <strong>${esc(SRC[srcOf(picked[0])].label)}</strong> has.` : 'Nothing has been marked yet.'}</p>
        <p class="muted tiny">Sit it again and have it marked a different way. The disagreements are where the
          information is: a point one marker called covered and another called missed is either an answer that reads
          better than it sounded, or a marker being generous — and knowing which matters more than either score.</p>
        <a class="btn btn-gold" href="#/osce/station/${encodeURIComponent(stationId)}">Open the station →</a>
      </div>`;
      return;
    }

    const full = [];
    for (const row of picked) {
      try { const f = await Backend.getOsceAttempt(row.id); if (f) full.push(f); } catch {}
    }
    if (full.length < 2) { host.innerHTML = `<div class="card"><p class="muted">Those markings could not be read.</p></div>`; return; }

    const maps = full.map(verdictMap);
    /* The scheme's own order, from the station if it is still there —
       falling back to whatever the first marking listed, so a station
       that has since been deleted still compares. */
    const rows = [];
    const seen = new Set();
    const push = (point, qLabel) => {
      const k = ptKey(point);
      if (!k || seen.has(k)) return;
      seen.add(k);
      const cells = maps.map(m => m[k] || null);
      const known = cells.filter(Boolean).map(c => c.status.replace(/^cover.*/, 'covered').replace(/^part.*/, 'partial').replace(/^miss.*/, 'missed'));
      const agree = known.length > 1 && known.every(s => s === known[0]);
      rows.push({ point, q: qLabel, cells, agree, judged: known.length });
    };
    if (st) {
      qsOf(st).forEach((q, i) => scorable(q.marking_points).forEach(p => push(p, `Q${i + 1}`)));
    }
    full[0].result?.questions?.forEach((mq, i) => (mq.points || []).forEach(p => push(p?.point, `Q${i + 1}`)));

    const contested = rows.filter(r => r.judged > 1 && !r.agree);
    const agreed = rows.filter(r => r.judged > 1 && r.agree);
    const partial = rows.filter(r => r.judged <= 1);

    const ico = c => !c ? '<span class="cmp-na" title="this examiner did not record this point">·</span>'
      : /^cover/.test(c.status) ? '<span class="cmp-v is-cov">✓</span>'
      : /^part/.test(c.status) ? '<span class="cmp-v is-par">~</span>'
      : '<span class="cmp-v is-mis">✗</span>';

    const table = list2 => `<table class="cmp-tab">
      <thead><tr><th class="cmp-pt">Marking point</th>${full.map(a => {
        const s = SRC[srcOf(a)];
        return `<th class="cmp-h ${s.cls}"><span>${esc(s.label)}</span></th>`;
      }).join('')}</tr></thead>
      <tbody>${list2.map(r => `<tr class="${r.agree ? '' : 'is-split'}">
        <td class="cmp-pt"><span class="cmp-q">${esc(r.q || '')}</span> ${esc(r.point)}</td>
        ${r.cells.map(c => `<td class="cmp-c" ${c?.note ? `title="${esc(c.note)}"` : ''}>${ico(c)}</td>`).join('')}
      </tr>`).join('')}</tbody></table>`;

    host.innerHTML = `
      ${(() => {
        /* ONE PERFORMANCE OR SEVERAL? It changes what the page means.

           Two markings of two different sittings differ for two reasons
           at once — you answered differently AND the marker was
           different — and nothing can separate them. Two markings of the
           SAME recording hold the answer constant, so every disagreement
           is about the marking and only the marking. That is a far
           stronger reading and the page has to say which one it is
           rather than let it be assumed. */
        const sits = full.map(a => a.sitting).filter(Boolean);
        const oneSitting = sits.length === full.length && new Set(sits).size === 1;
        return `<header class="page-head" data-animate>
        <p class="kicker">SIDE BY SIDE${oneSitting ? ' · ONE SITTING' : ''}</p>
        <h1 class="page-title">${esc(st?.topic || full[0].station?.topic || 'This station')}</h1>
        <p class="muted">${oneSitting
          ? `The <strong>same fifteen minutes</strong>, marked ${full.length} ways — one recording, ${full.length}
             markers. The answer is held constant, so every disagreement below is about the marking and nothing
             else. This is the strongest reading this page can give you.`
          : `The same station, marked ${full.length} ways on ${full.length} separate sittings. You answered
             differently each time as well, so a disagreement here is partly the marker and partly you.`}
          Nothing is averaged — the point of keeping the markers apart is that they can disagree.</p>
      </header>`;
      })()}

      <div class="card cmp-scores" data-animate>
        ${full.map(a => {
          const s = SRC[srcOf(a)];
          const r = a.result || {};
          return `<div class="cmp-score ${s.cls}">
            <span class="cmp-score-w">${esc(s.label)}</span>
            <strong>${r.percent ?? '—'}%</strong>
            <span class="muted tiny">${r.total ?? '—'}/${r.max ?? '—'} · ${
              esc(new Date(a.created || Date.now()).toLocaleDateString('en-GB', { dateStyle: 'medium' }))}</span>
            <a class="link tiny" href="#/osce/result/${encodeURIComponent(a.id)}">Open →</a>
          </div>`;
        }).join('')}
      </div>

      ${contested.length ? `<div class="card cmp-split" data-animate>
        <h3 class="card-title">⚡ Where they disagree — ${contested.length} point${contested.length === 1 ? '' : 's'}</h3>
        <p class="muted">Read these first. Each one is a point where the same answer was scored two different ways.
          Listen back to what you actually said: either it read better than it sounded, or one of these markers is
          being kind to you — and both are worth knowing before the real thing.</p>
        <div class="table-scroll">${table(contested)}</div>
      </div>` : `<div class="card" data-animate>
        <h3 class="card-title">✓ They agree on everything they both judged</h3>
        <p class="muted">${agreed.length} point${agreed.length === 1 ? '' : 's'} scored the same way by every marker.
          That is a marking you can trust — and a rarer result than you would expect.</p>
      </div>`}

      ${agreed.length ? `<details class="card cmp-fold" data-animate>
        <summary><span class="card-title">Where they agree — ${agreed.length} point${agreed.length === 1 ? '' : 's'}</span><span class="dc-caret">▸</span></summary>
        <div class="table-scroll">${table(agreed)}</div>
      </details>` : ''}

      ${partial.length ? `<details class="card cmp-fold" data-animate>
        <summary><span class="card-title">Judged by only one of them — ${partial.length}</span><span class="dc-caret">▸</span></summary>
        <p class="muted tiny">A marking that stopped early, or a scheme edited between the two attempts. Not a
          disagreement — nobody to disagree with.</p>
        <div class="table-scroll">${table(partial)}</div>
      </details>` : ''}`;
    FX.viewIn(view);
  }

  function coverageHtml(cov, modules, mean, passed, scored, recent) {
    const barFor = m => {
      const pct = m.percent == null ? 0 : m.percent;
      const cls = m.examinable === 0 ? 'is-none' : pct >= 80 ? 'is-good' : pct >= 40 ? 'is-mid' : 'is-low';
      return `<div class="os-cov-mod ${cls}">
        <div class="os-cov-head">
          <strong>${esc(m.name)}</strong>
          ${m.examinable === 0
            ? '<span class="tiny muted">no station examines this yet</span>'
            : `<span class="tiny muted">${m.touched} of ${m.examinable} topics${m.mean != null ? ` · ${m.mean}% mean` : ''}</span>`}
        </div>
        <div class="os-cov-bar"><i style="width:${pct}%"></i></div>
        <div class="os-cov-topics">
          ${(m.topics || []).map(t => `<span class="os-cov-chip ${
            !t.examinable ? 'is-na' : t.attempts ? (t.best >= 70 ? 'is-good' : t.best >= 50 ? 'is-mid' : 'is-low') : 'is-untouched'
          }" title="${esc(t.name)}${t.examinable ? ` — ${t.stations} station${t.stations === 1 ? '' : 's'}${
            t.attempts ? `, best ${t.best}%` : ', never sat'}` : ' — no station'}">${esc(t.name)}</span>`).join('')}
        </div>
      </div>`;
    };
    const noStation = cov.modules.filter(m => m.examinable === 0).length;
    return `
      <header data-animate>
        <p class="kicker">OSCE PROGRESS</p>
        <h1 class="page-title">Where you stand</h1>
      </header>

      <div class="card os-prog-figs" data-animate>
        <div class="os-circ-fig"><b>${scored.length}</b><span>stations marked</span></div>
        <div class="os-circ-fig"><b>${mean}%</b><span>mean score</span></div>
        <div class="os-circ-fig"><b>${passed}/${scored.length}</b><span>at or above the pass mark</span></div>
        <div class="os-circ-fig"><b>${cov.overall}%</b><span>of the blueprint touched</span></div>
      </div>

      <div class="card" data-animate>
        <h3 class="card-title">📈 How the scores are moving</h3>
        <p class="muted tiny">Your last ${recent.length} marked stations, oldest first. The line is the pass mark of
          each station, which is not the same on every one.</p>
        <div id="os-trend" class="os-trend"></div>
      </div>

      <div class="card" data-animate>
        <h3 class="card-title">🗺 The blueprint, and how much of it you have walked</h3>
        <p class="muted">The exam draws nine stations from these modules. A module only turns green when the whole of
          it has been covered — one topic sat nine times does not colour it in. ${
          noStation ? `<strong>${noStation}</strong> module${noStation === 1 ? ' has' : 's have'} no station written yet;
          they are greyed out rather than counted against you.` : ''}</p>
        <div class="os-cov">${cov.modules.map(barFor).join('')}</div>
        ${cov.untagged ? `<p class="muted tiny" style="margin-top:10px">${cov.untagged} published station${
          cov.untagged === 1 ? ' is' : 's are'} not yet placed on the blueprint, so they do not appear above.</p>` : ''}
      </div>`;
  }

  /** A small column chart of the recent scores against each station's pass mark. */
  function paintTrend(view, recent) {
    const host = view.querySelector('#os-trend');
    if (!host || !recent.length) return;
    const w = 100 / recent.length;
    host.innerHTML = recent.map((a, i) => {
      const pct = a.result.percent;
      const pass = a.passMark != null && a.result.max ? Math.round(a.passMark / a.result.max * 100) : 70;
      return `<div class="os-trend-col" style="width:${w}%" title="${esc(a.topic || '')} — ${pct}% (pass ${pass}%)">
        <i class="${a.result.pass ? 'is-pass' : 'is-fail'}" style="height:${Math.max(3, pct)}%"></i>
        <u style="bottom:${pass}%"></u>
        <span>${pct}</span>
      </div>`;
    }).join('');
  }

  /* The repeated mistakes. A point missed once is bad luck; the same point
     missed in three different stations is the thing to revise tonight —
     so they are grouped by the WORDS of the marking point, not by station,
     and only what came back more than once is promoted to the top. */
  function paintMistakes(host, attempts, modules, cards) {
    if (!host) return;
    const byId = {}; cards.forEach(c => byId[c.id] = c);
    const missed = [];
    for (const a of attempts) {
      for (const qr of (a.result?.questions || [])) {
        for (const p of (qr.points || [])) {
          if (/cover/i.test(p.status)) continue;
          missed.push({ point: String(p.point || ''), status: p.status, note: p.note || '',
            attempt: a.id, topic: a.station?.topic || '', when: a.created || 0,
            bp: a.bp || OsceBlueprint.tagOf(byId[a.station_id]) || null });
        }
      }
    }
    if (!missed.length) {
      host.innerHTML = `<h3 class="card-title">🔁 What keeps costing you marks</h3>
        <p class="muted">Nothing was missed in the stations that have been marked. That is a good problem.</p>`;
      return;
    }
    // group by the idea, not the wording: the first six significant words
    const keyOf = s => OsceBlueprint.norm(s).split(' ').filter(w => w.length > 3).slice(0, 6).join(' ');
    const groups = new Map();
    for (const m of missed) {
      const k = keyOf(m.point) || m.point.slice(0, 40);
      if (!groups.has(k)) groups.set(k, { point: m.point, n: 0, part: 0, topics: new Set(), mods: new Set(), last: 0 });
      const g = groups.get(k);
      g.n++; if (/partial/i.test(m.status)) g.part++;
      if (m.topic) g.topics.add(m.topic);
      if (m.bp?.module) g.mods.add(m.bp.module);
      g.last = Math.max(g.last, m.when);
      if (m.point.length > g.point.length) g.point = m.point;   // keep the fullest wording
    }
    const all = [...groups.values()].sort((a, b) => b.n - a.n || b.last - a.last);
    const repeats = all.filter(g => g.n > 1);
    const once = all.filter(g => g.n === 1);

    const row = g => `<li class="os-miss ${g.n > 2 ? 'is-hot' : ''}">
      <span class="os-miss-n">${g.n}×</span>
      <div>
        <strong>${esc(g.point)}</strong>
        <span class="tiny muted">${[...g.mods].map(m => esc(OsceBlueprint.moduleName(modules, m))).join(', ') || 'unplaced'}${
          g.part ? ` · ${g.part} of those were partly said` : ''} · seen in ${g.topics.size} station${g.topics.size === 1 ? '' : 's'}</span>
      </div>
    </li>`;

    host.innerHTML = `
      <h3 class="card-title">🔁 What keeps costing you marks</h3>
      <p class="muted">From your last ${attempts.length} marked station${attempts.length === 1 ? '' : 's'}.
        ${repeats.length
          ? `<strong>${repeats.length}</strong> point${repeats.length === 1 ? ' has' : 's have'} been missed more than once —
             those are the ones worth an evening, because they are costing you marks in stations that look nothing alike.`
          : 'Nothing has been missed twice yet.'}</p>
      ${repeats.length ? `<ul class="os-miss-list">${repeats.slice(0, 12).map(row).join('')}</ul>` : ''}
      ${once.length ? `<details class="dev-collapse" style="margin-top:12px">
        <summary><span class="card-title">Missed once (${once.length})</span><span class="dc-caret">▸</span></summary>
        <ul class="os-miss-list">${once.slice(0, 40).map(row).join('')}</ul>
      </details>` : ''}
      <div class="os-tips" id="os-tips"></div>`;

    /* The advice is derived, not generated: a model is not needed to notice
       that six of your last ten misses are in one module. */
    const tips = [];
    /* Counted from the misses themselves, one point one vote. Summing each
       GROUP's total into every module it appeared in multiplied the same
       miss by the number of modules it turned up in, and reported figures
       larger than the number of points that were ever dropped. */
    const modCount = new Map();
    missed.forEach(m => { if (m.bp?.module) modCount.set(m.bp.module, (modCount.get(m.bp.module) || 0) + 1); });
    const worst = [...modCount.entries()].sort((a, b) => b[1] - a[1])[0];
    if (worst && worst[1] >= 3 && modCount.size > 1) {
      tips.push(`Most of what you are dropping sits in <strong>${esc(OsceBlueprint.moduleName(modules, worst[0]))}</strong>
        — ${worst[1]} of your ${missed.length} missed points. A circuit weighted there will find the rest of them.`);
    }
    const partly = all.filter(g => g.part >= g.n / 2 && g.n > 1).length;
    if (partly) {
      tips.push(`<strong>${partly}</strong> of your repeated misses were marked <em>partial</em>, not missed — you are
        reaching the right idea and stopping short of the detail that carries the mark. Say the number, the dose or the
        time window out loud; that is usually the half you are leaving out.`);
    }
    if (repeats.length >= 3) {
      tips.push(`Make a deck from one of these attempts — a card per repeated point, with the figure on the back —
        and it will take a fortnight rather than a term to clear them.`);
    }
    const tipHost = host.querySelector('#os-tips');
    if (tips.length && tipHost) {
      tipHost.innerHTML = `<h4 class="card-title" style="margin-top:18px">What to do about it</h4>
        <ul class="os-tip-list">${tips.map(t => `<li>${t}</li>`).join('')}</ul>`;
    }
  }

  /** Any station left mid-flight, for the "resume" card on the OSCE home. */
  async function openSessions() {
    const out = [];
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (!k || !k.startsWith('aureum.osce:')) continue;
        const s = JSON.parse(localStorage.getItem(k) || 'null');
        if (s && s.phase !== 'done') out.push(s);
      }
    } catch {}
    return out.sort((a, b) => (b.started || 0) - (a.started || 0));
  }

  /** Attempts shaped for the dashboard: newest last, with the bits charts need. */
  async function progress() {
    let list = [];
    try { list = (await myAttempts()) || []; } catch { return []; }
    return list
      .filter(a => a.result && a.result.percent != null)
      .map(a => ({ id: a.id, station: a.station?.topic || a.station_id, percent: a.result.percent,
        total: a.result.total, max: a.result.max, pass: !!a.result.pass, created: a.created || 0,
        passMark: a.station?.pass_mark ?? null }))
      .sort((x, y) => x.created - y.created);
  }

  /* ---------------- speak instead of type, anywhere ----------------
     Whisper is not OSCE-specific. On an iPad, where there is no dictation in
     the browser at all, a microphone button is the difference between a note
     somebody makes and one they do not.

     Attach it beside any textarea, input or contenteditable: press to record,
     press again to stop, and the transcript is appended. Silent about itself
     when Groq is unavailable — the button simply does not appear, because a
     dead button is worse than no button. */
  function micButton(target, opts = {}) {
    if (!target || !groqOn('whisper')) return null;
    if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) return null;

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'voice-mic ' + (opts.className || '');
    btn.title = 'Dictate instead of typing';
    btn.innerHTML = '🎙';
    let media = null, rec = null, chunks = [], busy = false;

    const setText = t => {
      const cur = ('value' in target && target.tagName !== 'DIV') ? target.value : target.innerText;
      const joined = (cur.trim() ? cur.trim() + ' ' : '') + t;
      if ('value' in target && target.tagName !== 'DIV') { target.value = joined; }
      else { target.innerText = joined; }
      target.dispatchEvent(new Event('input', { bubbles: true }));
    };

    const stop = async () => {
      btn.classList.remove('is-rec');
      btn.innerHTML = '⏳';
      busy = true;
      await new Promise(res => { if (!rec) return res(); rec.onstop = res; try { rec.stop(); } catch { res(); } });
      try { media?.getTracks().forEach(t => t.stop()); } catch {}
      const blob = chunks.length ? new Blob(chunks, { type: rec?.mimeType || 'audio/webm' }) : null;
      chunks = []; rec = null; media = null;
      let out = null;
      if (blob) { try { out = await groqTranscribe(blob, opts.hint || ''); } catch {} }
      busy = false;
      btn.innerHTML = '🎙';
      if (out?.text) setText(out.text);
      else {
        btn.title = groqReport().why || 'That could not be transcribed';
        btn.classList.add('is-bad');
        setTimeout(() => btn.classList.remove('is-bad'), 2500);
      }
    };

    btn.addEventListener('click', async () => {
      if (busy) return;
      if (rec) return stop();
      try { media = await navigator.mediaDevices.getUserMedia({ audio: true }); }
      catch { btn.classList.add('is-bad'); btn.title = 'The microphone is blocked for this site';
        setTimeout(() => btn.classList.remove('is-bad'), 2500); return; }
      const mime = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4']
        .find(t => MediaRecorder.isTypeSupported(t)) || '';
      rec = new MediaRecorder(media, Object.assign(mime ? { mimeType: mime } : {}, { audioBitsPerSecond: 24000 }));
      rec.ondataavailable = e => { if (e.data?.size) chunks.push(e.data); };
      rec.start(1000);
      btn.classList.add('is-rec');
      btn.innerHTML = '⏹';
      // a note is a note, not a station — stop it before it becomes a file
      setTimeout(() => { if (rec) stop(); }, (opts.maxSecs || 120) * 1000);
    });
    return btn;
  }

  return { renderBank, renderStation, renderSim, renderRun, renderResult, renderMine, renderEdit, progress,
    renderCircuit, renderProgress, renderDecks, renderCompare, srcOf, verdictMap,
    micButton, groqReport, resetGroq, voiceAvailable: () => groqOn('whisper'),
    stations, bustStations, collections, bustCollections, openSessions, dropSession,
    marksOf, passOf, qsOf, minsOf, imagesOf, isHeading, headText, scorable, questionFor, toWav, wavRateFor, modelChoices, noAudioReason,
    stationAsText, promptLevel, setPromptLevel, promptPlan, missingPoints, saidAlready,
    myAttempts, bustAttempts, decks, bustDecks,
    silenceWait, setSilenceWait, salvageJson,
    /* Lent to the case-discussion section. One recorder implementation, one
       voice path, one base64 encoder: a second copy of makeCapture would be a
       second copy of every iPad workaround inside it, and the two would drift
       apart on the first Safari release that changed something. */
    makeCapture, toBase64, speak, groqVoice, voiceOn: () => groqOn('voice'), openPrintSheet, releaseScroll,
    VSRC, voiceSrc, setVoiceSrc, studioVoice, speakOn: voiceOn, setSpeakOn: setVoiceOn,
    makeDoc, docAsText, allPoints, coachFor, coachWanted, COACH,
    // exposed for tests and for the circuit page's live redraw
    markState, onMarkChange, retryMark, shell, circuitNext,
    printResult, printScheme, __printPresets: PRINT_PRESETS,
    reconcile, creditOf, readingMode, ICONS,
    /* Lent to OSCE in AI so a tape recorded there is marked by exactly the
       same path as one recorded here — the same model picker, the same
       cost estimate, the same upload, the same pending queue. A second
       copy of this would be a second copy of every one of those. */
    wireMarkControls, effectiveSource, chosenModel,
    roleOf, hasRole, roleLabel, roleText, roleHtml,
    __parseResult: parseResult };
})();
